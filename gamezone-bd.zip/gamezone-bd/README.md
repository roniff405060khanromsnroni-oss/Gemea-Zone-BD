# GAMEZONE BD — Gaming Top-Up Marketplace

*Your Gaming Top-Up Destination.* A full-stack top-up store: customer storefront, order & payment flow,
order tracking, user accounts, and a role-protected admin dashboard. Prices are in BDT (৳).

* **Backend:** Node.js (no npm dependencies) · built-in `node:sqlite` database · scrypt password hashing
* **Frontend:** single-page app in vanilla ES modules (no build step) — `public/`
* **Admin:** separate app at `/admin`, protected by role-based authentication

---

## 1. Read this first — what is and is not "live"

| Area | Status |
|---|---|
| Storefront, accounts, orders, tracking, admin dashboard | ✅ Working, covered by automated tests and a real-browser run |
| **Manual payments** (bKash / Nagad / Rocket "Send Money") | ✅ Working. Customer submits TrxID → **an admin verifies it against the real account balance/statement** → only then is the order marked paid |
| **bKash online gateway** | ⚙️ Integration is written, but **disabled until you add your bKash merchant credentials**. It was tested only against a *local mock* of bKash, never the real service. **Test it in bKash's sandbox before taking real money.** |
| **Nagad online gateway** | ❌ Not implemented (Nagad requires merchant RSA keys only Nagad can issue). Nagad works in manual mode. `server/services/providers/nagad.js` marks where to add it. |
| **Delivering the top-up to the game account** | ❌ **Manual.** There is no automatic delivery API. After payment is verified, you deliver the diamonds/UC yourself (through your supplier/reseller panel) and then mark the order **Completed**. |
| Product prices | ⚠️ The seeded prices are **sample values**. Set your real prices in *Admin → Products* before launch. |
| Payment methods | Seeded **disabled**, and a method stays hidden from customers until it is usable (manual methods need a receiving number; gateway methods need credentials). |
| Reviews / "latest orders" | Nothing is fabricated: they appear only from real customers and real completed orders (reviews need admin approval). |
| Game artwork | Original abstract artwork generated for this project (`scripts/gen-art.js`). It is **not** official publisher art. Upload licensed images in *Admin → Games / Products*. |

**How "paid" is decided (the rule that is enforced in code):** an order becomes paid only when
(a) an authenticated admin clicks *Verify payment* on an order with a submitted TrxID, or
(b) the payment provider confirms the payment **server-to-server** with a matching amount and invoice number.
A screenshot, a redirect URL, or a customer's claim can never do it. A TrxID can't be reused on another order.

---

## 2. Requirements

* **Node.js 22.13 or newer** (uses the built-in `node:sqlite`; it prints no warnings in `npm` scripts)
* A server with HTTPS for production (a small VPS is enough)
* Optional: SMTP account (password-reset emails), bKash merchant credentials

There is nothing to `npm install`.

## 3. Install & run locally

```bash
cd gamezone-bd
cp .env.example .env            # then edit if you like; defaults work locally
npm run setup                   # creates the database + loads starter content
npm run create-admin            # creates YOUR admin account (asks for email & password)
npm start                       # http://localhost:3000   ·  admin: http://localhost:3000/admin
```

Other commands: `npm run dev` (auto-restart) · `npm test` (22 end-to-end API tests) · `npm run migrate`

**First steps in the admin dashboard** (`/admin`):
1. **Payment methods** → edit bKash/Nagad/Rocket: enter your receiving number and instructions, switch *Enabled* on.
2. **Products** → set your real prices (and tick *Available*).
3. **Website settings** → support WhatsApp/Facebook/etc. links, announcement, footer text.
4. **Games / Banners / Promotions / FAQs** → manage the content customers see.

## 4. Database setup & migrations

SQLite file at `DB_PATH` (default `data/gamezone.db`). Schema lives in `server/db.js` as an append-only list of migrations.
`npm run migrate` applies pending ones and is safe to run repeatedly (the Docker image and systemd unit run it on every start).
To change the schema later, **add** a new migration object — never edit an applied one.
`npm run seed` loads the starter games/FAQs/banners and does nothing if games already exist.

Tables: `users, sessions, password_resets, games, categories, products, payment_methods, orders, order_events, banners, promotions, reviews, faqs, settings`.

## 5. Configuration (`.env`)

All secrets come from environment variables; nothing secret is in frontend code or the admin UI.

| Variable | Purpose |
|---|---|
| `APP_URL` | Public URL, e.g. `https://your-domain.com` — used for payment callbacks and reset links |
| `NODE_ENV=production` | Turns on Secure cookies + HSTS (needs HTTPS) |
| `TRUST_PROXY=1` | Set when behind Nginx/Caddy so rate limiting sees real client IPs |
| `DB_PATH`, `UPLOAD_DIR` | Keep both on persistent storage |
| `SMTP_*` | Password-reset emails. Without SMTP the reset link is only printed in the server log |
| `BKASH_BASE_URL`, `BKASH_APP_KEY`, `BKASH_APP_SECRET`, `BKASH_USERNAME`, `BKASH_PASSWORD` | bKash tokenized-checkout credentials from your bKash merchant onboarding |

### Enabling the bKash online gateway
1. Get sandbox credentials from bKash, put them in `.env` (sandbox `BKASH_BASE_URL` is pre-filled in `.env.example`), set `APP_URL` to a **public HTTPS** URL (bKash must be able to redirect to it), restart.
2. *Admin → Payment methods → "bKash (Online Payment)"* now shows credentials detected → switch **Enabled** on.
3. Make a sandbox payment end-to-end. Check the field names/endpoints in `server/services/providers/bkash.js` against the documentation bKash gave you.
4. Only then switch `BKASH_BASE_URL` to the live URL with your live credentials.

If a customer pays but the page doesn't update, the order page has **Re-check payment**, and admins have **Re-check with provider** on the order.

## 6. Security measures included

scrypt-hashed passwords · random server-side sessions stored hashed, `HttpOnly` + `SameSite=Lax` cookies · CSRF defence (custom header + origin check) · role checks on every admin route · login / registration / reset / order rate limiting · no account-existence leaks on login or reset · single-use 1-hour reset tokens that sign out all sessions · parameterised SQL only · server-side validation of every field and **prices read only from the database** · text rendered as text nodes (no HTML injection) · strict Content-Security-Policy and other security headers · uploads restricted to real PNG/JPG/WEBP/GIF by content sniffing · path-traversal protection · the site never asks for a game password.

## 7. Deploying (Ubuntu VPS + Caddy)

```bash
# 1. server prep (Node 22 – e.g. from nodesource.com or nvm)
sudo adduser --system --group --home /opt/gamezone-bd gamezone
# 2. copy the project to /opt/gamezone-bd (git clone / scp), then:
cd /opt/gamezone-bd && sudo -u gamezone cp .env.example .env && sudo -u gamezone nano .env
#    set NODE_ENV=production, APP_URL=https://your-domain.com, TRUST_PROXY=1, SMTP_*, BKASH_* …
sudo -u gamezone npm run setup && sudo -u gamezone npm run create-admin
# 3. run as a service
sudo cp deploy/gamezone.service /etc/systemd/system/ && sudo systemctl enable --now gamezone
# 4. HTTPS reverse proxy
sudo apt install caddy && sudo cp deploy/Caddyfile /etc/caddy/Caddyfile   # edit the domain first
sudo systemctl reload caddy
```
Point your domain's DNS **A record** at the server before step 4. Check logs with `journalctl -u gamezone -f`.

**Docker alternative:** `docker build -t gamezone-bd .` then
`docker run -d --name gamezone -p 3000:3000 -v gamezone-data:/data --env-file .env gamezone-bd`
(put it behind HTTPS), and create the admin with
`docker exec -it gamezone node --disable-warning=ExperimentalWarning scripts/create-admin.js`.

**Backups:** `deploy/backup.sh` writes a consistent database snapshot + uploads archive; run it daily from cron and copy the result off the server.

**Scaling note:** SQLite and the in-memory rate limiter are designed for a single server process — right for a shop of this kind. If you ever need several servers, move to PostgreSQL and a shared rate-limit store.

## 8. Project layout

```
server/            API (lib/ http+validation, services/ auth·orders·payments·mail, routes/ public·auth·orders·admin)
public/            storefront SPA (js/, css/, img/) and admin app (admin/)
scripts/           migrate · seed · create-admin · gen-art
deploy/            systemd unit, Caddyfile, backup script
test/e2e.test.js   22 end-to-end tests (auth, authorization, purchase flow, payment-trust rules, admin CRUD)
```

## 9. Order lifecycle

`Pending` → (customer submits TrxID) `Payment Submitted` → (admin verifies / gateway confirms) `Processing` → (you deliver) `Completed`.
Also `Cancelled` (unpaid orders only) and `Refunded` (paid orders only). The admin cannot set *Processing/Completed* on an unpaid order, and every change is recorded in the order's activity log with who did it.
You are responsible for actually sending refunds through your payment account when you mark an order Refunded.

## 10. Legal / business notes

Top-up resale terms, refund policy, and consumer/e-commerce rules in Bangladesh (including any trade-licence and payment-provider merchant requirements) are your responsibility — check them before launching. This project is not affiliated with Garena, Krafton/PUBG, Moonton, or any game publisher; the footer says so.
