#!/bin/sh
# Consistent online backup of the database + uploaded images. Run daily from cron and copy the result OFF the server.
#   0 3 * * *  /opt/gamezone-bd/deploy/backup.sh
set -eu
APP=/opt/gamezone-bd
OUT=${1:-$APP/backups}
STAMP=$(date +%Y%m%d-%H%M%S)
mkdir -p "$OUT"
cd "$APP"
# node:sqlite's VACUUM INTO produces a safe, consistent snapshot even while the site is running
node --disable-warning=ExperimentalWarning -e "
const { DatabaseSync } = require('node:sqlite');
const db = new DatabaseSync(process.env.DB_PATH || 'data/gamezone.db');
db.exec(\"VACUUM INTO '$OUT/gamezone-$STAMP.db'\");
"
[ -d data/uploads ] && tar -czf "$OUT/uploads-$STAMP.tar.gz" -C data uploads || true
# keep the newest 14 snapshots
ls -1t "$OUT"/gamezone-*.db 2>/dev/null | tail -n +15 | xargs -r rm -f
echo "Backup written to $OUT"
