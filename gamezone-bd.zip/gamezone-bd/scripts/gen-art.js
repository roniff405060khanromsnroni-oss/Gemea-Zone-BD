'use strict';
// Generates GAMEZONE BD's original SVG artwork: logo, game thumbnails, banners and product icons.
// Run:  npm run art     (output is already committed in public/img – only re-run if you change this file)
// The game art is abstract and original; replace it with licensed official artwork from Admin → Games.
const fs = require('node:fs');
const path = require('node:path');

const OUT = path.join(__dirname, '..', 'public', 'img');
const write = (rel, svg) => { const f = path.join(OUT, rel); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, svg.trim() + '\n'); };

// ───────────── building blocks ─────────────
const grad = (id, stops, { x1 = 0, y1 = 0, x2 = 1, y2 = 1 } = {}) =>
  `<linearGradient id="${id}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}">${stops.map(([o, c, a = 1]) => `<stop offset="${o}" stop-color="${c}" stop-opacity="${a}"/>`).join('')}</linearGradient>`;
const radial = (id, stops) =>
  `<radialGradient id="${id}">${stops.map(([o, c, a = 1]) => `<stop offset="${o}" stop-color="${c}" stop-opacity="${a}"/>`).join('')}</radialGradient>`;
const blur = (id, s) => `<filter id="${id}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="${s}"/></filter>`;

/** Faceted gem centred at (cx,cy) with width s. colours = [light, mid, dark] */
function gem(cx, cy, s, [l, m, d], uid) {
  const P = (x, y) => `${(cx + x * s).toFixed(1)},${(cy + y * s).toFixed(1)}`;
  const A = P(-0.5, -0.2), B = P(-0.27, -0.5), C = P(0.27, -0.5), D = P(0.5, -0.2), E = P(0, 0.55), F = P(-0.2, -0.2), G = P(0.2, -0.2);
  const poly = (pts, fill, op = 1) => `<polygon points="${pts.join(' ')}" fill="${fill}" fill-opacity="${op}"/>`;
  return `<g>
    ${poly([B, C, G, F], l)}
    ${poly([A, B, F], m)}
    ${poly([C, D, G], m)}
    ${poly([A, F, E], d)}
    ${poly([F, G, E], m)}
    ${poly([G, D, E], d)}
    <polyline points="${[A, B, C, D, E, A].join(' ')}" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="${Math.max(1, s * 0.025).toFixed(1)}" stroke-linejoin="round"/>
    <polygon points="${[B, C, G, F].join(' ')}" fill="url(#${uid})" opacity=".55"/>
  </g>`;
}

const LAYOUTS = { // gem layouts per tier: [x, y, size] in a 240×240 tile
  1: [[120, 122, 92]],
  2: [[88, 132, 78], [152, 118, 84]],
  3: [[84, 140, 70], [158, 140, 70], [121, 100, 84]],
  4: [[82, 146, 68], [158, 146, 68], [100, 100, 78], [150, 98, 78]],
  5: [[72, 156, 62], [120, 160, 66], [168, 156, 62], [92, 108, 74], [148, 106, 74], [120, 68, 62]],
};

function productTile(file, kind, tier, palette) {
  const id = `p${Math.random().toString(36).slice(2, 7)}`;
  const [c1, c2, c3] = palette;
  let body = '';
  if (kind === 'gem') {
    body = LAYOUTS[tier].map(([x, y, s]) => gem(x, y, s, [c1, c2, c3], `${id}sh`)).join('');
  } else if (kind === 'coin') {
    const coin = (x, y, r) => `<g><circle cx="${x}" cy="${y}" r="${r}" fill="url(#${id}c)"/><circle cx="${x}" cy="${y}" r="${r * 0.78}" fill="none" stroke="#fff" stroke-opacity=".5" stroke-width="2"/>
      <text x="${x}" y="${y + r * 0.22}" font-family="Arial,Helvetica,sans-serif" font-weight="900" font-size="${r * 0.62}" text-anchor="middle" fill="#7c4a03" fill-opacity=".85">UC</text></g>`;
    body = LAYOUTS[tier].map(([x, y, s]) => coin(x, y, s * 0.5)).join('');
  } else if (kind === 'card') {
    const label = tier === 'weekly' ? '7' : '30';
    body = `<g transform="rotate(-6 120 120)"><rect x="44" y="66" width="152" height="104" rx="16" fill="url(#${id}c)"/>
      <rect x="44" y="66" width="152" height="104" rx="16" fill="none" stroke="#fff" stroke-opacity=".5" stroke-width="2"/>
      <rect x="60" y="82" width="38" height="26" rx="6" fill="#fff" fill-opacity=".35"/>
      <text x="62" y="152" font-family="Arial,Helvetica,sans-serif" font-weight="900" font-size="44" fill="#fff">${label}<tspan font-size="20" dy="-2"> DAYS</tspan></text></g>`;
  } else if (kind === 'bundle') {
    body = `<g><rect x="56" y="112" width="128" height="72" rx="12" fill="url(#${id}c)"/>
      <rect x="48" y="90" width="144" height="34" rx="10" fill="${c1}"/>
      <rect x="108" y="90" width="24" height="94" fill="#fff" fill-opacity=".45"/>
      ${gem(120, 66, 56, [c1, c2, c3], `${id}sh`)}</g>`;
  } else if (kind === 'pass') {
    body = `<g transform="rotate(8 120 120)"><path d="M44 78h152v26a14 14 0 0 0 0 28v26H44v-26a14 14 0 0 0 0-28z" fill="url(#${id}c)"/>
      <path d="M120 98l8 17 18 2-13 12 4 18-17-9-17 9 4-18-13-12 18-2z" fill="#fff" fill-opacity=".9"/></g>`;
  }
  write(file, `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 240" role="img">
  <defs>${radial(`${id}bg`, [[0, '#26307a'], [1, '#0b0f24']])}${radial(`${id}glow`, [[0, c2, 0.55], [1, c2, 0]])}
  ${grad(`${id}c`, [[0, c1], [1, c3]])}${grad(`${id}sh`, [[0, '#fff', 0.9], [1, '#fff', 0]], { x1: 0, y1: 0, x2: 0.6, y2: 1 })}</defs>
  <rect width="240" height="240" fill="url(#${id}bg)"/>
  <circle cx="120" cy="124" r="104" fill="url(#${id}glow)"/>
  ${body}
</svg>`);
}

const BLUE = ['#9be7ff', '#38bdf8', '#4f46e5'];
const PURPLE = ['#f0abfc', '#c084fc', '#7c3aed'];
const GOLD = ['#fde68a', '#fbbf24', '#d97706'];
const GREEN = ['#a7f3d0', '#34d399', '#0d9488'];

for (let t = 1; t <= 5; t++) {
  productTile(`products/diamond-${t}.svg`, 'gem', t, BLUE);
  productTile(`products/gem-${t}.svg`, 'gem', t, PURPLE);
  productTile(`products/uc-${t}.svg`, 'coin', t, GOLD);
}
productTile('products/card-weekly.svg', 'card', 'weekly', GREEN);
productTile('products/card-monthly.svg', 'card', 'monthly', PURPLE);
productTile('products/bundle.svg', 'bundle', 0, BLUE);
productTile('products/pass.svg', 'pass', 0, GOLD);

// ───────────── game art (abstract, original) ─────────────
function scene(kind, w, h, theme) {
  const id = `s${kind}${w}`;
  const { a, b, c } = theme;
  let deco = '';
  const cx = w * 0.62, cy = h * 0.5, u = Math.min(w, h);
  if (kind === 'ff') { // sunset + big gems + sharp blades
    deco = `<circle cx="${cx}" cy="${cy}" r="${u * 0.42}" fill="url(#${id}sun)"/>
      ${[0, 1, 2, 3, 4, 5].map((i) => `<polygon points="${w * (0.05 + i * 0.17)},${h} ${w * (0.1 + i * 0.17)},${h * (0.7 - (i % 3) * 0.08)} ${w * (0.15 + i * 0.17)},${h}" fill="#fff" fill-opacity=".05"/>`).join('')}
      ${gem(cx, cy, u * 0.62, ['#ffe4c2', '#ff9d4d', '#d9345b'], `${id}sh`)}
      ${gem(w * 0.24, h * 0.78, u * 0.22, ['#ffe4c2', '#ff9d4d', '#d9345b'], `${id}sh`)}`;
  } else if (kind === 'pubg') { // crosshair + hex grid
    const hex = (x, y, r) => `<polygon points="${[0, 1, 2, 3, 4, 5].map((i) => `${(x + r * Math.cos(Math.PI / 3 * i)).toFixed(1)},${(y + r * Math.sin(Math.PI / 3 * i)).toFixed(1)}`).join(' ')}" fill="none" stroke="#fff" stroke-opacity=".08" stroke-width="2"/>`;
    deco = `${Array.from({ length: 30 }, (_, i) => hex((i % 6) * u * 0.26 + (Math.floor(i / 6) % 2) * u * 0.13, Math.floor(i / 6) * u * 0.23 + 10, u * 0.14)).join('')}
      <g transform="translate(${cx} ${cy})" stroke="#fff" fill="none" stroke-linecap="round">
        <circle r="${u * 0.34}" stroke-opacity=".9" stroke-width="${u * 0.025}"/><circle r="${u * 0.2}" stroke-opacity=".5" stroke-width="${u * 0.012}"/>
        <path d="M0 ${-u * 0.46}V${-u * 0.16}M0 ${u * 0.16}V${u * 0.46}M${-u * 0.46} 0H${-u * 0.16}M${u * 0.16} 0H${u * 0.46}" stroke-width="${u * 0.03}"/>
        <circle r="${u * 0.03}" fill="${c}" stroke="none"/></g>`;
  } else { // mlbb: crest + lightning
    deco = `<g transform="translate(${cx} ${cy})"><path d="M0 ${-u * 0.46}L${u * 0.34} ${-u * 0.3}V${u * 0.08}Q${u * 0.34} ${u * 0.34} 0 ${u * 0.5}Q${-u * 0.34} ${u * 0.34} ${-u * 0.34} ${u * 0.08}V${-u * 0.3}Z" fill="url(#${id}crest)" stroke="#fff" stroke-opacity=".7" stroke-width="${u * 0.014}"/>
      <path d="M${u * 0.06} ${-u * 0.3}L${-u * 0.14} ${u * 0.04}H${-u * 0.01}L${-u * 0.08} ${u * 0.32}L${u * 0.16} ${-u * 0.08}H${u * 0.02}Z" fill="#fff" fill-opacity=".92"/></g>
      ${[0, 1, 2, 3].map((i) => `<polygon points="${w * (0.08 + i * 0.12)},${h} ${w * (0.14 + i * 0.12)},${h * 0.62} ${w * (0.2 + i * 0.12)},${h}" fill="#fff" fill-opacity=".05"/>`).join('')}`;
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="xMidYMid slice" role="img">
  <defs>${grad(`${id}bg`, [[0, a], [0.55, b], [1, '#070a14']], { x1: 0, y1: 0, x2: 0.8, y2: 1 })}
  ${radial(`${id}sun`, [[0, c, 0.9], [0.6, c, 0.25], [1, c, 0]])}${blur(`${id}bl`, u * 0.06)}
  ${grad(`${id}crest`, [[0, c], [1, a]], { x1: 0, y1: 0, x2: 0, y2: 1 })}
  ${grad(`${id}sh`, [[0, '#fff', 0.9], [1, '#fff', 0]], { x1: 0, y1: 0, x2: 0.6, y2: 1 })}</defs>
  <rect width="${w}" height="${h}" fill="url(#${id}bg)"/>
  <circle cx="${cx}" cy="${cy}" r="${u * 0.5}" fill="${c}" opacity=".35" filter="url(#${id}bl)"/>
  ${deco}
  <rect width="${w}" height="${h}" fill="url(#${id}fade)"/>
  <defs>${grad(`${id}fade`, [[0, '#070a14', 0], [1, '#070a14', 0.55]], { x1: 0, y1: 0.4, x2: 0, y2: 1 })}</defs>
</svg>`;
}

const THEMES = {
  'free-fire': ['ff', { a: '#5a1230', b: '#241041', c: '#ff7a3d' }],
  'pubg-mobile': ['pubg', { a: '#0f3d4a', b: '#0f1d3a', c: '#2dd4bf' }],
  'mobile-legends': ['mlbb', { a: '#2a1a73', b: '#16113d', c: '#a78bfa' }],
};
for (const [slug, [kind, theme]] of Object.entries(THEMES)) {
  write(`games/${slug}.svg`, scene(kind, 480, 600, theme));
  write(`banners/${slug}.svg`, scene(kind, 1200, 420, theme));
}

// ───────────── GAMEZONE BD logo ─────────────
const hexPath = 'M32 3 57 17.5v29L32 61 7 46.5v-29z';
const gPath = 'M43.4 23.2A14.5 14.5 0 1 0 46.5 32.5H33.5';
const mark = (uid) => `<defs>${grad(`${uid}g`, [[0, '#3b82ff'], [1, '#8b5cf6']])}${grad(`${uid}s`, [[0, '#22d3ee'], [1, '#a78bfa']])}</defs>
  <path d="${hexPath}" fill="url(#${uid}g)"/>
  <path d="${hexPath}" fill="none" stroke="url(#${uid}s)" stroke-width="1.6" stroke-linejoin="round" opacity=".9"/>
  <path d="${gPath}" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M40 15.5 34.5 25h5L35 34" fill="none" stroke="#22d3ee" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" opacity="0"/>
  <polygon points="48,14 51,19 48,24 45,19" fill="#22d3ee"/>`;

write('logo-mark.svg', `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" role="img" aria-label="GAMEZONE BD">${mark('m')}</svg>`);
write('../favicon.svg', `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">${mark('f')}</svg>`);
write('logo.svg', `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 392 64" role="img" aria-label="GAMEZONE BD">
  <g>${mark('l')}</g>
  <defs>${grad('lt', [[0, '#22d3ee'], [1, '#a78bfa']], { x1: 0, y1: 0, x2: 1, y2: 0 })}</defs>
  <text x="76" y="38" font-family="'Segoe UI',Arial,Helvetica,sans-serif" font-weight="800" font-size="30" letter-spacing="1.5" fill="#f1f4ff">GAMEZONE<tspan fill="url(#lt)"> BD</tspan></text>
  <text x="77" y="55" font-family="'Segoe UI',Arial,Helvetica,sans-serif" font-weight="600" font-size="10.5" letter-spacing="2.6" fill="#8e98c4">YOUR GAMING TOP-UP DESTINATION</text>
</svg>`);

console.log('Artwork written to public/img');
