'use strict';
const { migrate } = require('../server/db');

const applied = migrate();
console.log(applied.length ? `Applied migrations: ${applied.join(', ')}` : 'Database is up to date.');
