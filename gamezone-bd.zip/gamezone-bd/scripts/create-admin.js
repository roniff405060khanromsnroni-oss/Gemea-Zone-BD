'use strict';
// Create (or promote) an administrator.
//   npm run create-admin -- --email you@example.com --name "Your Name"
// The password is typed interactively (hidden). For automation you may set ADMIN_PASSWORD in the environment.
const readline = require('node:readline');
const { migrate, get, run } = require('../server/db');
const { hashPassword } = require('../server/services/auth');
const { EMAIL_RE } = require('../server/lib/validate');

function arg(name) {
  const i = process.argv.indexOf(`--${name}`);
  return i > -1 ? process.argv[i + 1] : undefined;
}

function ask(question, { hidden = false } = {}) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: hidden });
    if (hidden) {
      rl._writeToOutput = (s) => { if (s.includes(question)) rl.output.write(s); else rl.output.write('*'); };
    }
    rl.question(question, (a) => { rl.close(); if (hidden) process.stdout.write('\n'); resolve(a.trim()); });
  });
}

(async () => {
  migrate();
  const email = (arg('email') || (await ask('Admin email: '))).toLowerCase();
  if (!EMAIL_RE.test(email)) { console.error('That is not a valid email address.'); process.exit(1); }
  const existing = get('SELECT * FROM users WHERE email = ?', email);
  const name = arg('name') || existing?.name || (await ask('Display name: ')) || 'Administrator';

  const password = process.env.ADMIN_PASSWORD || (await ask('Password (min 10 chars): ', { hidden: true }));
  if (password.length < 10) { console.error('Use at least 10 characters for an admin password.'); process.exit(1); }
  if (!process.env.ADMIN_PASSWORD && password !== (await ask('Repeat password: ', { hidden: true }))) { console.error('Passwords do not match.'); process.exit(1); }

  const hash = await hashPassword(password);
  if (existing) {
    run(`UPDATE users SET role = 'admin', status = 'active', password_hash = ?, name = ? WHERE id = ?`, hash, name, existing.id);
    console.log(`Updated ${email}: now an administrator with the new password.`);
  } else {
    run(`INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'admin')`, name, email, hash);
    console.log(`Administrator ${email} created. Sign in at /admin`);
  }
})();
