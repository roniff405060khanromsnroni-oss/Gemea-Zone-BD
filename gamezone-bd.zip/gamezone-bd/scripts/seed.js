'use strict';
// Loads starter content (games, sample packages, FAQs, payment-method slots). Safe to re-run: does nothing
// if games already exist.
//
// ⚠ Package PRICES below are SAMPLE values so the store is not empty. Set your real prices in
//   Admin → Products before going live. Payment methods are seeded DISABLED on purpose.
const { migrate, get, run, tx } = require('../server/db');

migrate();
if (get('SELECT COUNT(*) AS n FROM games').n > 0) {
  console.log('Games already exist – seed skipped.');
  process.exit(0);
}

const gem = (n) => `/img/products/diamond-${n}.svg`;
const ml = (n) => `/img/products/gem-${n}.svg`;
const uc = (n) => `/img/products/uc-${n}.svg`;

const games = [
  {
    slug: 'free-fire', name: 'Free Fire', currency_label: 'Diamonds', featured: 1,
    description: 'Top up Free Fire Diamonds, memberships and bundles with just your Player ID.',
    image_url: '/img/games/free-fire.svg', banner_url: '/img/banners/free-fire.svg',
    requires_server_id: 0, player_id_label: 'Player ID (UID)', player_id_pattern: '^[0-9]{8,12}$',
    categories: ['Diamond Top-Up', 'Weekly Membership', 'Monthly Membership', 'Special Bundles', 'Other Packages'],
    products: [
      ['Diamond Top-Up', '25 Diamonds', '25 Diamonds', gem(1), 22, null, 0],
      ['Diamond Top-Up', '50 Diamonds', '50 Diamonds', gem(1), 40, 45, 0],
      ['Diamond Top-Up', '115 Diamonds', '115 Diamonds', gem(2), 80, null, 1],
      ['Diamond Top-Up', '240 Diamonds', '240 Diamonds', gem(2), 160, null, 1],
      ['Diamond Top-Up', '355 Diamonds', '355 Diamonds', gem(3), 240, null, 0],
      ['Diamond Top-Up', '480 Diamonds', '480 Diamonds', gem(3), 320, null, 0],
      ['Diamond Top-Up', '610 Diamonds', '610 Diamonds', gem(4), 400, null, 0],
      ['Diamond Top-Up', '1240 Diamonds', '1240 Diamonds', gem(4), 800, 850, 1],
      ['Diamond Top-Up', '2530 Diamonds', '2530 Diamonds', gem(5), 1600, null, 0],
      ['Weekly Membership', 'Weekly Membership', '7 days', '/img/products/card-weekly.svg', 160, null, 1],
      ['Monthly Membership', 'Monthly Membership', '30 days', '/img/products/card-monthly.svg', 800, 900, 0],
      ['Special Bundles', 'Starter Bundle', 'Bundle', '/img/products/bundle.svg', 120, null, 0],
      ['Other Packages', 'Level Up Pass', 'Pass', '/img/products/pass.svg', 200, null, 0],
    ],
  },
  {
    slug: 'pubg-mobile', name: 'PUBG Mobile', currency_label: 'UC', featured: 1,
    description: 'Get PUBG Mobile UC delivered straight to your Player ID.',
    image_url: '/img/games/pubg-mobile.svg', banner_url: '/img/banners/pubg-mobile.svg',
    requires_server_id: 0, player_id_label: 'Player ID', player_id_pattern: '^[0-9]{8,12}$',
    categories: ['UC Top-Up'],
    products: [
      ['UC Top-Up', '60 UC', '60 UC', uc(1), 90, null, 0],
      ['UC Top-Up', '325 UC', '325 UC', uc(2), 450, null, 1],
      ['UC Top-Up', '660 UC', '660 UC', uc(3), 900, 950, 1],
      ['UC Top-Up', '1800 UC', '1800 UC', uc(4), 2250, null, 0],
      ['UC Top-Up', '3850 UC', '3850 UC', uc(5), 4500, null, 0],
    ],
  },
  {
    slug: 'mobile-legends', name: 'Mobile Legends', currency_label: 'Diamonds', featured: 1,
    description: 'Mobile Legends Diamonds and Weekly Pass – enter your User ID and Zone ID.',
    image_url: '/img/games/mobile-legends.svg', banner_url: '/img/banners/mobile-legends.svg',
    requires_server_id: 1, player_id_label: 'User ID', server_id_label: 'Zone ID',
    player_id_pattern: '^[0-9]{6,12}$', server_id_pattern: '^[0-9]{3,6}$',
    categories: ['Diamond Top-Up', 'Weekly Pass'],
    products: [
      ['Diamond Top-Up', '56 Diamonds', '56 Diamonds', ml(1), 80, null, 0],
      ['Diamond Top-Up', '172 Diamonds', '172 Diamonds', ml(2), 240, null, 1],
      ['Diamond Top-Up', '257 Diamonds', '257 Diamonds', ml(3), 360, null, 0],
      ['Diamond Top-Up', '706 Diamonds', '706 Diamonds', ml(4), 960, 1000, 1],
      ['Weekly Pass', 'Weekly Diamond Pass', '7 days', '/img/products/card-weekly.svg', 150, null, 0],
    ],
  },
];

const paymentMethods = [
  ['bkash', 'bKash (Send Money)', 'manual', '', '#e2136e', 'Open the bKash app → Send Money (or Payment) → enter the number above → enter the exact amount → confirm. Then submit your Transaction ID below.'],
  ['bkash-gateway', 'bKash (Online Payment)', 'gateway', 'bkash', '#e2136e', 'You will be redirected to bKash to approve the payment securely.'],
  ['nagad', 'Nagad', 'manual', '', '#f6921e', 'Open the Nagad app → Send Money → enter the number above → enter the exact amount → confirm. Then submit your Transaction ID below.'],
  ['rocket', 'Rocket', 'manual', '', '#8c3494', 'Dial *322# or open the Rocket app → Send Money → enter the number above → enter the exact amount → confirm. Then submit your Transaction ID below.'],
];

const faqs = [
  ['How do I top up my game?', 'Pick your game, choose a package, enter your Player ID (and Server/Zone ID if asked), select a payment method and place the order. After your payment is verified we process the top-up and you can follow every step on the Track Order page.'],
  ['Do you need my game password?', 'Never. We only ask for your Player ID (and Server/Zone ID where the game uses one). Anyone who asks you for your password is not us – do not share it.'],
  ['Which payment methods can I use?', 'bKash, Nagad and Rocket, depending on what is currently enabled in the checkout. After paying, you submit the Transaction ID so we can verify the payment.'],
  ['When is my order marked as paid?', 'Only after the payment is confirmed – either automatically by the payment gateway, or by our team checking the Transaction ID against our account. A screenshot alone never marks an order as paid.'],
  ['I entered the wrong Player ID. What now?', 'Contact support immediately with your Order ID. Once a top-up has been delivered to an account it usually cannot be reversed, so please double-check your ID before paying.'],
  ['How can I check my order status?', 'Use the Track Order page with your Order ID, or open Orders in your account to see all your orders and their current status.'],
  ['What if my order is cancelled or refunded?', 'If we cannot complete an order, its status changes to Cancelled or Refunded and any verified payment is returned using the method it was paid with. Contact support if you have questions about a specific order.'],
];

const banners = [
  ['Free Fire Diamonds', 'Enter your Player ID and top up in a few taps', '/img/banners/free-fire.svg', '#/game/free-fire'],
  ['PUBG Mobile UC', 'Get UC for your next season', '/img/banners/pubg-mobile.svg', '#/game/pubg-mobile'],
  ['Mobile Legends Diamonds', 'Top up with your User ID and Zone ID', '/img/banners/mobile-legends.svg', '#/game/mobile-legends'],
];

const promotions = [
  ['Safe by design', 'We only ever ask for your Player ID – never your game password.', 'Secure', ''],
  ['Track every order', 'Follow your order from payment to delivery with your Order ID.', 'Tracking', '#/track'],
];

tx(() => {
  games.forEach((g, gi) => {
    const r = run(
      `INSERT INTO games (slug, name, description, image_url, banner_url, currency_label, requires_server_id, player_id_label,
                          server_id_label, player_id_pattern, server_id_pattern, featured, active, sort_order)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,?)`,
      g.slug, g.name, g.description, g.image_url, g.banner_url, g.currency_label, g.requires_server_id, g.player_id_label,
      g.server_id_label || 'Server ID', g.player_id_pattern || '', g.server_id_pattern || '', g.featured, gi);
    const gameId = Number(r.lastInsertRowid);
    const catId = {};
    g.categories.forEach((c, ci) => { catId[c] = Number(run('INSERT INTO categories (game_id, name, sort_order) VALUES (?,?,?)', gameId, c, ci).lastInsertRowid); });
    g.products.forEach(([cat, name, qty, img, price, old, popular], pi) => {
      run(`INSERT INTO products (game_id, category_id, name, quantity_label, image_url, price_bdt, old_price_bdt, popular, sort_order)
           VALUES (?,?,?,?,?,?,?,?,?)`, gameId, catId[cat], name, qty, img, price, old, popular, pi);
    });
  });
  paymentMethods.forEach(([code, name, type, provider, color, instructions], i) =>
    run(`INSERT INTO payment_methods (code, name, type, gateway_provider, brand_color, instructions, enabled, sort_order) VALUES (?,?,?,?,?,?,0,?)`,
      code, name, type, provider, color, instructions, i));
  faqs.forEach(([q, a], i) => run('INSERT INTO faqs (question, answer, sort_order) VALUES (?,?,?)', q, a, i));
  banners.forEach(([t, s, img, link], i) => run('INSERT INTO banners (title, subtitle, image_url, link_url, sort_order) VALUES (?,?,?,?,?)', t, s, img, link, i));
  promotions.forEach(([t, d, b, l], i) => run('INSERT INTO promotions (title, description, badge, link_url, sort_order) VALUES (?,?,?,?,?)', t, d, b, l, i));
});

console.log('Seeded games, packages (SAMPLE prices), payment-method slots (disabled), FAQs, banners and promotions.');
console.log('Next: npm run create-admin  →  sign in at /admin  →  set prices, receiving numbers and enable payment methods.');
