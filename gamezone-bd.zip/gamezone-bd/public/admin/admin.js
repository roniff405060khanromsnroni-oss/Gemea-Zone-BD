import { h, mount, icon, money, fmtDate, safeUrl, toast, withBusy, statusBadge, spinner, debounce, $ } from '/js/util.js';
import { api, uploadImage } from '/js/api.js';

const app = $('#app');
let me = null;
let lookups = { games: [], categories: [] };
let badge = 0;

// ───────────── resource definitions (mirror the server-side schemas) ─────────────
const T = (key, label, extra = {}) => ({ key, label, type: 'text', ...extra });
const N = (key, label, extra = {}) => ({ key, label, type: 'number', ...extra });
const B = (key, label, extra = {}) => ({ key, label, type: 'bool', ...extra });
const IMG = (key, label, extra = {}) => ({ key, label, type: 'image', ...extra });
const SORT = N('sort_order', 'Sort order', { default: 0, hint: 'Lower numbers appear first' });

const RES = {
  games: {
    title: 'Games', singular: 'game', canAdd: true,
    fields: [T('name', 'Game name', { required: true, full: true }), T('slug', 'URL slug', { hint: 'Leave empty to generate from the name' }), T('currency_label', 'Currency label', { default: 'Credits', hint: 'e.g. Diamonds, UC' }),
      { key: 'description', label: 'Description', type: 'textarea', full: true }, IMG('image_url', 'Thumbnail image'), IMG('banner_url', 'Banner image'),
      B('requires_server_id', 'Requires Server / Zone ID'), T('player_id_label', 'Player ID label', { default: 'Player ID' }), T('server_id_label', 'Server ID label', { default: 'Server ID' }),
      T('player_id_pattern', 'Player ID pattern (regex)', { hint: 'Optional, e.g. ^[0-9]{8,12}$' }), T('server_id_pattern', 'Server ID pattern (regex)', { hint: 'Optional' }), B('featured', 'Featured on homepage'), B('active', 'Visible in store', { default: 1 }), SORT],
    cols: [['image_url', 'img'], ['name', 'Game', (r) => h('div', null, h('b', null, r.name), h('div', { class: 'tag' }, `/${r.slug}`))], ['currency_label', 'Currency'], ['featured', 'Featured', yesno], ['active', 'Status', activePill], ['sort_order', 'Order']],
  },
  categories: {
    title: 'Categories', singular: 'category', canAdd: true,
    fields: [{ key: 'game_id', label: 'Game', type: 'select', source: 'games', required: true }, T('name', 'Category name', { required: true }), SORT],
    cols: [['game_name', 'Game'], ['name', 'Category'], ['sort_order', 'Order']],
  },
  products: {
    title: 'Top-up Products', singular: 'product', canAdd: true, filterGame: true,
    fields: [{ key: 'game_id', label: 'Game', type: 'select', source: 'games', required: true }, { key: 'category_id', label: 'Category', type: 'select', source: 'categories', dependsOn: 'game_id', optional: true },
      T('name', 'Product name', { required: true, full: true }), T('quantity_label', 'Quantity label', { hint: 'e.g. 240 Diamonds' }), IMG('image_url', 'Product image'),
      N('price_bdt', 'Price (৳)', { required: true, min: 1 }), N('old_price_bdt', 'Old price (৳)', { optional: true, hint: 'Shows a discount badge when higher than the price' }),
      B('available', 'Available for purchase', { default: 1 }), B('popular', 'Show in Popular Top-Ups'), SORT],
    cols: [['image_url', 'img'], ['name', 'Product', (r) => h('div', null, h('b', null, r.name), h('div', { class: 'tag' }, `${r.game_name}${r.category_name ? ` · ${r.category_name}` : ''}`))], ['price_bdt', 'Price', (r) => h('div', null, h('b', null, money(r.price_bdt)), r.old_price_bdt ? h('s', { class: 'tag' }, ` ${money(r.old_price_bdt)}`) : null)], ['available', 'Stock', (r, reload) => toggleCell('products', r, 'available', reload)], ['popular', 'Popular', yesno]],
  },
  banners: {
    title: 'Homepage Banners', singular: 'banner', canAdd: true,
    fields: [T('title', 'Title', { required: true, full: true }), T('subtitle', 'Subtitle', { full: true }), IMG('image_url', 'Banner image (≈1200×420)', { full: true }), T('link_url', 'Link', { hint: 'e.g. #/game/free-fire or https://…', full: true }), B('active', 'Active', { default: 1 }), SORT],
    cols: [['image_url', 'img'], ['title', 'Title'], ['link_url', 'Link'], ['active', 'Status', (r, reload) => toggleCell('banners', r, 'active', reload)], ['sort_order', 'Order']],
  },
  promotions: {
    title: 'Promotions', singular: 'promotion', canAdd: true,
    fields: [T('title', 'Title', { required: true, full: true }), { key: 'description', label: 'Description', type: 'textarea', full: true }, T('badge', 'Badge text', { hint: 'e.g. Hot, -10%' }), T('link_url', 'Link'), B('active', 'Active', { default: 1 }), SORT],
    cols: [['title', 'Title'], ['badge', 'Badge'], ['active', 'Status', (r, reload) => toggleCell('promotions', r, 'active', reload)], ['sort_order', 'Order']],
  },
  reviews: {
    title: 'Customer Reviews', singular: 'review', canAdd: false,
    note: 'Reviews come from customers with a completed order. Approve the ones you want shown on the homepage.',
    fields: [T('name', 'Name', { required: true }), N('rating', 'Rating (1–5)', { required: true, min: 1 }), { key: 'comment', label: 'Review', type: 'textarea', full: true, required: true }, B('approved', 'Approved (visible on site)')],
    cols: [['name', 'Customer'], ['rating', 'Rating', (r) => '★'.repeat(r.rating) + '☆'.repeat(5 - r.rating)], ['comment', 'Review', (r) => h('span', { class: 'small' }, r.comment.length > 90 ? `${r.comment.slice(0, 90)}…` : r.comment)], ['approved', 'Approved', (r, reload) => toggleCell('reviews', r, 'approved', reload)], ['created_at', 'Date', (r) => fmtDate(r.created_at).split(',')[0]]],
  },
  faqs: {
    title: 'FAQs', singular: 'FAQ', canAdd: true,
    fields: [T('question', 'Question', { required: true, full: true }), { key: 'answer', label: 'Answer', type: 'textarea', full: true, required: true }, B('active', 'Active', { default: 1 }), SORT],
    cols: [['question', 'Question'], ['active', 'Status', (r, reload) => toggleCell('faqs', r, 'active', reload)], ['sort_order', 'Order']],
  },
  payment_methods: {
    title: 'Payment Methods', singular: 'payment method', canAdd: true, canDelete: true,
    fields: [T('name', 'Display name', { required: true }), T('code', 'Code', { required: true, hint: 'Lowercase, e.g. bkash, nagad, rocket, upay' }),
      { key: 'type', label: 'Type', type: 'select', options: [['manual', 'Manual – customer sends money, admin verifies TrxID'], ['gateway', 'Gateway – verified automatically by the provider']], required: true },
      { key: 'gateway_provider', label: 'Gateway provider (gateway type only)', type: 'select', options: [['', '—'], ['bkash', 'bKash (implemented)'], ['nagad', 'Nagad (not implemented)']], optional: true, hint: 'Credentials are set in the server .env file, never here.' },
      T('account_number', 'Receiving number (manual type)', { hint: 'The merchant/personal number customers send money to' }), T('brand_color', 'Brand colour', { default: '#6366f1', type: 'color' }),
      { key: 'instructions', label: 'Payment instructions shown to customers', type: 'textarea', full: true }, B('enabled', 'Enabled'), SORT],
    cols: [['name', 'Method', (r) => h('div', null, h('b', null, r.name), h('div', { class: 'tag' }, r.code))], ['type', 'Type', (r) => (r.type === 'gateway' ? `Gateway (${r.gateway_provider || '—'})` : 'Manual')], ['account_number', 'Number'],
      ['enabled', 'Enabled', (r, reload) => toggleCell('payment_methods', r, 'enabled', reload)],
      ['available', 'Live on checkout?', (r) => (r.available ? h('span', { class: 'pill on' }, 'Live') : h('span', { class: 'pill warn' }, r.enabled ? (r.type === 'gateway' ? 'Hidden – no gateway credentials' : 'Hidden – add receiving number') : 'Hidden – disabled'))]],
  },
};

function yesno(r, _, key) { return h('span', { class: `pill ${r[key] ? 'on' : 'off'}` }, r[key] ? 'Yes' : 'No'); }
function activePill(r) { return h('span', { class: `pill ${r.active ? 'on' : 'off'}` }, r.active ? 'Active' : 'Hidden'); }

function toggleCell(name, r, key, reload) {
  const cb = h('input', { type: 'checkbox', checked: !!r[key], 'aria-label': key, onchange: async () => {
    try { await api(`/admin/r/${name}/${r.id}`, { method: 'PUT', body: { [key]: cb.checked } }); toast('Saved', 'success'); await reload?.(); }
    catch (e) { cb.checked = !cb.checked; toast(e.message, 'error'); }
  } });
  return h('label', { class: 'switch' }, cb, h('i'));
}

// ───────────── generic modal + form ─────────────
function openModal(title, body, footer) {
  const prev = document.activeElement;
  const close = () => { box.remove(); document.removeEventListener('keydown', onKey); prev?.focus?.(); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  const box = h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': title, onclick: (e) => { if (e.target === box) close(); } },
    h('div', { class: 'modal-box' }, h('div', { class: 'modal-head' }, h('h2', null, title), h('button', { class: 'icon-btn', 'aria-label': 'Close', onclick: close }, icon('close', 18))), body, footer ? footer(close) : null));
  document.addEventListener('keydown', onKey);
  document.body.append(box);
  box.querySelector('input,select,textarea,button.btn')?.focus();
  return close;
}

function buildInput(f, value, form) {
  if (f.type === 'bool') { const c = h('input', { type: 'checkbox', checked: value === undefined ? !!f.default : !!value }); return { el: h('label', { class: 'check full' }, h('span', { class: 'switch' }, c, h('i')), f.label), get: () => c.checked }; }
  let inp;
  if (f.type === 'textarea') inp = h('textarea', { class: 'input', rows: 3, value: value ?? '' });
  else if (f.type === 'select') {
    inp = h('select', { class: 'input' });
    const fill = () => {
      const opts = f.options || optionsFor(f, form);
      inp.replaceChildren(...[f.optional ? [['', '— none —']] : [['', 'Select…']], opts].flat().map(([v, l]) => h('option', { value: v, selected: String(v) === String(inp.dataset.cur ?? value ?? '') }, l)));
    };
    inp.dataset.cur = value ?? ''; fill(); inp.addEventListener('change', () => { inp.dataset.cur = inp.value; });
    inp.refill = () => fill();
  } else if (f.type === 'image') return imageInput(f, value);
  else inp = h('input', { class: 'input', type: f.type === 'number' ? 'number' : f.type === 'color' ? 'color' : 'text', value: value ?? f.default ?? '', min: f.min, step: f.type === 'number' ? 1 : null });
  return { el: h('label', { class: `field${f.full ? ' full' : ''}` }, h('span', null, f.label), inp, f.hint ? h('small', { class: 'hint' }, f.hint) : null), get: () => inp.value, input: inp };
}

function optionsFor(f, form) {
  if (f.source === 'games') return lookups.games.map((g) => [g.id, g.name]);
  if (f.source === 'categories') { const gid = form?.game_id ? Number(form.game_id.get()) : null; return lookups.categories.filter((c) => !gid || c.game_id === gid).map((c) => [c.id, `${c.game_name} – ${c.name}`]); }
  return [];
}

function imageInput(f, value) {
  const url = h('input', { class: 'input', placeholder: 'https://… or upload →', value: value ?? '' });
  const prev = h('img', { alt: '', src: safeUrl(value) || '/img/logo-mark.svg' });
  url.addEventListener('input', () => { prev.src = safeUrl(url.value) || '/img/logo-mark.svg'; });
  const file = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp,image/gif', hidden: true, onchange: async () => {
    const f0 = file.files[0]; if (!f0) return;
    if (f0.size > 3_000_000) return toast('Image must be under 3 MB', 'error');
    try { url.value = await uploadImage(f0); prev.src = url.value; toast('Image uploaded', 'success'); } catch (e) { toast(e.message, 'error'); }
  } });
  return { el: h('div', { class: `field${f.full ? ' full' : ''}` }, h('span', null, f.label), h('div', { class: 'upl' }, prev, url, file, h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: () => file.click() }, 'Upload'))), get: () => url.value };
}

function openForm(name, def, row, onSaved) {
  const form = {};
  const grid = h('div', { class: 'fgrid two' });
  for (const f of def.fields) { const b = buildInput(f, row ? row[f.key] : undefined, form); form[f.key] = b; grid.append(b.el); }
  if (form.game_id && form.category_id) form.game_id.input.addEventListener('change', () => { form.category_id.input.dataset.cur = ''; form.category_id.input.refill(); });
  const err = h('div', { class: 'alert alert-error', hidden: true, role: 'alert' });
  openModal(`${row ? 'Edit' : 'Add'} ${def.singular}`, h('div', { class: 'modal-body' }, err, grid), (close) => h('div', { class: 'modal-foot' },
    h('button', { class: 'btn btn-ghost', type: 'button', onclick: close }, 'Cancel'),
    h('button', { class: 'btn btn-primary', type: 'button', onclick: async (e) => {
      err.hidden = true;
      const body = {};
      for (const f of def.fields) {
        const v = form[f.key].get();
        if (f.type === 'number') body[f.key] = v === '' ? (f.optional ? null : '') : Number(v);
        else if (f.type === 'select' && f.source) body[f.key] = v === '' ? (f.optional ? null : '') : Number(v);
        else body[f.key] = v;
      }
      await withBusy(e.currentTarget, async () => {
        try { await api(row ? `/admin/r/${name}/${row.id}` : `/admin/r/${name}`, { method: row ? 'PUT' : 'POST', body }); toast('Saved', 'success'); close(); await refreshLookups(); onSaved(); }
        catch (ex) { err.textContent = ex.message; err.hidden = false; }
      });
    } }, 'Save')));
}

async function refreshLookups() {
  const [g, c] = await Promise.all([api('/admin/r/games'), api('/admin/r/categories')]);
  lookups = { games: g.items, categories: c.items };
}

// ───────────── generic CRUD page ─────────────
async function crudPage(name) {
  const def = RES[name];
  const root = h('div');
  let rows = [];
  let gameFilter = '';
  const body = h('div');
  async function load() {
    const { items } = await api(`/admin/r/${name}`);
    rows = items; draw();
  }
  function draw() {
    const shown = gameFilter ? rows.filter((r) => String(r.game_id) === gameFilter) : rows;
    const head = h('tr', null, def.cols.map(([, label, fn]) => h('th', null, fn === undefined && label === 'img' ? '' : label)), h('th'));
    const trs = shown.map((r) => h('tr', null,
      def.cols.map(([key, label, fn]) => h('td', null, label === 'img' ? h('img', { class: 'thumb', src: safeUrl(r[key]) || '/img/logo-mark.svg', alt: '', loading: 'lazy' }) : fn ? (fn === yesno ? yesno(r, load, key) : fn(r, load, key)) : String(r[key] ?? ''))),
      h('td', null, h('div', { class: 'acts' },
        h('button', { class: 'btn btn-ghost btn-sm', onclick: () => openForm(name, def, r, load), 'aria-label': `Edit ${r.name || r.title || ''}` }, icon('edit', 15), ' Edit'),
        h('button', { class: 'btn btn-danger btn-sm', 'aria-label': 'Delete', onclick: async () => {
          const warn = name === 'games' ? 'Delete this game together with ALL its products and categories? Past orders keep their details.' : 'Delete this item?';
          if (!confirm(warn)) return;
          try { await api(`/admin/r/${name}/${r.id}`, { method: 'DELETE' }); toast('Deleted', 'success'); await refreshLookups(); await load(); } catch (e) { toast(e.message, 'error'); }
        } }, icon('trash', 15))))));
    mount(body, shown.length ? h('div', { class: 'tablewrap' }, h('table', { class: 't' }, h('thead', null, head), h('tbody', null, trs))) : h('div', { class: 'empty' }, h('h3', null, `No ${def.title.toLowerCase()} yet`), def.canAdd ? h('p', null, 'Use the Add button to create the first one.') : h('p', null, 'Nothing to show.')));
  }
  mount(root, def.note ? h('p', { class: 'muted' }, def.note) : null,
    h('div', { class: 'toolbar' },
      def.filterGame ? (() => { const s = h('select', { class: 'input', 'aria-label': 'Filter by game', onchange: () => { gameFilter = s.value; draw(); } }, h('option', { value: '' }, 'All games'), lookups.games.map((g) => h('option', { value: g.id }, g.name))); return s; })() : null,
      h('span', { class: 'grow' }), def.canAdd ? h('button', { class: 'btn btn-primary', onclick: () => openForm(name, def, null, load) }, icon('plus', 16), ` Add ${def.singular}`) : null),
    body, name === 'payment_methods' ? await gatewayInfo() : null);
  await load();
  return root;
}

async function gatewayInfo() {
  const sys = await api('/admin/system');
  return h('div', { class: 'card pad mt' }, h('h3', null, 'Gateway credentials'),
    h('p', { class: 'muted' }, 'API keys are never entered or shown in the dashboard. Put them in the server’s .env file (see .env.example) and restart the server. A gateway method only appears at checkout once its credentials exist.'),
    sys.gateways.map((g) => h('div', { class: 'sysrow' }, h('span', null, g.name), g.configured ? h('span', { class: 'pill on' }, 'Credentials detected') : h('span', { class: 'pill warn' }, g.key === 'nagad' ? 'Not implemented – use manual mode' : 'Not configured'))));
}

// ───────────── dashboard ─────────────
async function dashboardPage() {
  const s = await api('/admin/stats');
  const sys = await api('/admin/system');
  const max = Math.max(1, ...s.last_7_days.map((d) => d.orders));
  const stat = (label, val, hot) => h('div', { class: `card stat${hot ? ' hot' : ''}` }, h('span', null, label), h('b', null, val));
  return h('div', null,
    h('div', { class: 'stats' }, stat('Total Users', s.total_users), stat('Total Orders', s.total_orders), stat('Pending Orders', s.pending_orders, s.awaiting_verification > 0), stat('Completed Orders', s.completed_orders), stat('Total Revenue', money(s.total_revenue)), stat('Total Products', s.total_products)),
    s.awaiting_verification ? h('a', { class: 'alert alert-warn mt', href: '#/orders?payment_status=submitted' }, icon('alert', 18), h('span', null, `${s.awaiting_verification} payment${s.awaiting_verification > 1 ? 's are' : ' is'} waiting for your verification →`)) : null,
    h('div', { class: 'cols c2 mt' },
      h('div', { class: 'card pad' }, h('h3', null, 'Orders – last 7 days'), h('div', { class: 'bars' }, s.last_7_days.map((d) => h('div', { title: `${d.day}: ${d.orders} orders, ${money(d.revenue)} revenue` }, h('b', null, d.orders), h('i', { style: { '--p': Math.round((d.orders / max) * 95) } }), h('span', null, d.day.slice(5)))))),
      h('div', { class: 'card pad' }, h('h3', null, 'System status'),
        sysRow('Site URL', sys.app_url), sysRow('Mode', sys.production ? 'Production' : 'Development'), sysRow('Secure cookies', sys.cookie_secure ? 'On' : 'Off'),
        sysRow('Password-reset email (SMTP)', sys.smtp_configured ? 'Configured' : 'Not configured – links print to server log'),
        sys.gateways.map((g) => sysRow(`${g.name} gateway`, g.configured ? 'Credentials detected' : 'Not configured')))),
    h('div', { class: 'card pad mt' }, h('div', { class: 'row-between' }, h('h3', null, 'Recent orders'), h('a', { class: 'btn btn-ghost btn-sm', href: '#/orders' }, 'View all')),
      s.recent.length ? h('div', { class: 'tablewrap' }, h('table', { class: 't' }, h('thead', null, h('tr', null, ['Order', 'Game / Package', 'Amount', 'Payment', 'Status', 'Date'].map((x) => h('th', null, x)))), h('tbody', null, s.recent.map((o) => h('tr', { style: { cursor: 'pointer' }, onclick: () => (location.hash = `#/orders?open=${o.id}`) },
        h('td', null, h('b', { class: 'mono' }, o.order_no)), h('td', null, `${o.game_name} · ${o.quantity_label || o.product_name}`), h('td', null, money(o.price_bdt)), h('td', null, o.payment_status), h('td', null, statusBadge(o.status)), h('td', null, fmtDate(o.created_at))))))) : h('p', { class: 'muted' }, 'No orders yet.')));
}
const sysRow = (k, v) => h('div', { class: 'sysrow' }, h('span', { class: 'muted' }, k), h('b', null, v));

// ───────────── orders ─────────────
const STATUSES = ['Pending', 'Payment Submitted', 'Processing', 'Completed', 'Cancelled', 'Refunded'];
const PSTAT = ['unpaid', 'submitted', 'paid', 'rejected', 'refunded'];

async function ordersPage(query) {
  const f = { status: query.status || '', payment_status: query.payment_status || '', q: '', page: 1 };
  const body = h('div');
  const pager = h('div', { class: 'pager' });
  async function load() {
    const qs = new URLSearchParams({ ...(f.status && { status: f.status }), ...(f.payment_status && { payment_status: f.payment_status }), ...(f.q && { q: f.q }), page: f.page });
    const r = await api(`/admin/orders?${qs}`);
    mount(body, r.items.length ? h('div', { class: 'tablewrap' }, h('table', { class: 't' }, h('thead', null, h('tr', null, ['Order', 'Customer', 'Game / Package', 'Player ID', 'Amount', 'Payment', 'Status', 'Date', ''].map((x) => h('th', null, x)))),
      h('tbody', null, r.items.map((o) => h('tr', null, h('td', null, h('b', { class: 'mono' }, o.order_no)), h('td', null, o.user_name || '—', h('div', { class: 'tag' }, o.user_email || '')),
        h('td', null, `${o.game_name}`, h('div', { class: 'tag' }, o.quantity_label || o.product_name)), h('td', { class: 'mono' }, o.player_id, o.server_id ? ` (${o.server_id})` : ''), h('td', null, money(o.price_bdt)),
        h('td', null, o.payment_status === 'submitted' ? h('span', { class: 'pill warn' }, 'Verify') : o.payment_status, h('div', { class: 'tag' }, o.payment_method_name)), h('td', null, statusBadge(o.status)), h('td', null, fmtDate(o.created_at)),
        h('td', null, h('button', { class: 'btn btn-ghost btn-sm', onclick: () => openOrder(o.id, load) }, 'Manage'))))))) : h('div', { class: 'empty' }, h('h3', null, 'No orders match')));
    const pages = Math.max(1, Math.ceil(r.total / r.per_page));
    mount(pager, h('span', null, `${r.total} order${r.total === 1 ? '' : 's'} · page ${r.page} of ${pages}`),
      h('button', { class: 'btn btn-ghost btn-sm', disabled: f.page <= 1, onclick: () => { f.page--; load(); } }, '← Prev'), h('button', { class: 'btn btn-ghost btn-sm', disabled: f.page >= pages, onclick: () => { f.page++; load(); } }, 'Next →'));
  }
  const sel = (key, label, opts) => h('select', { class: 'input', 'aria-label': label, onchange: (e) => { f[key] = e.target.value; f.page = 1; load(); } }, h('option', { value: '' }, label), opts.map((o) => h('option', { value: o, selected: f[key] === o }, o)));
  const search = h('input', { class: 'input', type: 'search', placeholder: 'Search order, player ID, TrxID, email…', 'aria-label': 'Search orders', oninput: debounce((e) => { f.q = e.target.value.trim(); f.page = 1; load(); }, 300) });
  const root = h('div', null, h('div', { class: 'toolbar' }, search, sel('status', 'All statuses', STATUSES), sel('payment_status', 'All payment states', PSTAT)), body, pager);
  await load();
  if (query.open) openOrder(Number(query.open), load);
  return root;
}

async function openOrder(id, reload) {
  const holder = h('div', { class: 'modal-body' }, h('div', { class: 'center' }, spinner()));
  const close = openModal('Order details', holder);
  async function show(data) {
    const d = data || (await api(`/admin/orders/${id}`));
    const o = d.order;
    const note = h('input', { class: 'input', placeholder: 'Optional note (visible in the activity log)', maxlength: 200 });
    const statusSel = h('select', { class: 'input', 'aria-label': 'New status' }, STATUSES.map((s) => h('option', { value: s, selected: s === o.status }, s)));
    const act = (label, cls, fn, confirmMsg) => h('button', { class: `btn ${cls} btn-sm`, onclick: async (e) => {
      if (confirmMsg && !confirm(confirmMsg)) return;
      await withBusy(e.currentTarget, async () => { try { const r = await fn(); toast('Updated', 'success'); await show(r); reload?.(); } catch (ex) { toast(ex.message, 'error'); } });
    } }, label);
    const verifyBlock = o.payment_status === 'submitted' ? h('div', { class: 'alert alert-warn' }, icon('alert', 18), h('div', { class: 'stack' },
      h('b', null, 'Manual payment awaiting verification'),
      h('span', null, `Check that ${money(o.price_bdt)} with TrxID `, h('b', { class: 'mono' }, o.payment_trx_id), ` from ${o.payment_sender} has arrived in your ${o.payment_method_name} account, then verify.`),
      h('div', { class: 'row-between', style: { justifyContent: 'flex-start' } },
        act('✓ Payment received – verify', 'btn-primary', () => api(`/admin/orders/${id}/verify-payment`, { method: 'POST' }), `Confirm that ${money(o.price_bdt)} (TrxID ${o.payment_trx_id}) is really in your account?`),
        act('✗ Reject', 'btn-danger', () => api(`/admin/orders/${id}/reject-payment`, { method: 'POST', body: { note: note.value } }))))) : null;
    const gatewayBlock = o.payment_method_type === 'gateway' && o.gateway_payment_id && !['paid', 'refunded'].includes(o.payment_status)
      ? h('div', { class: 'alert alert-info' }, icon('info', 18), h('div', { class: 'stack' }, h('span', null, 'Online payment started but not yet confirmed by the provider.'), act('Re-check with provider', 'btn-outline', () => api(`/admin/orders/${id}/gateway-recheck`, { method: 'POST' })))) : null;
    const kv = (k, v) => h('div', null, h('dt', null, k), h('dd', null, v || '—'));
    mount(holder, verifyBlock, gatewayBlock,
      h('div', { class: 'o-head' }, h('b', { class: 'mono o-id' }, o.order_no), statusBadge(o.status)),
      h('dl', { class: 'kv' }, kv('Customer', `${o.user_name || '—'} (${o.user_email || '—'})`), kv('Phone', o.user_phone), kv('Game', o.game_name), kv('Package', `${o.product_name} ${o.quantity_label && o.quantity_label !== o.product_name ? `(${o.quantity_label})` : ''}`),
        kv('Player ID', h('b', { class: 'mono' }, o.player_id)), o.server_id ? kv('Server / Zone ID', h('b', { class: 'mono' }, o.server_id)) : null, kv('Amount', money(o.price_bdt)), kv('Payment method', o.payment_method_name), kv('Payment status', o.payment_status),
        o.payment_trx_id ? kv('TrxID', h('b', { class: 'mono' }, o.payment_trx_id)) : null, o.payment_sender ? kv('Paid from', o.payment_sender) : null, kv('Created', fmtDate(o.created_at)), kv('Updated', fmtDate(o.updated_at))),
      h('div', { class: 'field' }, h('span', null, 'Update order status'), h('div', { class: 'toolbar' }, statusSel, act('Update', 'btn-primary', () => api(`/admin/orders/${id}/status`, { method: 'POST', body: { status: statusSel.value, note: note.value } }))), note,
        h('small', { class: 'hint' }, 'Processing and Completed require a verified payment. Paid orders are refunded, not cancelled.')),
      h('h3', null, 'Activity'), h('ul', { class: 'events' }, [...d.events].reverse().map((e) => h('li', null, h('span', { class: 'rdot' }), h('div', null, h('b', null, `${e.status} · ${e.payment_status}`), h('p', null, e.note), h('small', { class: 'muted' }, `${fmtDate(e.created_at)} · ${e.actor}`))))),
      h('div', { class: 'modal-foot', style: { padding: 0, border: 0 } }, h('button', { class: 'btn btn-ghost', onclick: close }, 'Close')));
  }
  try { await show(); } catch (e) { mount(holder, h('div', { class: 'alert alert-error' }, e.message)); }
}

// ───────────── users ─────────────
async function usersPage() {
  const body = h('div');
  let q = '';
  async function load() {
    const { items } = await api(`/admin/users?q=${encodeURIComponent(q)}`);
    mount(body, h('div', { class: 'tablewrap' }, h('table', { class: 't' }, h('thead', null, h('tr', null, ['User', 'Phone', 'Orders', 'Role', 'Status', 'Joined', 'Last login'].map((x) => h('th', null, x)))),
      h('tbody', null, items.map((u) => h('tr', null, h('td', null, h('b', null, u.name), h('div', { class: 'tag' }, u.email)), h('td', null, u.phone || '—'), h('td', null, u.orders),
        h('td', null, userSelect(u, 'role', ['user', 'admin'], load)), h('td', null, userSelect(u, 'status', ['active', 'banned'], load)), h('td', null, fmtDate(u.created_at).split(',')[0]), h('td', null, u.last_login_at ? fmtDate(u.last_login_at) : '—')))))));
  }
  const root = h('div', null, h('div', { class: 'toolbar' }, h('input', { class: 'input', type: 'search', placeholder: 'Search name or email…', 'aria-label': 'Search users', oninput: debounce((e) => { q = e.target.value.trim(); load(); }, 300) })), body);
  await load();
  return root;
}
function userSelect(u, key, opts, reload) {
  const s = h('select', { class: 'input', style: { minHeight: '36px', padding: '4px 10px' }, 'aria-label': `${key} for ${u.name}`, onchange: async () => {
    if (key === 'status' && s.value === 'banned' && !confirm(`Suspend ${u.name}? They will be signed out.`)) { s.value = u[key]; return; }
    try { await api(`/admin/users/${u.id}`, { method: 'PATCH', body: { [key]: s.value } }); toast('Saved', 'success'); await reload(); } catch (e) { s.value = u[key]; toast(e.message, 'error'); }
  } }, opts.map((o) => h('option', { value: o, selected: u[key] === o }, o)));
  return s;
}

// ───────────── settings & profile ─────────────
async function settingsPage() {
  const { settings: s } = await api('/admin/settings');
  const defs = [
    ['Brand', [T('site_name', 'Site name', { required: true }), T('tagline', 'Tagline'), T('hero_title', 'Homepage headline', { full: true }), { key: 'hero_subtitle', label: 'Homepage sub-headline', type: 'textarea', full: true }, T('announcement', 'Announcement bar text', { hint: 'Leave empty to hide', full: true })]],
    ['Support & social links', [T('support_whatsapp', 'WhatsApp number', { hint: 'Digits only, e.g. 8801XXXXXXXXX' }), T('support_phone', 'Support phone'), T('support_email', 'Support email'), T('support_telegram', 'Telegram link'), T('support_facebook', 'Facebook link'), T('support_instagram', 'Instagram link'), T('support_youtube', 'YouTube link')]],
    ['Footer & store', [{ key: 'footer_text', label: 'Footer text', type: 'textarea', full: true }, B('maintenance_mode', 'Maintenance mode – pause all new orders')]],
  ];
  const inputs = {};
  const sections = defs.map(([title, fields]) => h('div', { class: 'card pad mt' }, h('h3', null, title), h('div', { class: 'fgrid two mt-s' }, fields.map((f) => { const b = buildInput(f, f.type === 'bool' ? s[f.key] === '1' : s[f.key], {}); inputs[f.key] = b; return b.el; }))));
  const err = h('div', { class: 'alert alert-error', hidden: true });
  const btn = h('button', { class: 'btn btn-primary', onclick: async (e) => {
    err.hidden = true;
    const body = Object.fromEntries(Object.entries(inputs).map(([k, b]) => [k, b.get()]));
    await withBusy(e.currentTarget, async () => { try { await api('/admin/settings', { method: 'PUT', body }); toast('Settings saved', 'success'); } catch (ex) { err.textContent = ex.message; err.hidden = false; } });
  } }, 'Save settings');
  return h('div', null, ...sections, err, h('div', { class: 'mt' }, btn));
}

async function profilePage() {
  const name = h('input', { class: 'input', value: me.name, maxlength: 60 });
  const phone = h('input', { class: 'input', value: me.phone || '' });
  const cur = h('input', { class: 'input', type: 'password', autocomplete: 'current-password' });
  const nw = h('input', { class: 'input', type: 'password', autocomplete: 'new-password' });
  const fld = (l, i, hint) => h('label', { class: 'field' }, h('span', null, l), i, hint ? h('small', { class: 'hint' }, hint) : null);
  return h('div', { class: 'cols' },
    h('div', { class: 'card pad' }, h('h3', null, 'Admin profile'), h('div', { class: 'form mt-s' }, fld('Name', name), fld('Email (login)', h('input', { class: 'input', value: me.email, disabled: true })), fld('Phone', phone),
      h('button', { class: 'btn btn-primary', onclick: async (e) => { await withBusy(e.currentTarget, async () => { try { const r = await api('/auth/profile', { method: 'PATCH', body: { name: name.value, phone: phone.value } }); me = r.user; toast('Profile saved', 'success'); } catch (ex) { toast(ex.message, 'error'); } }); } }, 'Save profile'))),
    h('div', { class: 'card pad' }, h('h3', null, 'Change password'), h('div', { class: 'form mt-s' }, fld('Current password', cur), fld('New password', nw, 'At least 8 characters. Other devices will be signed out.'),
      h('button', { class: 'btn btn-primary', onclick: async (e) => { await withBusy(e.currentTarget, async () => { try { await api('/auth/change-password', { method: 'POST', body: { current_password: cur.value, new_password: nw.value } }); cur.value = ''; nw.value = ''; toast('Password changed', 'success'); } catch (ex) { toast(ex.message, 'error'); } }); } }, 'Update password'))));
}

// ───────────── shell, routing, login ─────────────
const NAV = [
  ['Overview', [['/', 'Dashboard', 'grid'], ['/orders', 'Orders', 'box']]],
  ['Catalogue', [['/games', 'Games', 'bolt'], ['/categories', 'Categories', 'menu'], ['/products', 'Products', 'star']]],
  ['Storefront', [['/banners', 'Banners', 'edit'], ['/promotions', 'Promotions', 'bolt'], ['/reviews', 'Reviews', 'star'], ['/faqs', 'FAQs', 'info']]],
  ['Business', [['/payments', 'Payment methods', 'lock'], ['/users', 'Users', 'user'], ['/settings', 'Website settings', 'shield'], ['/profile', 'My profile', 'user']]],
];
const TITLES = { '/': 'Dashboard', '/orders': 'Orders', '/games': 'Games', '/categories': 'Categories', '/products': 'Products', '/banners': 'Homepage Banners', '/promotions': 'Promotions', '/reviews': 'Customer Reviews', '/faqs': 'FAQs', '/payments': 'Payment Methods', '/users': 'Users', '/settings': 'Website Settings', '/profile': 'My Profile' };
const PAGES = {
  '/': dashboardPage, '/orders': (q) => ordersPage(q), '/users': usersPage, '/settings': settingsPage, '/profile': profilePage,
  '/games': () => crudPage('games'), '/categories': () => crudPage('categories'), '/products': () => crudPage('products'), '/banners': () => crudPage('banners'),
  '/promotions': () => crudPage('promotions'), '/reviews': () => crudPage('reviews'), '/faqs': () => crudPage('faqs'), '/payments': () => crudPage('payment_methods'),
};

function parseHash() { const [p, qs = ''] = (location.hash.slice(1) || '/').split('?'); return { path: p || '/', query: Object.fromEntries(new URLSearchParams(qs)) }; }

let navId = 0;
async function renderPage() {
  const { path, query } = parseHash();
  const id = ++navId;
  const main = $('#page'); if (!main) return;
  document.querySelectorAll('.modal').forEach((m) => m.remove()); // a modal must never outlive its page
  $('#side')?.classList.remove('open'); $('#scrim').hidden = true;
  document.querySelectorAll('.side nav a').forEach((a) => a.classList.toggle('active', a.getAttribute('href') === `#${path}`));
  $('#ptitle').textContent = TITLES[path] || 'Not found';
  document.title = `${TITLES[path] || 'Admin'} · GAMEZONE BD Admin`;
  mount(main, h('div', { class: 'center' }, spinner()));
  let node;
  try { node = PAGES[path] ? await PAGES[path](query) : h('div', { class: 'empty' }, h('h3', null, 'Page not found')); }
  catch (e) { if (e.status === 401 || e.status === 403) return boot(); node = h('div', { class: 'alert alert-error' }, icon('alert', 18), h('span', null, e.message)); }
  if (id !== navId) return;
  mount(main, node); window.scrollTo({ top: 0 });
  api('/admin/stats').then((s) => { badge = s.awaiting_verification; const c = $('#ob'); if (c) { c.textContent = badge; c.hidden = !badge; } }).catch(() => {});
}

function shell() {
  const side = h('aside', { class: 'side', id: 'side', 'aria-label': 'Admin navigation' },
    h('div', { class: 'side-top' }, h('a', { class: 'logo', href: '#/' }, h('img', { src: '/img/logo-mark.svg', alt: '', width: 34, height: 34 }), h('span', { class: 'logo-text' }, h('b', null, 'ADMIN'))), h('button', { class: 'icon-btn burger', 'aria-label': 'Close menu', onclick: () => { side.classList.remove('open'); $('#scrim').hidden = true; } }, icon('close', 18))),
    h('nav', null, NAV.map(([group, links]) => [h('h5', null, group), links.map(([p, label, ic]) => h('a', { href: `#${p}` }, icon(ic, 18), label, p === '/orders' ? h('span', { class: 'count', id: 'ob', hidden: true }, '0') : null))])),
    h('div', { class: 'side-foot' }, h('span', { class: 'muted' }, me.email), h('a', { class: 'btn btn-ghost btn-sm', href: '/', target: '_blank', rel: 'noopener' }, 'View store ↗'),
      h('button', { class: 'btn btn-outline btn-sm', onclick: async () => { await api('/auth/logout', { method: 'POST' }).catch(() => {}); me = null; boot(); } }, icon('logout', 15), ' Log out')));
  const scrim = h('div', { class: 'scrim', id: 'scrim', hidden: true, onclick: () => { side.classList.remove('open'); scrim.hidden = true; } });
  mount(app, h('div', { class: 'shell' }, side, scrim, h('div', { class: 'main' },
    h('div', { class: 'topbar' }, h('button', { class: 'icon-btn burger', 'aria-label': 'Open menu', onclick: () => { side.classList.add('open'); scrim.hidden = false; } }, icon('menu', 20)), h('h1', { id: 'ptitle' }), h('a', { class: 'btn btn-ghost btn-sm', href: '/', target: '_blank', rel: 'noopener' }, 'Store ↗')),
    h('div', { class: 'content', id: 'page' }))));
}

function loginScreen(msg) {
  const email = h('input', { class: 'input', type: 'email', autocomplete: 'username', required: true });
  const pw = h('input', { class: 'input', type: 'password', autocomplete: 'current-password', required: true });
  const err = h('div', { class: 'alert alert-error', hidden: !msg, role: 'alert' }, msg || '');
  const btn = h('button', { class: 'btn btn-primary btn-block', type: 'submit' }, 'Sign in');
  mount(app, h('div', { class: 'login-wrap' }, h('div', { class: 'auth-card card' }, h('img', { class: 'auth-logo', src: '/img/logo-mark.svg', alt: '', width: 56, height: 56 }), h('h1', null, 'GAMEZONE BD Admin'), h('p', { class: 'muted' }, 'Administrator sign-in'),
    h('form', { class: 'form', onsubmit: async (e) => {
      e.preventDefault(); err.hidden = true;
      await withBusy(btn, async () => {
        try {
          const r = await api('/auth/login', { method: 'POST', body: { email: email.value, password: pw.value } });
          if (r.user.role !== 'admin') { await api('/auth/logout', { method: 'POST' }); throw new Error('This account does not have administrator access.'); }
          boot();
        } catch (ex) { err.textContent = ex.message; err.hidden = false; }
      });
    } }, err, h('label', { class: 'field' }, h('span', null, 'Email'), email), h('label', { class: 'field' }, h('span', null, 'Password'), pw), btn))));
  email.focus();
}

async function boot() {
  try { me = (await api('/auth/me')).user; } catch { me = null; }
  if (!me || me.role !== 'admin') return loginScreen(me && me.role !== 'admin' ? 'This account does not have administrator access.' : '');
  await refreshLookups().catch(() => {});
  shell();
  await renderPage();
}

window.addEventListener('hashchange', () => { if (me) renderPage(); });
boot();
