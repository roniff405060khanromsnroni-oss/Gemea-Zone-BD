import { h, mount, icon, money, safeUrl, discount, timeAgo, toast, withBusy, skeletonGrid } from './util.js';
import { api, ApiError } from './api.js';
import { state, go, loadSite, currentHash } from './state.js';
import { searchBox, renderFooter, renderAnnouncement } from './layout.js';

// ───────────── shared cards ─────────────
export function gameCard(g) {
  return h('a', { class: 'gcard', href: `#/game/${g.slug}` },
    h('div', { class: 'gimg' }, h('img', { src: safeUrl(g.image_url), alt: `${g.name} artwork`, loading: 'lazy', width: 480, height: 600 }), h('span', { class: 'gtag' }, g.currency_label)),
    h('div', { class: 'gbody' }, h('h3', null, g.name), h('p', null, g.description), h('span', { class: 'gcta' }, 'Top up now ', icon('chevron', 16))));
}

export function productCard(p, { onBuy, selected = false, showGame = false } = {}) {
  const off = discount(p);
  const soldOut = !p.available;
  const card = h('article', { class: `pcard${selected ? ' selected' : ''}${soldOut ? ' soldout' : ''}`, onclick: () => !soldOut && onBuy(p) },
    off ? h('span', { class: 'off' }, `-${off}%`) : null,
    soldOut ? h('span', { class: 'ribbon' }, 'Out of stock') : null,
    h('div', { class: 'pimg' }, h('img', { src: safeUrl(p.image_url), alt: '', loading: 'lazy', width: 240, height: 240 })),
    h('div', { class: 'pbody' },
      showGame ? h('span', { class: 'pgame' }, p.game_name) : null,
      h('h4', null, p.name),
      p.quantity_label && p.quantity_label !== p.name ? h('span', { class: 'pqty' }, p.quantity_label) : null,
      h('div', { class: 'pprice' }, h('b', null, money(p.price_bdt)), p.old_price_bdt > p.price_bdt ? h('s', null, money(p.old_price_bdt)) : null),
      h('button', { class: 'btn btn-primary btn-sm btn-block', type: 'button', disabled: soldOut, 'aria-pressed': selected ? 'true' : 'false', onclick: (e) => { e.stopPropagation(); onBuy(p); } }, soldOut ? 'Unavailable' : selected ? 'Selected ✓' : 'Buy Now')));
  return card;
}

const sectionHead = (title, sub, link) => h('div', { class: 'sec-head' }, h('div', null, h('h2', null, title), sub ? h('p', { class: 'muted' }, sub) : null), link ? h('a', { class: 'btn btn-ghost btn-sm', href: link[0] }, link[1], ' ', icon('chevron', 16)) : null);

function stars(n) { return h('span', { class: 'stars', role: 'img', 'aria-label': `${n} out of 5 stars` }, [1, 2, 3, 4, 5].map((i) => h('span', { class: i <= n ? 'on' : '' }, icon('star', 16)))); }

// ───────────── home ─────────────
export async function homePage(ctx) {
  const site = await loadSite();
  renderAnnouncement(); renderFooter();
  const s = site.settings;
  const root = h('div', { class: 'page home' });

  // hero
  const tile = (src, cls) => h('div', { class: `float-tile ${cls}` }, h('img', { src, alt: '', width: 160, height: 160 }));
  root.append(h('section', { class: 'hero' }, h('div', { class: 'container hero-in' },
    h('div', { class: 'hero-copy' },
      h('span', { class: 'eyebrow' }, icon('bolt', 14), ' Premium gaming top-up'),
      h('h1', null, s.hero_title),
      h('p', { class: 'lead' }, s.hero_subtitle),
      searchBox({ big: true }),
      h('div', { class: 'hero-cta' }, h('a', { class: 'btn btn-primary', href: '#/games' }, 'Browse all games'), h('a', { class: 'btn btn-outline', href: '#/track' }, 'Track an order')),
      h('ul', { class: 'trust' },
        h('li', null, icon('lock', 18), 'No game password, ever'),
        h('li', null, icon('shield', 18), 'Payments verified before delivery'),
        h('li', null, icon('clock', 18), 'Live order tracking'))),
    h('div', { class: 'hero-art', 'aria-hidden': 'true' }, h('div', { class: 'orb' }), tile('/img/products/diamond-4.svg', 't1'), tile('/img/products/uc-3.svg', 't2'), tile('/img/products/gem-3.svg', 't3')))));

  // banners
  if (site.banners.length) root.append(banner(site.banners, ctx));

  // featured games
  const featured = site.games.filter((g) => g.featured);
  const showGames = featured.length ? featured : site.games;
  root.append(h('section', { class: 'container section' }, sectionHead('Featured Games', 'Pick a game and top up in minutes', ['#/games', 'All games']),
    showGames.length ? h('div', { class: 'grid grid-games' }, showGames.map(gameCard)) : emptyState('No games yet', 'Games added in the admin dashboard will appear here.')));

  // popular products
  if (site.popular.length) {
    root.append(h('section', { class: 'container section' }, sectionHead('Popular Top-Ups', 'Most-picked packages right now'),
      h('div', { class: 'grid grid-products' }, site.popular.map((p) => productCard(p, { showGame: true, onBuy: (x) => go(`/game/${x.game_slug}?p=${x.id}`) })))));
  }

  // offers & promotions
  if (site.promotions.length || site.offers.length) {
    root.append(h('section', { class: 'container section' }, sectionHead('Special Offers & Promotions'),
      site.promotions.length ? h('div', { class: 'grid grid-promos' }, site.promotions.map((p) => {
        const link = safeUrl(p.link_url);
        return h(link ? 'a' : 'div', { class: 'promo', href: link || null },
          p.badge ? h('span', { class: 'badge b-accent' }, p.badge) : null, h('h3', null, p.title), h('p', null, p.description));
      })) : null,
      site.offers.length ? h('div', { class: 'grid grid-products mt' }, site.offers.map((p) => productCard(p, { showGame: true, onBuy: (x) => go(`/game/${x.game_slug}?p=${x.id}`) }))) : null));
  }

  // how it works + latest orders
  root.append(h('section', { class: 'container section' }, h('div', { class: 'two-col' },
    h('div', { class: 'card pad' }, h('h2', null, 'How it works'),
      h('ol', { class: 'steps' }, [
        ['Choose your game', 'Pick a game and a top-up package.'],
        ['Enter your Player ID', 'Only your ID – never your password.'],
        ['Pay with bKash, Nagad or Rocket', 'We verify every payment before processing.'],
        ['Track your order', 'Follow the status live with your Order ID.'],
      ].map(([t, d], i) => h('li', null, h('span', { class: 'num' }, i + 1), h('div', null, h('b', null, t), h('p', null, d)))))),
    h('div', { class: 'card pad' }, h('h2', null, 'Latest completed orders'),
      site.recent_orders.length
        ? h('ul', { class: 'recent' }, site.recent_orders.map((o) => h('li', null, h('span', { class: 'rdot' }), h('div', null, h('b', null, `${o.who} got ${o.item}`), h('p', null, `${o.game_name} · ${timeAgo(o.at)}`)))))
        : h('p', { class: 'muted' }, 'Completed orders will show up here. Place an order and be the first!')))));

  // reviews
  root.append(h('section', { class: 'container section' }, sectionHead('Customer Reviews', 'What our customers say'),
    site.reviews.length ? h('div', { class: 'grid grid-reviews' }, site.reviews.map((r) => h('figure', { class: 'review card pad' },
      stars(r.rating), h('blockquote', null, r.comment), h('figcaption', null, h('span', { class: 'avatar sm' }, [...r.name][0].toUpperCase()), r.name))))
      : emptyState('No reviews yet', 'Customers with a completed order can share their experience from the Orders page.')));

  // FAQ
  if (site.faqs.length) {
    root.append(h('section', { class: 'container section narrow' }, sectionHead('Frequently Asked Questions'), faqList(site.faqs)));
  }
  return root;
}

export const faqList = (faqs) => h('div', { class: 'faq' }, faqs.map((f, i) => h('details', { open: i === 0 && false }, h('summary', null, f.question, icon('down', 18)), h('p', null, f.answer))));

export function emptyState(title, text, action) {
  return h('div', { class: 'empty' }, icon('box', 36), h('h3', null, title), text ? h('p', null, text) : null, action || null);
}

function banner(banners, ctx) {
  let i = 0;
  const slides = banners.map((b, n) => {
    const link = safeUrl(b.link_url);
    return h(link ? 'a' : 'div', { class: `slide${n === 0 ? ' on' : ''}`, href: link || null, 'aria-hidden': n === 0 ? 'false' : 'true', tabindex: n === 0 || !link ? null : '-1' },
      h('img', { src: safeUrl(b.image_url), alt: '', loading: n === 0 ? 'eager' : 'lazy' }),
      h('div', { class: 'slide-text' }, h('h3', null, b.title), b.subtitle ? h('p', null, b.subtitle) : null, link ? h('span', { class: 'btn btn-primary btn-sm' }, 'Top up now') : null));
  });
  const dots = banners.map((_, n) => h('button', { class: n === 0 ? 'on' : '', 'aria-label': `Show banner ${n + 1}`, onclick: () => show(n) }));
  function show(n) {
    i = (n + slides.length) % slides.length;
    slides.forEach((s, k) => { s.classList.toggle('on', k === i); s.setAttribute('aria-hidden', k === i ? 'false' : 'true'); if (s.tagName === 'A') s.tabIndex = k === i ? 0 : -1; });
    dots.forEach((d, k) => d.classList.toggle('on', k === i));
  }
  const box = h('section', { class: 'container section tight' }, h('div', { class: 'banner', 'aria-roledescription': 'carousel', 'aria-label': 'Promotions' }, slides,
    banners.length > 1 ? h('div', { class: 'dots' }, dots) : null));
  if (banners.length > 1) {
    let hover = false;
    box.addEventListener('mouseenter', () => { hover = true; });
    box.addEventListener('mouseleave', () => { hover = false; });
    const t = setInterval(() => { if (!hover && !document.hidden) show(i + 1); }, 6000);
    ctx.onLeave(() => clearInterval(t));
  }
  return box;
}

// ───────────── all games ─────────────
export async function gamesPage(ctx) {
  const q = (ctx.query.q || '').trim();
  const [site, found] = await Promise.all([loadSite(), q.length >= 2 ? api(`/search?q=${encodeURIComponent(q)}`) : Promise.resolve(null)]);
  renderFooter(); renderAnnouncement();
  ctx.title = q ? `Search: ${q}` : 'All Games';
  const games = q ? site.games.filter((g) => found.games.some((x) => x.slug === g.slug)) : site.games;

  return h('div', { class: 'page container section' },
    h('div', { class: 'page-head' }, h('h1', null, q ? `Results for “${q}”` : 'All Games'), h('p', { class: 'muted' }, q ? `${games.length} game${games.length === 1 ? '' : 's'} · ${found.products.length} package${found.products.length === 1 ? '' : 's'}` : 'Choose a game to see its top-up packages'), searchBox()),
    games.length || !q ? h('div', { class: 'grid grid-games' }, games.map(gameCard), q ? null : h('div', { class: 'gcard soon' }, h('div', { class: 'soon-in' }, icon('plus', 32), h('h3', null, 'More games'), h('p', null, 'New games are added regularly.')))) : null,
    q && found.products.length ? [h('h2', { class: 'mt' }, 'Matching packages'), h('div', { class: 'grid grid-products' }, found.products.map((p) => productCard(p, { showGame: true, onBuy: (x) => go(`/game/${x.game_slug}?p=${x.id}`) })))] : null,
    q && !games.length && !found.products.length ? emptyState('Nothing found', 'Try a different spelling or browse all games.', h('a', { class: 'btn btn-primary', href: '#/games' }, 'Show all games')) : null);
}

// ───────────── game page + checkout ─────────────
const CK = 'gz_checkout';

export async function gamePage(ctx) {
  let data;
  try { data = await api(`/games/${encodeURIComponent(ctx.params.slug)}`); }
  catch (e) { if (e.status === 404) return notFound('That game could not be found.'); throw e; }
  await loadSite().catch(() => {});
  renderFooter(); renderAnnouncement();

  const { game, categories, products, payment_methods: methods } = data;
  ctx.title = `${game.name} Top-Up`;
  const maintenance = state.site?.settings.maintenance_mode === '1';

  // restore a checkout that was interrupted by logging in
  let saved = null;
  try { saved = JSON.parse(sessionStorage.getItem(CK) || 'null'); } catch { /* ignore */ }
  if (saved && saved.slug !== game.slug) saved = null;

  const sel = { product: products.find((p) => p.available && (String(p.id) === ctx.query.p || (!ctx.query.p && saved && saved.product === p.id))) || null, method: (saved && methods.find((m) => m.id === saved.method)?.id) || methods[0]?.id || null };
  let player = saved?.player || '';
  let server = saved?.server || '';
  let filter = 'all';

  // ── packages column ──
  const chips = h('div', { class: 'chips', role: 'tablist', 'aria-label': 'Package categories' });
  const list = h('div', { class: 'plist' });
  const usedCats = categories.filter((c) => products.some((p) => p.category_id === c.id));
  const hasUncat = products.some((p) => !p.category_id || !categories.some((c) => c.id === p.category_id));
  const groups = [...usedCats.map((c) => ({ id: c.id, name: c.name, items: products.filter((p) => p.category_id === c.id) })), ...(hasUncat ? [{ id: 0, name: 'Other packages', items: products.filter((p) => !p.category_id || !categories.some((c) => c.id === p.category_id)) }] : [])];

  function drawChips() {
    mount(chips, [{ id: 'all', name: 'All' }, ...groups].map((g) => h('button', { role: 'tab', class: `chip${String(filter) === String(g.id) ? ' on' : ''}`, 'aria-selected': String(filter) === String(g.id), onclick: () => { filter = g.id; drawChips(); drawList(); } }, g.name)));
  }
  function drawList() {
    const shown = filter === 'all' ? groups : groups.filter((g) => String(g.id) === String(filter));
    mount(list, shown.length ? shown.map((g) => h('section', { class: 'pgroup' }, h('h3', null, g.name), h('div', { class: 'grid grid-products tight-g' }, g.items.map((p) => productCard(p, { selected: sel.product?.id === p.id, onBuy: choose }))))) : emptyState('No packages yet', 'Packages for this game will appear here soon.'));
  }

  // ── checkout column (built once so typing never loses focus) ──
  const idHint = (label) => h('small', { class: 'hint' }, `Find your ${label} in the game’s profile screen. We never ask for your password.`);
  const pErr = h('span', { class: 'err', role: 'alert' });
  const sErr = h('span', { class: 'err', role: 'alert' });
  const pInput = h('input', { class: 'input', id: 'pid', inputmode: 'numeric', autocomplete: 'off', maxlength: 30, placeholder: `Enter ${game.player_id_label}`, value: player, 'aria-describedby': 'pid-err', oninput: (e) => { player = e.target.value.trim(); pErr.textContent = ''; persist(); refresh(); } });
  const sInput = game.requires_server_id ? h('input', { class: 'input', id: 'sid', inputmode: 'numeric', autocomplete: 'off', maxlength: 20, placeholder: `Enter ${game.server_id_label}`, value: server, oninput: (e) => { server = e.target.value.trim(); sErr.textContent = ''; persist(); refresh(); } }) : null;

  const selBox = h('div', { class: 'sel-box' });
  const sumBox = h('div', { class: 'summary' });
  const submit = h('button', { class: 'btn btn-primary btn-lg btn-block', type: 'submit' }, 'Place Order');
  const mbar = h('div', { class: 'mbar', hidden: true });

  const methodBox = methods.length
    ? h('div', { class: 'pm-grid', role: 'radiogroup', 'aria-label': 'Payment method' }, methods.map((m) => {
        const input = h('input', { type: 'radio', name: 'pm', value: m.id, checked: m.id === sel.method, onchange: () => { sel.method = m.id; persist(); refresh(); } });
        return h('label', { class: 'pm', style: { '--c': m.brand_color } }, input, h('span', { class: 'pm-dot' }), h('span', { class: 'pm-name' }, m.name), h('span', { class: 'pm-type' }, m.type === 'gateway' ? 'Online' : 'Send money'));
      }))
    : h('div', { class: 'alert alert-warn' }, icon('alert', 18), h('span', null, 'No payment method is available right now. Please check back soon or contact support.'));

  const form = h('form', { class: 'checkout card', novalidate: true, onsubmit: onSubmit },
    h('h3', null, 'Complete your top-up'),
    h('div', { class: 'step' }, h('span', { class: 'num' }, 1), h('b', null, 'Your package')), selBox,
    h('div', { class: 'step' }, h('span', { class: 'num' }, 2), h('b', null, 'Your game account')),
    h('label', { class: 'field', for: 'pid' }, h('span', null, game.player_id_label), pInput, pErr),
    game.requires_server_id ? h('label', { class: 'field', for: 'sid' }, h('span', null, game.server_id_label), sInput, sErr) : null,
    idHint(game.player_id_label),
    h('div', { class: 'step' }, h('span', { class: 'num' }, 3), h('b', null, 'Payment method')), methodBox,
    sumBox,
    maintenance ? h('div', { class: 'alert alert-warn' }, icon('alert', 18), h('span', null, 'The store is closed for maintenance. Ordering is paused.')) : null,
    submit,
    h('p', { class: 'fine' }, icon('lock', 14), ' Your order is only processed after your payment has been verified.'));

  function persist() { try { sessionStorage.setItem(CK, JSON.stringify({ slug: game.slug, product: sel.product?.id || null, player, server, method: sel.method })); } catch { /* ignore */ } }

  function refresh() {
    const p = sel.product;
    mount(selBox, p ? h('div', { class: 'sel' }, h('img', { src: safeUrl(p.image_url), alt: '', width: 56, height: 56 }), h('div', null, h('b', null, p.name), h('small', null, p.quantity_label)), h('b', { class: 'sel-price' }, money(p.price_bdt)))
                     : h('p', { class: 'muted small' }, 'Choose a package from the list.'));
    const m = methods.find((x) => x.id === sel.method);
    mount(sumBox, h('dl', null,
      h('div', null, h('dt', null, 'Package'), h('dd', null, p ? p.name : '—')),
      h('div', null, h('dt', null, game.player_id_label), h('dd', null, player || '—')),
      game.requires_server_id ? h('div', null, h('dt', null, game.server_id_label), h('dd', null, server || '—')) : null,
      h('div', null, h('dt', null, 'Payment'), h('dd', null, m ? m.name : '—')),
      h('div', { class: 'total' }, h('dt', null, 'Total'), h('dd', null, p ? money(p.price_bdt) : '—'))));
    submit.disabled = !p || !methods.length || maintenance;
    if (p) { mount(mbar, h('div', null, h('b', null, p.name), h('small', null, money(p.price_bdt))), h('button', { class: 'btn btn-primary btn-sm', type: 'button', onclick: () => form.scrollIntoView({ behavior: 'smooth', block: 'start' }) }, 'Continue')); mbar.hidden = false; } else mbar.hidden = true;
  }

  function choose(p) {
    sel.product = p; persist(); drawList(); refresh();
    if (window.matchMedia('(max-width: 900px)').matches) form.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setTimeout(() => (player ? (game.requires_server_id && !server ? sInput : pInput) : pInput).focus({ preventScroll: true }), 350);
  }

  function checkId(value, pattern, label) {
    if (!value) return `Enter your ${label}`;
    if (pattern) { try { if (!new RegExp(pattern).test(value)) return `That ${label} doesn’t look right – please double-check it`; } catch { /* ignore bad pattern */ } }
    return '';
  }

  async function onSubmit(e) {
    e.preventDefault();
    if (!sel.product) return toast('Please choose a package first', 'error');
    const e1 = checkId(player, game.player_id_pattern, game.player_id_label);
    const e2 = game.requires_server_id ? checkId(server, game.server_id_pattern, game.server_id_label) : '';
    pErr.textContent = e1; sErr.textContent = e2;
    if (e1) return pInput.focus();
    if (e2) return sInput.focus();
    if (!sel.method) return toast('Please choose a payment method', 'error');
    persist();
    if (!state.user) { toast('Please log in to place your order – your selection is saved', 'info'); return go(`/login?next=${encodeURIComponent(currentHash())}`); }
    await withBusy(submit, async () => {
      try {
        const { order } = await api('/orders', { method: 'POST', body: { product_id: sel.product.id, payment_method_id: sel.method, player_id: player, server_id: server } });
        sessionStorage.removeItem(CK);
        toast(`Order ${order.order_no} created`, 'success');
        go(`/order/${order.order_no}`);
      } catch (err) {
        if (err.status === 401) { go(`/login?next=${encodeURIComponent(currentHash())}`); return; }
        toast(err.message, 'error');
        if (err.fields?.player_id || /Player|User ID/i.test(err.message)) pErr.textContent = err.message;
      }
    });
  }

  drawChips(); drawList(); refresh();
  ctx.onLeave(() => mbar.remove());
  document.body.append(mbar);

  return h('div', { class: 'page' },
    h('section', { class: 'game-hero', style: { '--bg-img': game.banner_url ? `url("${safeUrl(game.banner_url)}")` : 'none' } }, h('div', { class: 'container gh-in' },
      h('a', { class: 'crumb', href: '#/games' }, '← All games'),
      h('div', { class: 'gh-main' }, h('img', { class: 'gh-img', src: safeUrl(game.image_url), alt: '', width: 96, height: 120 }),
        h('div', null, h('h1', null, game.name), h('p', null, game.description), h('span', { class: 'badge b-accent' }, `${game.currency_label} top-up`))))),
    h('div', { class: 'container section tight game-layout' }, h('div', { class: 'game-main' }, chips, list), h('aside', { class: 'game-side' }, form)));
}

export function notFound(msg = 'The page you’re looking for doesn’t exist.') {
  return h('div', { class: 'page container section' }, emptyState('Page not found', msg, h('a', { class: 'btn btn-primary', href: '#/' }, 'Back to home')));
}

export { skeletonGrid, ApiError };
