import { h, mount, icon, money, fmtDate, safeUrl, toast, withBusy, statusBadge, statusClass, copyText, spinner } from './util.js';
import { api } from './api.js';
import { state, go, setUser, loadSite, requireLogin, currentHash } from './state.js';
import { renderFooter, renderAnnouncement } from './layout.js';
import { emptyState, faqList } from './pages-store.js';

// ───────────── form helpers ─────────────
function field(label, input, { hint, error } = {}) {
  const err = h('span', { class: 'err', role: 'alert' }, error || '');
  return { el: h('label', { class: 'field' }, h('span', null, label), input, hint ? h('small', { class: 'hint' }, hint) : null, err), err };
}
const input = (attrs) => h('input', { class: 'input', ...attrs });

function showFieldErrors(err, map) {
  let any = false;
  for (const [k, el] of Object.entries(map)) { el.textContent = err.fields?.[k] && err.fields[k] !== 'invalid' ? err.fields[k] : ''; if (el.textContent) any = true; }
  return any;
}

function authShell(title, sub, ...kids) {
  return h('div', { class: 'page container section auth-wrap' }, h('div', { class: 'auth-card card' },
    h('img', { class: 'auth-logo', src: '/img/logo-mark.svg', alt: '', width: 52, height: 52 }), h('h1', null, title), sub ? h('p', { class: 'muted' }, sub) : null, ...kids));
}

const safeNext = (n) => (n && /^\/[a-z]/i.test(n) && !n.startsWith('//') ? n : '/');

// ───────────── login / register ─────────────
export async function loginPage(ctx) {
  await loadSite().catch(() => {}); renderFooter(); renderAnnouncement();
  ctx.title = 'Login';
  if (state.user) { go(safeNext(ctx.query.next)); return h('div'); }
  const email = input({ type: 'email', required: true, autocomplete: 'email', placeholder: 'you@example.com' });
  const pw = input({ type: 'password', required: true, autocomplete: 'current-password', placeholder: 'Your password' });
  const msg = h('div', { class: 'alert alert-error', hidden: true, role: 'alert' });
  const btn = h('button', { class: 'btn btn-primary btn-block', type: 'submit' }, 'Log in');
  const form = h('form', { class: 'form', novalidate: true, onsubmit: async (e) => {
    e.preventDefault(); msg.hidden = true;
    if (!email.value.trim() || !pw.value) { msg.textContent = 'Enter your email and password.'; msg.hidden = false; return; }
    await withBusy(btn, async () => {
      try {
        const r = await api('/auth/login', { method: 'POST', body: { email: email.value, password: pw.value } });
        setUser(r.user); toast(`Welcome back, ${r.user.name.split(' ')[0]}!`, 'success');
        go(safeNext(ctx.query.next));
      } catch (err) { msg.textContent = err.message; msg.hidden = false; }
    });
  } }, msg, field('Email', email).el, field('Password', pw).el,
    h('div', { class: 'row-between' }, h('a', { href: '#/forgot' }, 'Forgot password?')), btn);
  return authShell('Welcome back', 'Log in to track orders and top up faster.', form,
    h('p', { class: 'auth-alt' }, 'New here? ', h('a', { href: `#/register${ctx.query.next ? `?next=${encodeURIComponent(ctx.query.next)}` : ''}` }, 'Create an account')));
}

export async function registerPage(ctx) {
  await loadSite().catch(() => {}); renderFooter(); renderAnnouncement();
  ctx.title = 'Create account';
  if (state.user) { go('/'); return h('div'); }
  const name = input({ required: true, autocomplete: 'name', maxlength: 60, placeholder: 'Your name' });
  const email = input({ type: 'email', required: true, autocomplete: 'email', placeholder: 'you@example.com' });
  const phone = input({ type: 'tel', autocomplete: 'tel', placeholder: '01XXXXXXXXX (optional)' });
  const pw = input({ type: 'password', required: true, autocomplete: 'new-password', minlength: 8, placeholder: 'At least 8 characters' });
  const pw2 = input({ type: 'password', required: true, autocomplete: 'new-password', placeholder: 'Repeat password' });
  const fN = field('Full name', name), fE = field('Email', email), fP = field('Mobile number', phone, { hint: 'Optional. Used only for support.' }), fW = field('Password', pw), fW2 = field('Confirm password', pw2);
  const msg = h('div', { class: 'alert alert-error', hidden: true, role: 'alert' });
  const btn = h('button', { class: 'btn btn-primary btn-block', type: 'submit' }, 'Create account');
  const form = h('form', { class: 'form', novalidate: true, onsubmit: async (e) => {
    e.preventDefault(); msg.hidden = true;
    [fN, fE, fP, fW, fW2].forEach((f) => (f.err.textContent = ''));
    if (pw.value !== pw2.value) { fW2.err.textContent = 'Passwords do not match'; return; }
    await withBusy(btn, async () => {
      try {
        const r = await api('/auth/register', { method: 'POST', body: { name: name.value, email: email.value, phone: phone.value, password: pw.value } });
        setUser(r.user); toast('Account created – welcome to GAMEZONE BD!', 'success'); go(safeNext(ctx.query.next));
      } catch (err) {
        if (!showFieldErrors(err, { name: fN.err, email: fE.err, phone: fP.err, password: fW.err })) { msg.textContent = err.message; msg.hidden = false; }
        else if (err.fields.email === 'taken') fE.err.textContent = err.message;
      }
    });
  } }, msg, fN.el, fE.el, fP.el, fW.el, fW2.el, btn);
  return authShell('Create your account', 'Order history and tracking in one place.', form, h('p', { class: 'auth-alt' }, 'Already registered? ', h('a', { href: '#/login' }, 'Log in')));
}

export async function forgotPage(ctx) {
  await loadSite().catch(() => {}); renderFooter(); renderAnnouncement();
  ctx.title = 'Reset password';
  const email = input({ type: 'email', required: true, autocomplete: 'email', placeholder: 'you@example.com' });
  const out = h('div');
  const btn = h('button', { class: 'btn btn-primary btn-block', type: 'submit' }, 'Send reset link');
  const form = h('form', { class: 'form', novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    await withBusy(btn, async () => {
      try { const r = await api('/auth/forgot-password', { method: 'POST', body: { email: email.value } }); mount(out, h('div', { class: 'alert alert-ok' }, icon('check', 18), h('span', null, r.message))); }
      catch (err) { mount(out, h('div', { class: 'alert alert-error' }, err.message)); }
    });
  } }, field('Email', email).el, btn, out);
  return authShell('Forgot your password?', 'Enter your email and we’ll send you a reset link.', form, h('p', { class: 'auth-alt' }, h('a', { href: '#/login' }, '← Back to login')));
}

export async function resetPage(ctx) {
  await loadSite().catch(() => {}); renderFooter(); renderAnnouncement();
  ctx.title = 'Choose a new password';
  const token = ctx.query.token || '';
  const pw = input({ type: 'password', required: true, autocomplete: 'new-password', minlength: 8, placeholder: 'At least 8 characters' });
  const msg = h('div', { class: 'alert alert-error', hidden: true, role: 'alert' });
  const btn = h('button', { class: 'btn btn-primary btn-block', type: 'submit' }, 'Save new password');
  if (!token) return authShell('Link not valid', 'This reset link is missing its token.', h('a', { class: 'btn btn-primary', href: '#/forgot' }, 'Request a new link'));
  const form = h('form', { class: 'form', novalidate: true, onsubmit: async (e) => {
    e.preventDefault(); msg.hidden = true;
    await withBusy(btn, async () => {
      try { await api('/auth/reset-password', { method: 'POST', body: { token, password: pw.value } }); toast('Password updated – please log in', 'success'); go('/login'); }
      catch (err) { msg.textContent = err.message; msg.hidden = false; }
    });
  } }, msg, field('New password', pw).el, btn);
  return authShell('Choose a new password', null, form);
}

// ───────────── profile ─────────────
export async function profilePage(ctx) {
  if (!requireLogin()) return h('div');
  await loadSite().catch(() => {}); renderFooter(); renderAnnouncement();
  ctx.title = 'My Profile';
  const u = state.user;
  const name = input({ value: u.name, maxlength: 60, required: true });
  const phone = input({ value: u.phone, type: 'tel', placeholder: '01XXXXXXXXX' });
  const pErr = h('span', { class: 'err' });
  const saveBtn = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Save changes');
  const profile = h('form', { class: 'form', novalidate: true, onsubmit: async (e) => {
    e.preventDefault(); pErr.textContent = '';
    await withBusy(saveBtn, async () => {
      try { const r = await api('/auth/profile', { method: 'PATCH', body: { name: name.value, phone: phone.value } }); setUser(r.user); toast('Profile updated', 'success'); }
      catch (err) { pErr.textContent = err.message; toast(err.message, 'error'); }
    });
  } }, field('Full name', name).el, field('Email', input({ value: u.email, disabled: true }), { hint: 'Your email is your login and cannot be changed here.' }).el,
    h('label', { class: 'field' }, h('span', null, 'Mobile number'), phone, pErr), saveBtn);

  const cur = input({ type: 'password', autocomplete: 'current-password', required: true });
  const nw = input({ type: 'password', autocomplete: 'new-password', required: true, minlength: 8 });
  const cErr = h('span', { class: 'err' });
  const pwBtn = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Update password');
  const pwForm = h('form', { class: 'form', novalidate: true, onsubmit: async (e) => {
    e.preventDefault(); cErr.textContent = '';
    await withBusy(pwBtn, async () => {
      try { await api('/auth/change-password', { method: 'POST', body: { current_password: cur.value, new_password: nw.value } }); cur.value = ''; nw.value = ''; toast('Password changed. Other devices were signed out.', 'success'); }
      catch (err) { cErr.textContent = err.message; toast(err.message, 'error'); }
    });
  } }, h('label', { class: 'field' }, h('span', null, 'Current password'), cur, cErr), field('New password', nw, { hint: 'At least 8 characters.' }).el, pwBtn);

  return h('div', { class: 'page container section narrow' }, h('div', { class: 'page-head' }, h('h1', null, 'My Account'), h('p', { class: 'muted' }, `Member since ${fmtDate(u.created_at).split(',')[0]}`)),
    h('div', { class: 'grid grid-2' }, h('section', { class: 'card pad' }, h('h2', null, 'Account information'), profile), h('section', { class: 'card pad' }, h('h2', null, 'Change password'), pwForm)),
    h('div', { class: 'card pad mt row-between' }, h('div', null, h('h3', null, 'Your orders'), h('p', { class: 'muted' }, 'View history and live status of every order.')), h('a', { class: 'btn btn-outline', href: '#/orders' }, 'View orders')));
}

// ───────────── orders list ─────────────
export async function ordersPage(ctx) {
  if (!requireLogin()) return h('div');
  await loadSite().catch(() => {}); renderFooter(); renderAnnouncement();
  ctx.title = 'My Orders';
  const { orders } = await api('/orders');
  const hasDone = orders.some((o) => o.status === 'Completed');
  return h('div', { class: 'page container section' }, h('div', { class: 'page-head row-between' }, h('div', null, h('h1', null, 'My Orders'), h('p', { class: 'muted' }, 'Your order history and current status')), h('a', { class: 'btn btn-primary', href: '#/games' }, icon('plus', 16), ' New top-up')),
    orders.length ? h('div', { class: 'olist' }, orders.map((o) => h('a', { class: 'ocard card', href: `#/order/${o.order_no}` },
      h('div', { class: 'o-main' }, h('b', null, o.game_name), h('span', null, `${o.product_name}${o.quantity_label && o.quantity_label !== o.product_name ? ` · ${o.quantity_label}` : ''}`), h('small', { class: 'mono' }, o.order_no)),
      h('div', { class: 'o-mid' }, h('span', { class: 'muted small' }, fmtDate(o.created_at)), h('span', { class: 'small' }, o.payment_label)),
      h('div', { class: 'o-end' }, statusBadge(o.status), h('b', null, money(o.price_bdt)), icon('chevron', 18)))))
      : emptyState('No orders yet', 'When you place a top-up order it will show up here.', h('a', { class: 'btn btn-primary', href: '#/games' }, 'Browse games')),
    hasDone ? reviewBox() : null);
}

function reviewBox() {
  const wrap = h('div', { class: 'card pad mt' });
  let rating = 5;
  const comment = h('textarea', { class: 'input', rows: 3, maxlength: 400, placeholder: 'How was your experience?' });
  const starBtns = [1, 2, 3, 4, 5].map((n) => h('button', { type: 'button', class: 'star-btn on', 'aria-label': `${n} star${n > 1 ? 's' : ''}`, onclick: () => { rating = n; starBtns.forEach((b, i) => b.classList.toggle('on', i < n)); } }, icon('star', 24)));
  const btn = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Submit review');
  mount(wrap, h('h3', null, 'Leave a review'), h('form', { class: 'form', onsubmit: async (e) => {
    e.preventDefault();
    await withBusy(btn, async () => {
      try { const r = await api('/reviews', { method: 'POST', body: { rating, comment: comment.value } }); mount(wrap, h('div', { class: 'alert alert-ok' }, icon('check', 18), h('span', null, r.message))); }
      catch (err) { toast(err.message, 'error'); }
    });
  } }, h('div', { class: 'star-pick' }, starBtns), comment, btn));
  return wrap;
}

// ───────────── single order (payment + tracking) ─────────────
const STEPS = ['Pending', 'Payment Submitted', 'Processing', 'Completed'];

function timeline(status) {
  if (status === 'Cancelled' || status === 'Refunded') return h('div', { class: `final ${statusClass(status)}` }, statusBadge(status), h('span', null, status === 'Cancelled' ? 'This order was cancelled.' : 'This order was refunded.'));
  const at = STEPS.indexOf(status);
  return h('ol', { class: 'tl' }, STEPS.map((s, i) => h('li', { class: i < at ? 'done' : i === at ? 'now' : '' }, h('span', { class: 'dot' }, i < at || status === 'Completed' ? icon('check', 14) : i + 1), h('span', null, s))));
}

export async function orderPage(ctx) {
  if (!requireLogin()) return h('div');
  await loadSite().catch(() => {}); renderFooter(); renderAnnouncement();
  const no = ctx.params.orderNo;
  ctx.ttl = no;
  ctx.title = `Order ${no}`;
  const root = h('div', { class: 'page container section narrow' });
  let timer = null;
  ctx.onLeave(() => clearInterval(timer));

  async function load() {
    const d = await api(`/orders/${encodeURIComponent(no)}`);
    draw(d);
    return d;
  }

  function draw({ order: o, payment_method: m, events }) {
    const waiting = ['Pending', 'Payment Submitted', 'Processing'].includes(o.status);
    const body = [
      h('a', { class: 'crumb', href: '#/orders' }, '← All orders'),
      h('div', { class: 'card pad o-head' }, h('div', null, h('small', { class: 'muted' }, 'Order ID'), h('div', { class: 'o-id' }, h('b', { class: 'mono' }, o.order_no), h('button', { class: 'icon-btn', 'aria-label': 'Copy order ID', onclick: () => copyText(o.order_no) }, icon('copy', 16)))), statusBadge(o.status)),
      h('div', { class: 'card pad' }, timeline(o.status)),
      h('div', { class: 'grid grid-2 mt' },
        h('div', { class: 'card pad' }, h('h3', null, 'Order details'), h('dl', { class: 'kv' },
          kv('Game', o.game_name), kv('Package', o.product_name), o.quantity_label && o.quantity_label !== o.product_name ? kv('Quantity', o.quantity_label) : null,
          kv('Player ID', o.player_id), o.server_id ? kv('Server / Zone ID', o.server_id) : null,
          kv('Amount', money(o.price_bdt)), kv('Payment method', o.payment_method), kv('Payment status', o.payment_label),
          o.payment_trx_id ? kv('Transaction ID', o.payment_trx_id) : null, kv('Ordered', fmtDate(o.created_at)), kv('Last updated', fmtDate(o.updated_at)))),
        h('div', { class: 'card pad' }, paymentPanel(o, m))),
      events.length ? h('div', { class: 'card pad mt' }, h('h3', null, 'Activity'), h('ul', { class: 'events' }, [...events].reverse().map((e) => h('li', null, h('span', { class: 'rdot' }), h('div', null, h('b', null, e.status), h('p', null, e.note.replace(/ — NOTE:.*$/, '')), h('small', { class: 'muted' }, fmtDate(e.created_at))))))) : null,
    ];
    mount(root, ...body);
    const payFlag = ctx.query.pay;
    if (payFlag === 'paid') toast('Payment confirmed – your order is being processed.', 'success');
    else if (payFlag === 'failed') toast('We could not confirm the payment. If money left your account, tap “Re-check payment”.', 'error');
    else if (payFlag === 'cancelled') toast('Payment was cancelled. You can try again.', 'info');
    if (payFlag) history.replaceState(null, '', `#/order/${o.order_no}`);
    clearInterval(timer);
    if (waiting) timer = setInterval(() => { if (!document.hidden) api(`/orders/${encodeURIComponent(no)}`).then(draw).catch(() => {}); }, 20000);
  }

  function paymentPanel(o, m) {
    if (o.status === 'Cancelled') return h('div', null, h('h3', null, 'Payment'), h('p', { class: 'muted' }, 'This order was cancelled.'));
    if (o.payment_status === 'paid' || o.payment_status === 'refunded') return h('div', null, h('h3', null, 'Payment'), h('div', { class: 'alert alert-ok' }, icon('check', 18), h('span', null, o.payment_status === 'refunded' ? 'Payment refunded.' : o.status === 'Completed' ? 'Payment verified and top-up delivered.' : 'Payment verified. Your top-up is being processed.')));
    if (o.payment_status === 'submitted') return h('div', null, h('h3', null, 'Payment under review'), h('div', { class: 'alert alert-info' }, icon('clock', 18), h('span', null, `We received your Transaction ID (${o.payment_trx_id}) and are verifying it. This page updates automatically.`)));

    // unpaid or rejected
    const cancelBtn = h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: async (e) => {
      if (!confirm('Cancel this order?')) return;
      await withBusy(e.currentTarget, async () => { try { await api(`/orders/${o.order_no}/cancel`, { method: 'POST' }); toast('Order cancelled', 'success'); await load(); } catch (err) { toast(err.message, 'error'); } });
    } }, 'Cancel order');

    if (o.payment_method_type === 'gateway') {
      const pay = h('button', { class: 'btn btn-primary btn-block', type: 'button', onclick: async (e) => {
        await withBusy(e.currentTarget, async () => { try { const r = await api(`/orders/${o.order_no}/payment/gateway`, { method: 'POST' }); location.href = r.redirect_url; } catch (err) { toast(err.message, 'error'); } });
      } }, `Pay ${money(o.price_bdt)} with ${o.payment_method}`);
      const recheck = o.gateway_pending ? h('button', { class: 'btn btn-outline btn-block', type: 'button', onclick: async (e) => {
        await withBusy(e.currentTarget, async () => {
          try { const r = await api(`/orders/${o.order_no}/payment/gateway/recheck`, { method: 'POST' }); toast(r.outcome === 'paid' ? 'Payment confirmed!' : 'The provider has not confirmed a payment yet.', r.outcome === 'paid' ? 'success' : 'info'); await load(); }
          catch (err) { toast(err.message, 'error'); }
        });
      } }, 'Re-check payment') : null;
      return h('div', null, h('h3', null, 'Pay securely'), h('p', { class: 'muted' }, m?.instructions || 'You will be redirected to complete the payment.'), h('div', { class: 'stack' }, pay, recheck, o.gateway_pending ? null : cancelBtn),
        h('p', { class: 'fine' }, icon('lock', 14), ' Your order is marked paid only after the provider confirms the payment to our server.'));
    }

    // manual
    const trx = input({ placeholder: 'e.g. 9K4D2X7QPA', maxlength: 20, autocapitalize: 'characters', autocomplete: 'off', required: true });
    const sender = input({ type: 'tel', placeholder: '01XXXXXXXXX', autocomplete: 'tel', required: true });
    const err = h('div', { class: 'alert alert-error', hidden: true, role: 'alert' });
    const btn = h('button', { class: 'btn btn-primary btn-block', type: 'submit' }, 'Submit payment details');
    return h('div', null, h('h3', null, `Pay with ${o.payment_method}`),
      o.payment_status === 'rejected' ? h('div', { class: 'alert alert-error' }, icon('alert', 18), h('span', null, 'Your previous payment details could not be verified. Please check them and submit again.')) : null,
      m ? h('ol', { class: 'pay-steps' },
        h('li', null, 'Send exactly ', h('b', null, money(o.price_bdt)), ' to:', h('div', { class: 'acct-num' }, h('b', { class: 'mono' }, m.account_number), h('button', { class: 'icon-btn', 'aria-label': 'Copy number', onclick: () => copyText(m.account_number) }, icon('copy', 16)))),
        m.instructions ? h('li', null, m.instructions) : null,
        h('li', null, 'Enter the Transaction ID and the number you paid from below.')) : null,
      h('form', { class: 'form', novalidate: true, onsubmit: async (e) => {
        e.preventDefault(); err.hidden = true;
        await withBusy(btn, async () => { try { await api(`/orders/${o.order_no}/payment/manual`, { method: 'POST', body: { trx_id: trx.value, sender_number: sender.value } }); toast('Payment details submitted for verification', 'success'); await load(); } catch (ex) { err.textContent = ex.message; err.hidden = false; } });
      } }, err, field('Transaction ID (TrxID)', trx).el, field('Paid from (your number)', sender).el, btn),
      h('p', { class: 'fine' }, icon('shield', 14), ' Your order is processed only after our team verifies the payment. A screenshot is never enough on its own.'), h('div', { class: 'mt-s' }, cancelBtn));
  }

  const kv = (k, v) => h('div', null, h('dt', null, k), h('dd', null, v));
  mount(root, h('div', { class: 'center' }, spinner()));
  try { await load(); } catch (e) { if (e.status === 404) mount(root, emptyState('Order not found', 'We could not find that order on your account.', h('a', { class: 'btn btn-primary', href: '#/orders' }, 'My orders'))); else throw e; }
  return root;
}

// ───────────── public tracking ─────────────
export async function trackPage(ctx) {
  await loadSite().catch(() => {}); renderFooter(); renderAnnouncement();
  ctx.title = 'Track Order';
  const out = h('div', { class: 'track-out' });
  const inp = input({ placeholder: 'GZ-XXXXXXXXXX', maxlength: 20, autocapitalize: 'characters', autocomplete: 'off', value: ctx.query.id || '', 'aria-label': 'Order ID' });
  const btn = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Track');

  async function lookup() {
    const id = inp.value.trim().toUpperCase();
    if (!id) return;
    mount(out, h('div', { class: 'center' }, spinner()));
    try {
      const { order: o } = await api(`/track/${encodeURIComponent(id)}`);
      mount(out, h('div', { class: 'card pad' }, h('div', { class: 'o-head' }, h('div', null, h('small', { class: 'muted' }, 'Order ID'), h('b', { class: 'mono o-id' }, o.order_no)), statusBadge(o.status)),
        h('div', { class: 'mt-s' }, timeline(o.status)),
        h('dl', { class: 'kv mt' }, kv2('Game', o.game_name), kv2('Product', `${o.product_name}${o.quantity_label && o.quantity_label !== o.product_name ? ` (${o.quantity_label})` : ''}`),
          kv2('Amount', money(o.price_bdt)), kv2('Player ID', o.player_id_masked), kv2('Payment status', o.payment_label), kv2('Order status', o.status), kv2('Order date', fmtDate(o.created_at)), kv2('Last updated', fmtDate(o.updated_at)))));
    } catch (e) { mount(out, h('div', { class: 'alert alert-error' }, icon('alert', 18), h('span', null, e.message))); }
  }
  const kv2 = (k, v) => h('div', null, h('dt', null, k), h('dd', null, v));
  if (inp.value) lookup();
  return h('div', { class: 'page container section narrow' }, h('div', { class: 'page-head' }, h('h1', null, 'Track your order'), h('p', { class: 'muted' }, 'Enter your Order ID to see the latest status.')),
    h('form', { class: 'track-form card pad', onsubmit: (e) => { e.preventDefault(); history.replaceState(null, '', `#/track?id=${encodeURIComponent(inp.value.trim())}`); lookup(); } }, inp, btn), out,
    h('p', { class: 'fine center' }, 'For privacy, only part of the Player ID is shown here. Log in to see full order details.'));
}

// ───────────── support ─────────────
export async function supportPage(ctx) {
  const site = await loadSite(); renderFooter(); renderAnnouncement();
  ctx.title = 'Support';
  const s = site.settings;
  const channels = [
    s.support_whatsapp ? ['whatsapp', 'WhatsApp', s.support_whatsapp, `https://wa.me/${s.support_whatsapp.replace(/\D/g, '')}`] : null,
    safeUrl(s.support_telegram) ? ['telegram', 'Telegram', 'Chat with us', s.support_telegram] : null,
    safeUrl(s.support_facebook) ? ['facebook', 'Facebook', 'Message us', s.support_facebook] : null,
    s.support_email ? ['mail', 'Email', s.support_email, `mailto:${s.support_email}`] : null,
    s.support_phone ? ['phone', 'Phone', s.support_phone, `tel:${s.support_phone.replace(/[^\d+]/g, '')}`] : null,
  ].filter(Boolean);
  return h('div', { class: 'page container section narrow' }, h('div', { class: 'page-head' }, h('h1', null, 'Support'), h('p', { class: 'muted' }, 'Need help with an order? Have your Order ID ready.')),
    channels.length ? h('div', { class: 'grid grid-2' }, channels.map(([ic, label, text, href]) => h('a', { class: 'card pad contact', href, target: href.startsWith('http') ? '_blank' : null, rel: 'noopener noreferrer' }, icon(ic, 26), h('div', null, h('b', null, label), h('p', null, text)))))
      : h('div', { class: 'alert alert-info' }, icon('info', 18), h('span', null, 'Support contact details have not been added yet. Check the FAQ below or track your order status.')),
    h('h2', { class: 'mt' }, 'Frequently asked questions'), site.faqs.length ? faqList(site.faqs) : h('p', { class: 'muted' }, 'No FAQs yet.'),
    h('div', { class: 'card pad mt row-between' }, h('div', null, h('h3', null, 'Already ordered?'), h('p', { class: 'muted' }, 'Check where your top-up is right now.')), h('a', { class: 'btn btn-primary', href: '#/track' }, 'Track order')));
}
