// Shared helpers. Every piece of user/admin-supplied text is inserted as a text node (never as HTML),
// so stored content cannot inject markup or script.

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const PROPS = new Set(['value', 'checked', 'disabled', 'selected', 'hidden', 'required', 'readOnly', 'multiple']);

/** Hyperscript: h('div', {class:'x', onclick: fn}, 'text', childNode, [more]) */
export function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style' && typeof v === 'object') {
      // custom properties (--x) are ignored by Object.assign, so set them explicitly
      for (const [p, val] of Object.entries(v)) { if (p.startsWith('--')) el.style.setProperty(p, val); else el.style[p] = val; }
    }
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (PROPS.has(k)) el[k] = v;
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  append(el, kids);
  return el;
}

export function append(el, kids) {
  for (const k of kids.flat(Infinity)) {
    if (k === null || k === undefined || k === false) continue;
    el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  }
  return el;
}

export function mount(el, ...kids) { el.replaceChildren(); append(el, kids); return el; }

// ───────────── formatting ─────────────
const nf = new Intl.NumberFormat('en-IN');
export const money = (n) => `৳${nf.format(Number(n) || 0)}`;

const dtf = new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true, timeZone: 'Asia/Dhaka' });
export const fmtDate = (iso) => (iso ? dtf.format(new Date(iso)) : '—');

export function timeAgo(iso) {
  const s = Math.max(1, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return 'just now';
  const units = [[60, 'min'], [3600, 'hour'], [86400, 'day'], [2592000, 'month']];
  let out = `${Math.floor(s / 2592000)} months`;
  for (let i = 0; i < units.length; i++) {
    const next = units[i + 1];
    if (!next || s < next[0]) { const n = Math.floor(s / units[i][0]); out = `${n} ${units[i][1]}${n > 1 ? 's' : ''}`; break; }
  }
  return `${out} ago`;
}

/** Only allow http(s), absolute paths and in-app hash links. */
export function safeUrl(u) {
  const s = String(u || '').trim();
  if (/^https?:\/\/[^\s]+$/i.test(s) || /^\/(?!\/)[^\s]*$/.test(s) || /^#\/[^\s]*$/.test(s)) return s;
  return '';
}

export const discount = (p) => (p.old_price_bdt && p.old_price_bdt > p.price_bdt ? Math.round((1 - p.price_bdt / p.old_price_bdt) * 100) : 0);

export const debounce = (fn, ms = 250) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

// ───────────── icons ─────────────
const ICONS = {
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6"/>',
  bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  shield: '<path d="M12 3 4 6v6c0 5 3.4 8.4 8 9 4.6-.6 8-4 8-9V6z"/><path d="m9 12 2 2 4-4"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  check: '<path d="m5 12 5 5 9-10"/>',
  chevron: '<path d="m9 6 6 6-6 6"/>',
  down: '<path d="m6 9 6 6 6-6"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
  lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  star: '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
  box: '<path d="m3 7 9-4 9 4v10l-9 4-9-4z"/><path d="m3 7 9 4 9-4M12 11v10"/>',
  whatsapp: '<path d="M4 20l1.3-4.2A8 8 0 1 1 8.4 18.7z"/><path d="M9 9c0 3 3 6 6 6l1-2-2.5-1-1 .8c-1-.5-1.8-1.3-2.3-2.3l.8-1L10 7z"/>',
  telegram: '<path d="M21 4 3 11l5 2 2 6 3-4 5 4z"/><path d="m8 13 9-6"/>',
  facebook: '<path d="M14 8h3V4h-3a4 4 0 0 0-4 4v3H7v4h3v6h4v-6h3l1-4h-4V8z"/>',
  instagram: '<rect x="4" y="4" width="16" height="16" rx="5"/><circle cx="12" cy="12" r="3.5"/><circle cx="17" cy="7" r=".8"/>',
  youtube: '<rect x="3" y="6" width="18" height="12" rx="4"/><path d="m10 9.5 5 2.5-5 2.5z"/>',
  alert: '<path d="M12 3 2 20h20z"/><path d="M12 10v4M12 17.5v.5"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8v.5"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  logout: '<path d="M10 4H5v16h5M15 8l4 4-4 4M19 12H9"/>',
  grid: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
};

export function icon(name, size = 20) {
  const ns = 'http://www.w3.org/2000/svg';
  const s = document.createElementNS(ns, 'svg');
  s.setAttribute('viewBox', '0 0 24 24');
  s.setAttribute('width', size);
  s.setAttribute('height', size);
  s.setAttribute('fill', 'none');
  s.setAttribute('stroke', 'currentColor');
  s.setAttribute('stroke-width', '1.8');
  s.setAttribute('stroke-linecap', 'round');
  s.setAttribute('stroke-linejoin', 'round');
  s.setAttribute('aria-hidden', 'true');
  s.setAttribute('class', 'icon');
  s.innerHTML = ICONS[name] || '';
  return s;
}

// ───────────── toasts & small widgets ─────────────
export function toast(message, type = 'info') {
  let box = $('#toasts');
  if (!box) { box = h('div', { id: 'toasts', 'aria-live': 'polite' }); document.body.append(box); }
  const t = h('div', { class: `toast toast-${type}`, role: 'status' }, icon(type === 'error' ? 'alert' : type === 'success' ? 'check' : 'info', 18), h('span', null, message));
  box.append(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 300); }, 4200);
}

export const spinner = (cls = '') => h('span', { class: `spinner ${cls}`, role: 'progressbar', 'aria-label': 'Loading' });

export function skeletonGrid(n = 6, cls = 'sk-card') {
  return h('div', { class: 'grid grid-cards' }, Array.from({ length: n }, () => h('div', { class: `skeleton ${cls}` })));
}

export async function copyText(text) {
  try { await navigator.clipboard.writeText(text); toast('Copied to clipboard', 'success'); }
  catch { toast('Could not copy – please copy it manually', 'error'); }
}

/** Disable a button + show a spinner while an async action runs. */
export async function withBusy(btn, fn) {
  const label = btn.textContent;
  btn.disabled = true;
  btn.replaceChildren(spinner('sm'), ' Please wait…');
  try { return await fn(); }
  finally { btn.disabled = false; btn.textContent = label; }
}

export function statusClass(status) {
  return { Pending: 'st-pending', 'Payment Submitted': 'st-submitted', Processing: 'st-processing', Completed: 'st-completed', Cancelled: 'st-cancelled', Refunded: 'st-refunded' }[status] || '';
}
export const statusBadge = (status) => h('span', { class: `badge ${statusClass(status)}` }, status);
