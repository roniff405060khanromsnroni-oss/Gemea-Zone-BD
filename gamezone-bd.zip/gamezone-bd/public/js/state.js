import { api } from './api.js';

export const state = { user: null, site: null };

export const go = (path) => { location.hash = path; };
export const currentHash = () => location.hash.slice(1) || '/';

export function setUser(user) {
  state.user = user;
  document.dispatchEvent(new CustomEvent('gz:user'));
}

export async function loadSite() {
  state.site = await api('/site');
  return state.site;
}

export async function loadUser() {
  try { setUser((await api('/auth/me')).user); } catch { setUser(null); }
}

/** Redirect to login (remembering where to come back to) when not signed in. Returns true if allowed. */
export function requireLogin() {
  if (state.user) return true;
  go(`/login?next=${encodeURIComponent(currentHash())}`);
  return false;
}
