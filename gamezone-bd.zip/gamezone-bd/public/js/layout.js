import { h, mount, icon, safeUrl, debounce, money, $ } from './util.js';
import { api } from './api.js';
import { state, go, setUser } from './state.js';
import { toast } from './util.js';

const NAV = [['/', 'Home'], ['/games', 'All Games'], ['/orders', 'Orders'], ['/track', 'Track Order'], ['/support', 'Support']];

export function logo(cls = '') {
  return h('a', { class: `logo ${cls}`, href: '#/', 'aria-label': 'GAMEZONE BD – home' },
    h('img', { src: '/img/logo-mark.svg', alt: '', width: 38, height: 38 }),
    h('span', { class: 'logo-text' }, h('b', null, 'GAMEZONE'), h('i', null, ' BD')));
}

export function renderAnnouncement() {
  const el = $('#announce');
  const text = state.site?.settings.announcement;
  if (!el) return;
  el.replaceChildren();
  el.hidden = !text;
  if (text) el.append(h('div', { class: 'container' }, icon('bolt', 16), ' ', text));
}

export function renderHeader() {
  const hdr = $('#hdr');
  const path = (location.hash.slice(1) || '/').split('?')[0];
  const active = (p) => (p === '/' ? path === '/' : path === p || path.startsWith(`${p}/`) || (p === '/games' && path.startsWith('/game/')));
  const user = state.user;

  const links = NAV.map(([p, label]) => h('a', { href: `#${p}`, class: active(p) ? 'active' : '' , 'aria-current': active(p) ? 'page' : null }, label));

  const account = user
    ? h('div', { class: 'acct' },
        h('button', { class: 'btn btn-ghost acct-btn', 'aria-haspopup': 'true', onclick: (e) => { e.stopPropagation(); e.currentTarget.parentElement.classList.toggle('open'); } },
          h('span', { class: 'avatar' }, [...user.name][0].toUpperCase()), h('span', { class: 'acct-name' }, user.name.split(' ')[0]), icon('down', 16)),
        h('div', { class: 'acct-menu' },
          h('a', { href: '#/profile' }, icon('user', 16), ' My Profile'),
          h('a', { href: '#/orders' }, icon('box', 16), ' My Orders'),
          user.role === 'admin' ? h('a', { href: '/admin' }, icon('shield', 16), ' Admin Dashboard') : null,
          h('button', { onclick: logout }, icon('logout', 16), ' Log out')))
    : h('a', { class: `btn btn-primary btn-sm ${active('/login') ? 'is-active' : ''}`, href: '#/login' }, icon('user', 16), ' Login');

  const burger = h('button', { class: 'burger', 'aria-label': 'Open menu', 'aria-expanded': 'false', onclick: toggleDrawer }, icon('menu', 24));

  mount(hdr, h('div', { class: 'container hdr-in' },
    logo(), h('nav', { class: 'nav', 'aria-label': 'Main' }, links), h('div', { class: 'hdr-end' }, account, burger)));

  const drawer = h('div', { id: 'drawer', class: 'drawer', hidden: true },
    h('div', { class: 'drawer-in' }, links.map((l) => l.cloneNode(true)),
      user ? [h('a', { href: '#/profile' }, 'My Profile'), user.role === 'admin' ? h('a', { href: '/admin' }, 'Admin Dashboard') : null, h('button', { class: 'linklike', onclick: logout }, 'Log out')]
           : [h('a', { href: '#/login' }, 'Login'), h('a', { href: '#/register' }, 'Create account')]));
  hdr.append(drawer);
}

function toggleDrawer() {
  const d = $('#drawer');
  const open = d.hidden;
  d.hidden = !open;
  $('.burger').setAttribute('aria-expanded', String(open));
  document.body.classList.toggle('no-scroll', open);
}
export function closeMenus() {
  const d = $('#drawer');
  if (d && !d.hidden) { d.hidden = true; document.body.classList.remove('no-scroll'); $('.burger')?.setAttribute('aria-expanded', 'false'); }
  document.querySelectorAll('.acct.open').forEach((a) => a.classList.remove('open'));
}
document.addEventListener('click', (e) => { if (!e.target.closest('.acct')) document.querySelectorAll('.acct.open').forEach((a) => a.classList.remove('open')); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeMenus(); });

async function logout() {
  try { await api('/auth/logout', { method: 'POST' }); } catch { /* ignore */ }
  setUser(null);
  closeMenus();
  toast('You have been logged out', 'success');
  go('/');
}

export function renderFooter() {
  const s = state.site?.settings || {};
  const social = [
    ['whatsapp', s.support_whatsapp ? `https://wa.me/${s.support_whatsapp.replace(/\D/g, '')}` : '', 'WhatsApp'],
    ['telegram', s.support_telegram, 'Telegram'], ['facebook', s.support_facebook, 'Facebook'],
    ['instagram', s.support_instagram, 'Instagram'], ['youtube', s.support_youtube, 'YouTube'],
  ].filter(([, url]) => safeUrl(url));
  const methods = (state.site?.payment_methods || []).map((m) => h('span', { class: 'pm-pill', style: { '--c': m.brand_color } }, m.name));

  mount($('#ftr'), h('div', { class: 'container ftr-in' },
    h('div', { class: 'ftr-brand' }, logo(), h('p', null, s.footer_text),
      social.length ? h('div', { class: 'social' }, social.map(([ic, url, label]) => h('a', { href: safeUrl(url), target: '_blank', rel: 'noopener noreferrer', 'aria-label': label, title: label }, icon(ic, 20)))) : null),
    h('div', null, h('h4', null, 'Explore'), h('a', { href: '#/games' }, 'All Games'), h('a', { href: '#/orders' }, 'My Orders'), h('a', { href: '#/track' }, 'Track an Order'), h('a', { href: '#/support' }, 'Support & FAQ')),
    h('div', null, h('h4', null, 'Games'), (state.site?.games || []).slice(0, 5).map((g) => h('a', { href: `#/game/${g.slug}` }, g.name))),
    h('div', null, h('h4', null, 'We accept'), methods.length ? h('div', { class: 'pm-list' }, methods) : h('p', { class: 'muted small' }, 'bKash · Nagad · Rocket'),
      h('p', { class: 'muted small' }, 'Payments are verified before any order is processed. We never ask for game passwords.'))),
    h('div', { class: 'container ftr-bot' }, `© ${new Date().getFullYear()} ${s.site_name || 'GAMEZONE BD'}. All rights reserved.`));
}

// ───────────── search ─────────────
export function searchBox({ big = false } = {}) {
  const input = h('input', { type: 'search', placeholder: 'Search games or top-up packages…', 'aria-label': 'Search games and products', autocomplete: 'off', maxlength: 60 });
  const panel = h('div', { class: 'search-panel', hidden: true });
  const wrap = h('form', { class: `search ${big ? 'search-big' : ''}`, role: 'search', onsubmit: (e) => { e.preventDefault(); const q = input.value.trim(); if (q) { panel.hidden = true; go(`/games?q=${encodeURIComponent(q)}`); } } },
    icon('search', 20), input, h('button', { class: 'btn btn-primary btn-sm', type: 'submit' }, 'Search'), panel);

  let seq = 0;
  const run = debounce(async () => {
    const q = input.value.trim();
    if (q.length < 2) { panel.hidden = true; return; }
    const my = ++seq;
    try {
      const r = await api(`/search?q=${encodeURIComponent(q)}`);
      if (my !== seq) return;
      if (!r.games.length && !r.products.length) { mount(panel, h('div', { class: 'sp-empty' }, `No results for “${q}”`)); panel.hidden = false; return; }
      mount(panel,
        r.games.length ? h('div', { class: 'sp-h' }, 'Games') : null,
        r.games.map((g) => h('a', { class: 'sp-row', href: `#/game/${g.slug}` }, h('img', { src: safeUrl(g.image_url), alt: '', loading: 'lazy' }), h('span', null, g.name))),
        r.products.length ? h('div', { class: 'sp-h' }, 'Top-up packages') : null,
        r.products.map((p) => h('a', { class: 'sp-row', href: `#/game/${p.game_slug}?p=${p.id}` }, h('img', { src: safeUrl(p.image_url), alt: '', loading: 'lazy' }),
          h('span', null, `${p.game_name} · ${p.name}`), h('b', null, money(p.price_bdt)))));
      panel.hidden = false;
    } catch { panel.hidden = true; }
  }, 220);
  input.addEventListener('input', run);
  input.addEventListener('focus', () => { if (panel.childNodes.length) panel.hidden = false; });
  document.addEventListener('click', (e) => { if (!wrap.contains(e.target)) panel.hidden = true; });
  panel.addEventListener('click', () => { panel.hidden = true; });
  return wrap;
}
