import { $, h, mount, icon, skeletonGrid } from './util.js';
import { state, loadSite, loadUser, currentHash } from './state.js';
import { renderHeader, renderFooter, renderAnnouncement, closeMenus } from './layout.js';
import { homePage, gamesPage, gamePage, notFound } from './pages-store.js';
import { loginPage, registerPage, forgotPage, resetPage, profilePage, ordersPage, orderPage, trackPage, supportPage } from './pages-account.js';

const ROUTES = [
  ['/', homePage], ['/games', gamesPage], ['/game/:slug', gamePage],
  ['/login', loginPage], ['/register', registerPage], ['/forgot', forgotPage], ['/reset', resetPage],
  ['/profile', profilePage], ['/orders', ordersPage], ['/order/:orderNo', orderPage],
  ['/track', trackPage], ['/support', supportPage],
].map(([p, fn]) => {
  const keys = [];
  const re = new RegExp(`^${p.replace(/:([a-zA-Z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; })}/?$`);
  return { re, keys, fn };
});

const view = () => $('#view');
let leaveHooks = [];
let navId = 0;

function parse() {
  const raw = currentHash();
  const [path, qs = ''] = raw.split('?');
  return { path: path || '/', query: Object.fromEntries(new URLSearchParams(qs)) };
}

async function render() {
  const id = ++navId;
  leaveHooks.forEach((fn) => { try { fn(); } catch { /* ignore */ } });
  leaveHooks = [];
  closeMenus();
  const { path, query } = parse();

  let match = null;
  for (const r of ROUTES) { const m = r.re.exec(path); if (m) { match = { r, params: Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])])) }; break; } }

  const ctx = { path, query, params: match?.params || {}, title: '', onLeave: (fn) => leaveHooks.push(fn) };
  renderHeader();
  const loader = h('div', { class: 'page container section' }, skeletonGrid(6));
  mount(view(), loader);
  window.scrollTo({ top: 0 });

  let node;
  try {
    node = match ? await match.r.fn(ctx) : notFound();
  } catch (err) {
    console.error(err);
    node = h('div', { class: 'page container section' }, h('div', { class: 'empty' }, icon('alert', 36), h('h3', null, 'Something went wrong'), h('p', null, err.message || 'Please try again.'), h('button', { class: 'btn btn-primary', onclick: render }, 'Try again')));
  }
  if (id !== navId) return; // a newer navigation superseded this one
  mount(view(), node);
  const site = state.site?.settings.site_name || 'GAMEZONE BD';
  document.title = ctx.title ? `${ctx.title} · ${site}` : `${site} – ${state.site?.settings.tagline || 'Gaming Top-Up'}`;
  view().focus({ preventScroll: true });
}

document.addEventListener('gz:user', renderHeader);
window.addEventListener('hashchange', render);

(async function boot() {
  await Promise.all([loadUser(), loadSite().catch(() => null)]);
  renderAnnouncement();
  renderFooter();
  await render();
  $('#boot')?.remove();
})();
