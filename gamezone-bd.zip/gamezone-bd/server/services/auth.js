'use strict';
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const { get, run, tx, now } = require('../db');
const { config } = require('../lib/env');
const { setCookie } = require('../lib/http');

const scrypt = promisify(crypto.scrypt);
const COOKIE = 'gz_session';
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

// ───────────── passwords (scrypt, per-user random salt) ─────────────
const N = 16384, R = 8, P = 1;

async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password, salt, 64, { N, r: R, p: P });
  return `scrypt$${N}$${R}$${P}$${salt.toString('base64')}$${key.toString('base64')}`;
}

async function verifyPassword(password, stored) {
  const parts = String(stored || '').split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const [, n, r, p, salt, hash] = parts;
  const expected = Buffer.from(hash, 'base64');
  const key = await scrypt(password, Buffer.from(salt, 'base64'), expected.length, { N: +n, r: +r, p: +p });
  return crypto.timingSafeEqual(key, expected);
}

let dummyHash = null; // used so unknown e-mails cost the same time as wrong passwords
async function burnPasswordCheck(password) {
  dummyHash ??= await hashPassword('not-a-real-password');
  await verifyPassword(password, dummyHash);
}

// ───────────── sessions ─────────────
function createSession(ctx, userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  const maxAge = config.sessionDays * 86400;
  run(
    'INSERT INTO sessions (token_hash, user_id, expires_at, ip, user_agent) VALUES (?, ?, ?, ?, ?)',
    sha256(token), userId, new Date(Date.now() + maxAge * 1000).toISOString(), ctx.ip || '', String(ctx.req.headers['user-agent'] || '').slice(0, 200)
  );
  setCookie(ctx.res, COOKIE, token, { maxAge });
}

function destroySession(ctx) {
  const token = ctx.cookies[COOKIE];
  if (token) run('DELETE FROM sessions WHERE token_hash = ?', sha256(token));
  setCookie(ctx.res, COOKIE, '', { maxAge: 0, expires: new Date(0) });
}

function destroyUserSessions(userId, exceptToken) {
  if (exceptToken) run('DELETE FROM sessions WHERE user_id = ? AND token_hash <> ?', userId, sha256(exceptToken));
  else run('DELETE FROM sessions WHERE user_id = ?', userId);
}

/** Resolve the logged-in user (or null). Installed as the HTTP layer's user resolver. */
async function resolveUser(ctx) {
  const token = ctx.cookies[COOKIE];
  if (!token) return null;
  const row = get(
    `SELECT u.id, u.name, u.email, u.phone, u.role, u.status, u.created_at
       FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.token_hash = ? AND s.expires_at > ? AND u.status = 'active'`,
    sha256(token), now()
  );
  return row ? { ...row } : null;
}

function cleanupExpired() {
  run('DELETE FROM sessions WHERE expires_at <= ?', now());
  run('DELETE FROM password_resets WHERE expires_at <= ?', now());
}

// ───────────── password reset ─────────────
function createResetToken(userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  tx(() => {
    run('DELETE FROM password_resets WHERE user_id = ?', userId);
    run('INSERT INTO password_resets (token_hash, user_id, expires_at) VALUES (?, ?, ?)', sha256(token), userId, new Date(Date.now() + 3600_000).toISOString());
  });
  return token;
}

function findResetToken(token) {
  return get('SELECT * FROM password_resets WHERE token_hash = ? AND used_at IS NULL AND expires_at > ?', sha256(String(token || '')), now());
}

module.exports = {
  COOKIE, hashPassword, verifyPassword, burnPasswordCheck,
  createSession, destroySession, destroyUserSessions, resolveUser, cleanupExpired,
  createResetToken, findResetToken, sha256,
};
