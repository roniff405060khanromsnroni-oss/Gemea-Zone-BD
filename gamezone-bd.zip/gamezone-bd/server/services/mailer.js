'use strict';
// Tiny SMTP client (AUTH LOGIN, implicit TLS or STARTTLS). No dependencies.
// If SMTP_HOST is not set, the message is printed to the console instead (development only).
const net = require('node:net');
const tls = require('node:tls');
const { config } = require('../lib/env');

function isConfigured() { return !!config.smtp.host; }

function lineReader(socket) {
  let buf = '';
  const waiters = [];
  const onData = (d) => { buf += d.toString('utf8'); flush(); };
  function flush() {
    // a complete SMTP reply ends with a line like "250 text" (no dash after the code)
    while (waiters.length) {
      const lines = buf.split('\r\n');
      const idx = lines.findIndex((l) => /^\d{3} /.test(l));
      if (idx < 0) return;
      const reply = lines.slice(0, idx + 1);
      buf = lines.slice(idx + 1).join('\r\n');
      waiters.shift().resolve({ code: parseInt(reply[idx].slice(0, 3), 10), text: reply.join('\n') });
    }
  }
  socket.on('data', onData);
  socket.on('error', (e) => waiters.splice(0).forEach((w) => w.reject(e)));
  socket.on('close', () => waiters.splice(0).forEach((w) => w.reject(new Error('SMTP connection closed'))));
  return {
    read: () => new Promise((resolve, reject) => { waiters.push({ resolve, reject }); flush(); }),
    detach: () => socket.off('data', onData),
  };
}

async function sendViaSmtp({ to, subject, text }) {
  const c = config.smtp;
  const connect = () => new Promise((resolve, reject) => {
    const s = c.secure
      ? tls.connect({ host: c.host, port: c.port, servername: c.host }, () => resolve(s))
      : net.connect({ host: c.host, port: c.port }, () => resolve(s));
    s.setTimeout(20000, () => s.destroy(new Error('SMTP timeout')));
    s.once('error', reject);
  });

  let socket = await connect();
  let reader = lineReader(socket);
  const expect = async (codes) => {
    const r = await reader.read();
    if (!codes.includes(r.code)) throw new Error(`SMTP error: ${r.text}`);
    return r;
  };
  const cmd = async (line, codes) => { socket.write(line + '\r\n'); return expect(codes); };

  try {
    await expect([220]);
    let ehlo = await cmd('EHLO gamezone.local', [250]);
    if (!c.secure && /STARTTLS/i.test(ehlo.text)) {
      await cmd('STARTTLS', [220]);
      reader.detach();
      socket = await new Promise((resolve, reject) => {
        const t = tls.connect({ socket, servername: c.host }, () => resolve(t));
        t.once('error', reject);
      });
      reader = lineReader(socket);
      ehlo = await cmd('EHLO gamezone.local', [250]);
    }
    if (c.user) {
      await cmd('AUTH LOGIN', [334]);
      await cmd(Buffer.from(c.user).toString('base64'), [334]);
      await cmd(Buffer.from(c.pass).toString('base64'), [235]);
    }
    const fromAddr = (c.from.match(/<([^>]+)>/) || [null, c.from])[1];
    await cmd(`MAIL FROM:<${fromAddr}>`, [250]);
    await cmd(`RCPT TO:<${to}>`, [250, 251]);
    await cmd('DATA', [354]);
    const safe = (s) => String(s).replace(/[\r\n]+/g, ' ');
    const body = text.replace(/\r?\n/g, '\r\n').replace(/^\./gm, '..');
    socket.write(
      `From: ${safe(c.from)}\r\nTo: ${safe(to)}\r\nSubject: ${safe(subject)}\r\nMIME-Version: 1.0\r\n` +
      `Content-Type: text/plain; charset=utf-8\r\nDate: ${new Date().toUTCString()}\r\n\r\n${body}\r\n.\r\n`
    );
    await expect([250]);
    await cmd('QUIT', [221]).catch(() => {});
  } finally {
    socket.destroy();
  }
}

/** Returns { delivered: boolean }. Never throws – callers must not leak delivery failures to users. */
async function sendMail(mail) {
  if (!isConfigured()) {
    console.log(`\n[mail:not-configured] To: ${mail.to}\nSubject: ${mail.subject}\n${mail.text}\n`);
    return { delivered: false };
  }
  try {
    await sendViaSmtp(mail);
    return { delivered: true };
  } catch (err) {
    console.error('[mail] delivery failed:', err.message);
    return { delivered: false };
  }
}

module.exports = { sendMail, isConfigured };
