'use strict';
// bKash "Tokenized Checkout" integration (server-side only; credentials come from environment variables).
//
// Flow:  grant token → create payment → customer approves on bKash → bKash redirects to our callback
//        → we call EXECUTE (and QUERY as fallback) → we only mark an order paid when bKash itself says
//        Completed AND the amount and invoice number match our own order record.
//
// NOTE: endpoint paths/field names follow bKash's published tokenized-checkout API (v1.2.0-beta).
// Verify against the documentation bKash gives you and test in the SANDBOX before going live.
const { config } = require('../../lib/env');

const name = 'bKash';

function isConfigured() {
  const b = config.bkash;
  return !!(b.baseUrl && b.appKey && b.appSecret && b.username && b.password);
}

let tokenCache = null;

async function call(path, body, { authed } = {}) {
  const b = config.bkash;
  const headers = { 'Content-Type': 'application/json', Accept: 'application/json' };
  if (authed) { headers.Authorization = await getToken(); headers['X-APP-Key'] = b.appKey; }
  else { headers.username = b.username; headers.password = b.password; }

  const res = await fetch(b.baseUrl + path, { method: 'POST', headers, body: JSON.stringify(body), signal: AbortSignal.timeout(20000) });
  const text = await res.text();
  try { return JSON.parse(text); }
  catch { throw new Error(`bKash returned a non-JSON response (HTTP ${res.status})`); }
}

async function getToken() {
  if (tokenCache && tokenCache.exp > Date.now() + 30_000) return tokenCache.token;
  const b = config.bkash;
  const r = await call('/tokenized/checkout/token/grant', { app_key: b.appKey, app_secret: b.appSecret });
  if (!r.id_token) throw new Error(`bKash token error: ${r.statusMessage || r.message || 'no token returned'}`);
  tokenCache = { token: r.id_token, exp: Date.now() + (Number(r.expires_in) || 3600) * 1000 };
  return tokenCache.token;
}

async function createPayment({ amount, invoice, payerReference, callbackURL }) {
  const r = await call('/tokenized/checkout/create', {
    mode: '0011', payerReference, callbackURL,
    amount: Number(amount).toFixed(2), currency: 'BDT', intent: 'sale', merchantInvoiceNumber: invoice,
  }, { authed: true });
  if (r.statusCode !== '0000' || !r.bkashURL || !r.paymentID) {
    throw new Error(`bKash could not start the payment: ${r.statusMessage || r.errorMessage || 'unknown error'}`);
  }
  return { paymentId: r.paymentID, redirectUrl: r.bkashURL };
}

const execute = (paymentID) => call('/tokenized/checkout/execute', { paymentID }, { authed: true });
const query = (paymentID) => call('/tokenized/checkout/payment/status', { paymentID }, { authed: true });

function isGood(r, { amount, invoice }) {
  return !!r
    && r.transactionStatus === 'Completed'
    && Number(r.amount) === Number(amount)
    && String(r.merchantInvoiceNumber) === String(invoice)
    && (!r.currency || r.currency === 'BDT')
    && !!r.trxID;
}

/**
 * Ask bKash (server-to-server) whether this payment really completed.
 * Returns { ok, trxId, reason }.  `ok` is true only for a Completed payment that matches our order.
 */
async function verifyPayment(paymentId, expected, { executeFirst = true } = {}) {
  let r = null;
  if (executeFirst) {
    try { r = await execute(paymentId); } catch { r = null; }
    if (isGood(r, expected)) return { ok: true, trxId: r.trxID };
  }
  // execute may fail because it already ran (or a network blip) – the status query is the source of truth
  const q = await query(paymentId);
  if (isGood(q, expected)) return { ok: true, trxId: q.trxID };
  const status = q.transactionStatus || (r && r.transactionStatus) || '';
  const mismatch = q.transactionStatus === 'Completed' ? 'amount/invoice mismatch' : '';
  return { ok: false, reason: mismatch || status || q.statusMessage || 'not completed' };
}

module.exports = { name, isConfigured, createPayment, verifyPayment, _resetTokenCache: () => { tokenCache = null; } };
