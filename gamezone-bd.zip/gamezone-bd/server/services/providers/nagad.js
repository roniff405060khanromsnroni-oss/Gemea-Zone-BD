'use strict';
// Nagad merchant gateway – NOT IMPLEMENTED.
//
// Nagad's merchant API needs merchant-specific RSA keys and onboarding that only Nagad can issue, so no
// working integration can be shipped without them. This file only marks the extension point:
// implement `isConfigured`, `createPayment` and `verifyPayment` with the same shapes as providers/bkash.js,
// then set the Nagad payment method's type to "gateway" and provider to "nagad" in the admin panel.
//
// Until then Nagad works in MANUAL mode: the customer sends money, submits the TrxID, and an admin verifies it.

const name = 'Nagad';
const isConfigured = () => false;
const notImplemented = async () => { throw new Error('The Nagad gateway integration is not implemented. Use manual verification.'); };

module.exports = { name, isConfigured, createPayment: notImplemented, verifyPayment: notImplemented };
