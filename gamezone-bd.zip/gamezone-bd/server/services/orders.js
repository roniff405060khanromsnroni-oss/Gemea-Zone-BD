'use strict';
const crypto = require('node:crypto');
const { all, get, run, tx, now } = require('../db');
const { HttpError } = require('../lib/errors');
const { validate, normalizeBdMobile } = require('../lib/validate');
const { getSettings } = require('./settings');
const providers = { bkash: require('./providers/bkash'), nagad: require('./providers/nagad') };

const ORDER_STATUSES = ['Pending', 'Payment Submitted', 'Processing', 'Completed', 'Cancelled', 'Refunded'];
const PAYMENT_LABELS = {
  unpaid: 'Unpaid',
  submitted: 'Submitted – awaiting verification',
  paid: 'Paid',
  rejected: 'Rejected – please resubmit',
  refunded: 'Refunded',
};

// ───────────── payment methods ─────────────
function methodAvailable(m) {
  if (!m.enabled) return false;
  if (m.type === 'gateway') return !!providers[m.gateway_provider]?.isConfigured();
  return !!m.account_number; // manual methods need a receiving number to show customers
}

function listPaymentMethods({ onlyAvailable = true } = {}) {
  const rows = all('SELECT * FROM payment_methods ORDER BY sort_order, id').map((m) => ({ ...m, available: methodAvailable(m) }));
  return onlyAvailable ? rows.filter((m) => m.available) : rows;
}

const publicMethod = (m) => ({
  id: m.id, code: m.code, name: m.name, type: m.type, brand_color: m.brand_color,
  account_number: m.type === 'manual' ? m.account_number : '', instructions: m.instructions,
});

// ───────────── helpers ─────────────
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no I, O, 0, 1
function newOrderNo() {
  for (let i = 0; i < 10; i++) {
    const bytes = crypto.randomBytes(10);
    let s = 'GZ-';
    for (const b of bytes) s += ALPHABET[b % ALPHABET.length];
    if (!get('SELECT 1 FROM orders WHERE order_no = ?', s)) return s;
  }
  throw new HttpError(500, 'Could not create an order number');
}

function addEvent(orderId, { status, payment_status, note = '', actor = 'system' }) {
  run('INSERT INTO order_events (order_id, status, payment_status, note, actor, created_at) VALUES (?, ?, ?, ?, ?, ?)', orderId, status, payment_status, note, actor, now());
}

const maskId = (s) => (s.length <= 4 ? '••••' : '•'.repeat(Math.min(s.length - 3, 8)) + s.slice(-3));

function ownerView(o) {
  return {
    order_no: o.order_no, game_name: o.game_name, product_name: o.product_name, quantity_label: o.quantity_label,
    price_bdt: o.price_bdt, player_id: o.player_id, server_id: o.server_id,
    payment_method: o.payment_method_name, payment_method_type: o.payment_method_type,
    payment_status: o.payment_status, payment_label: PAYMENT_LABELS[o.payment_status], status: o.status,
    payment_trx_id: o.payment_trx_id || '', gateway_pending: !!o.gateway_payment_id && o.payment_status === 'unpaid',
    created_at: o.created_at, updated_at: o.updated_at,
  };
}

/** What anyone holding an order number may see (tracking page). No account identifiers. */
function trackingView(o) {
  return {
    order_no: o.order_no, game_name: o.game_name, product_name: o.product_name, quantity_label: o.quantity_label,
    price_bdt: o.price_bdt, player_id_masked: maskId(o.player_id),
    payment_status: o.payment_status, payment_label: PAYMENT_LABELS[o.payment_status], status: o.status,
    created_at: o.created_at, updated_at: o.updated_at,
  };
}

// ───────────── create ─────────────
function createOrder(user, input) {
  if (getSettings().maintenance_mode === '1') throw new HttpError(503, 'The store is temporarily closed for maintenance. Please try again soon.');

  const data = validate(input, {
    product_id: { type: 'int', required: true, min: 1, label: 'Package' },
    payment_method_id: { type: 'int', required: true, min: 1, label: 'Payment method' },
    player_id: { type: 'string', required: true, max: 30, label: 'Player ID' },
    server_id: { type: 'string', max: 20, label: 'Server ID' },
  });

  const p = get(
    `SELECT p.*, g.name AS game_name, g.active AS game_active, g.requires_server_id, g.player_id_pattern,
            g.server_id_pattern, g.player_id_label, g.server_id_label
       FROM products p JOIN games g ON g.id = p.game_id WHERE p.id = ?`, data.product_id);
  if (!p || !p.game_active) throw new HttpError(404, 'This package no longer exists');
  if (!p.available) throw new HttpError(409, 'This package is currently unavailable');

  const checkId = (value, pattern, label, fallback, fallbackMsg) => {
    let re = fallback;
    if (pattern) { try { re = new RegExp(pattern); } catch { /* bad admin pattern → fallback */ } }
    if (!re.test(value)) throw new HttpError(400, re === fallback ? fallbackMsg(label) : `${label} is not valid for this game`, { [label]: 'invalid' });
  };
  checkId(data.player_id, p.player_id_pattern, p.player_id_label, /^[A-Za-z0-9_.-]{3,30}$/, (l) => `${l} must be 3–30 letters/numbers`);
  let serverId = '';
  if (p.requires_server_id) {
    if (!data.server_id) throw new HttpError(400, `${p.server_id_label} is required for this game`);
    checkId(data.server_id, p.server_id_pattern, p.server_id_label, /^[A-Za-z0-9_.-]{1,20}$/, (l) => `${l} is not valid`);
    serverId = data.server_id;
  }

  const m = get('SELECT * FROM payment_methods WHERE id = ?', data.payment_method_id);
  if (!m || !methodAvailable(m)) throw new HttpError(400, 'Please choose an available payment method');

  const open = get(`SELECT COUNT(*) AS n FROM orders WHERE user_id = ? AND status = 'Pending' AND payment_status IN ('unpaid','rejected')`, user.id).n;
  if (open >= 5) throw new HttpError(429, 'You have several unpaid orders already. Please pay or cancel them first.');

  return tx(() => {
    const orderNo = newOrderNo();
    const t = now();
    const r = run(
      `INSERT INTO orders (order_no, user_id, game_id, product_id, game_name, product_name, quantity_label, price_bdt, player_id, server_id,
                           payment_method_id, payment_method_name, payment_method_type, gateway_provider, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      orderNo, user.id, p.game_id, p.id, p.game_name, p.name, p.quantity_label, p.price_bdt, data.player_id, serverId,
      m.id, m.name, m.type, m.type === 'gateway' ? m.gateway_provider : '', t, t);
    addEvent(Number(r.lastInsertRowid), { status: 'Pending', payment_status: 'unpaid', note: 'Order created', actor: `user:${user.id}` });
    return get('SELECT * FROM orders WHERE id = ?', Number(r.lastInsertRowid));
  });
}

// ───────────── customer actions ─────────────
function getOwnedOrder(user, orderNo) {
  const o = get('SELECT * FROM orders WHERE order_no = ? AND user_id = ?', String(orderNo).toUpperCase(), user.id);
  if (!o) throw new HttpError(404, 'Order not found');
  return o;
}

/** Customer says "I sent the money – here is my TrxID". This NEVER marks the order paid. */
function submitManualPayment(user, orderNo, input) {
  const data = validate(input, {
    trx_id: { type: 'string', required: true, upper: true, min: 6, max: 20, pattern: /^[A-Z0-9]+$/, patternMsg: 'Transaction ID must contain only letters and numbers', label: 'Transaction ID' },
    sender_number: { type: 'string', required: true, max: 20, label: 'Sender number' },
  });
  const sender = normalizeBdMobile(data.sender_number);
  if (!sender) throw new HttpError(400, 'Enter the Bangladeshi mobile number you paid from (e.g. 01XXXXXXXXX)');

  return tx(() => {
    const o = getOwnedOrder(user, orderNo);
    if (o.payment_method_type !== 'manual') throw new HttpError(400, 'This order is paid through the online gateway');
    if (o.status !== 'Pending' || !['unpaid', 'rejected'].includes(o.payment_status)) throw new HttpError(409, 'Payment details can no longer be submitted for this order');
    const dup = get(
      `SELECT order_no FROM orders WHERE payment_method_name = ? AND payment_trx_id = ? AND payment_status IN ('submitted','paid','refunded') AND id <> ?`,
      o.payment_method_name, data.trx_id, o.id);
    if (dup) throw new HttpError(409, 'This Transaction ID has already been used. If you think this is a mistake, contact support.');
    run(`UPDATE orders SET payment_status = 'submitted', status = 'Payment Submitted', payment_trx_id = ?, payment_sender = ?, updated_at = ? WHERE id = ?`, data.trx_id, sender, now(), o.id);
    addEvent(o.id, { status: 'Payment Submitted', payment_status: 'submitted', note: `Customer submitted TrxID ${data.trx_id} from ${sender}`, actor: `user:${user.id}` });
    return get('SELECT * FROM orders WHERE id = ?', o.id);
  });
}

function cancelOwnOrder(user, orderNo) {
  return tx(() => {
    const o = getOwnedOrder(user, orderNo);
    if (o.status !== 'Pending' || !['unpaid', 'rejected'].includes(o.payment_status) || o.gateway_payment_id) {
      throw new HttpError(409, 'This order can no longer be cancelled online. Please contact support.');
    }
    run(`UPDATE orders SET status = 'Cancelled', updated_at = ? WHERE id = ?`, now(), o.id);
    addEvent(o.id, { status: 'Cancelled', payment_status: o.payment_status, note: 'Cancelled by customer', actor: `user:${o.user_id}` });
    return get('SELECT * FROM orders WHERE id = ?', o.id);
  });
}

// ───────────── payment state changes (shared by manual verification and gateway callbacks) ─────────────
/**
 * Mark an order paid. Only ever called after (a) an admin verified the payment, or (b) the gateway
 * confirmed it server-to-server. Idempotent.
 */
function markPaid(orderId, { trxId, actor, note }) {
  return tx(() => {
    const o = get('SELECT * FROM orders WHERE id = ?', orderId);
    if (!o) throw new HttpError(404, 'Order not found');
    if (['paid', 'refunded'].includes(o.payment_status)) return { order: o, changed: false };
    const cancelled = o.status === 'Cancelled';
    const nextStatus = cancelled ? 'Cancelled' : 'Processing';
    const t = now();
    run(
      `UPDATE orders SET payment_status = 'paid', status = ?, payment_trx_id = COALESCE(?, payment_trx_id), paid_at = ?, updated_at = ?,
              verified_by = ? WHERE id = ?`,
      nextStatus, trxId || null, t, t, actor.startsWith('admin:') ? Number(actor.slice(6)) : null, orderId);
    addEvent(orderId, {
      status: nextStatus, payment_status: 'paid', actor,
      note: (note || 'Payment verified') + (cancelled ? ' — NOTE: order was already cancelled, a refund is required' : ''),
    });
    return { order: get('SELECT * FROM orders WHERE id = ?', orderId), changed: true };
  });
}

// ───────────── admin actions ─────────────
function verifyManualPayment(orderId, adminId) {
  const o = get('SELECT * FROM orders WHERE id = ?', orderId);
  if (!o) throw new HttpError(404, 'Order not found');
  if (o.payment_status !== 'submitted') throw new HttpError(409, 'Only orders with a submitted payment can be verified');
  return markPaid(orderId, { actor: `admin:${adminId}`, note: `Payment verified by admin (TrxID ${o.payment_trx_id})` }).order;
}

function rejectManualPayment(orderId, adminId, note) {
  return tx(() => {
    const o = get('SELECT * FROM orders WHERE id = ?', orderId);
    if (!o) throw new HttpError(404, 'Order not found');
    if (o.payment_status !== 'submitted') throw new HttpError(409, 'Only a submitted payment can be rejected');
    run(`UPDATE orders SET payment_status = 'rejected', status = 'Pending', updated_at = ?, admin_note = ? WHERE id = ?`, now(), note || o.admin_note, orderId);
    addEvent(orderId, { status: 'Pending', payment_status: 'rejected', note: `Payment rejected${note ? `: ${note}` : ''}`, actor: `admin:${adminId}` });
    return get('SELECT * FROM orders WHERE id = ?', orderId);
  });
}

/** Admin status changes, with rules so the status can never contradict the payment state. */
function setOrderStatus(orderId, target, adminId, note = '') {
  if (!ORDER_STATUSES.includes(target)) throw new HttpError(400, 'Unknown status');
  return tx(() => {
    const o = get('SELECT * FROM orders WHERE id = ?', orderId);
    if (!o) throw new HttpError(404, 'Order not found');
    if (o.status === target) throw new HttpError(409, `Order is already ${target}`);
    let ps = o.payment_status;

    switch (target) {
      case 'Pending':
        if (!['unpaid', 'rejected'].includes(ps)) throw new HttpError(409, 'Only unpaid orders can go back to Pending');
        break;
      case 'Payment Submitted':
        if (ps !== 'submitted') throw new HttpError(409, 'No payment has been submitted for this order');
        break;
      case 'Processing':
      case 'Completed':
        if (ps !== 'paid') throw new HttpError(409, 'Payment must be verified before processing or completing an order');
        if (o.status === 'Refunded') throw new HttpError(409, 'A refunded order cannot be reopened');
        break;
      case 'Cancelled':
        if (ps === 'paid') throw new HttpError(409, 'A paid order cannot be cancelled – mark it Refunded instead');
        if (ps === 'submitted') ps = 'rejected';
        break;
      case 'Refunded':
        if (ps !== 'paid') throw new HttpError(409, 'Only a paid order can be refunded');
        ps = 'refunded';
        break;
    }
    run(`UPDATE orders SET status = ?, payment_status = ?, updated_at = ?, admin_note = CASE WHEN ? <> '' THEN ? ELSE admin_note END WHERE id = ?`, target, ps, now(), note, note, orderId);
    addEvent(orderId, { status: target, payment_status: ps, note: note || `Status changed to ${target}`, actor: `admin:${adminId}` });
    return get('SELECT * FROM orders WHERE id = ?', orderId);
  });
}

module.exports = {
  ORDER_STATUSES, PAYMENT_LABELS, providers,
  methodAvailable, listPaymentMethods, publicMethod,
  createOrder, getOwnedOrder, submitManualPayment, cancelOwnOrder, markPaid,
  verifyManualPayment, rejectManualPayment, setOrderStatus,
  ownerView, trackingView, addEvent,
};
