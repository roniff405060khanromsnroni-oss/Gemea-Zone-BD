'use strict';
const { all, run, tx } = require('../db');

// key → default value. Only keys listed here can be read/written.
const DEFAULTS = {
  site_name: 'GAMEZONE BD',
  tagline: 'Your Gaming Top-Up Destination',
  hero_title: 'Level up your game. Top up in minutes.',
  hero_subtitle: 'Choose your game, enter your Player ID, pay with bKash, Nagad or Rocket, and track every order from start to finish.',
  announcement: '',
  support_whatsapp: '',
  support_telegram: '',
  support_facebook: '',
  support_instagram: '',
  support_youtube: '',
  support_email: '',
  support_phone: '',
  footer_text: 'GAMEZONE BD is an independent top-up service and is not affiliated with or endorsed by any game publisher. All game names and trademarks belong to their respective owners.',
  maintenance_mode: '0',
};

// everything above is safe to expose to the storefront
const PUBLIC_KEYS = Object.keys(DEFAULTS);

function getSettings() {
  const out = { ...DEFAULTS };
  for (const r of all('SELECT key, value FROM settings')) if (r.key in DEFAULTS) out[r.key] = r.value;
  return out;
}

function setSettings(values) {
  tx(() => {
    for (const [k, v] of Object.entries(values)) {
      if (!(k in DEFAULTS)) continue;
      run('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', k, String(v));
    }
  });
}

module.exports = { DEFAULTS, PUBLIC_KEYS, getSettings, setSettings };
