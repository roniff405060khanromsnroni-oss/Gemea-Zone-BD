'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { config } = require('./lib/env');

if (config.dbPath !== ':memory:') fs.mkdirSync(path.dirname(config.dbPath), { recursive: true });

const db = new DatabaseSync(config.dbPath);
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL;');

const cache = new Map();
function stmt(sql) {
  let s = cache.get(sql);
  if (!s) { s = db.prepare(sql); cache.set(sql, s); }
  return s;
}
const all = (sql, ...p) => stmt(sql).all(...p);
const get = (sql, ...p) => stmt(sql).get(...p);
const run = (sql, ...p) => stmt(sql).run(...p);

/** Run fn inside a write transaction (do not nest). */
function tx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const r = fn();
    db.exec('COMMIT');
    return r;
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch { /* ignore */ }
    throw e;
  }
}

const now = () => new Date().toISOString();
const TS = `strftime('%Y-%m-%dT%H:%M:%fZ','now')`;

// ───────────── migrations (append only; never edit an applied one) ─────────────
const MIGRATIONS = [
  {
    id: '001_initial',
    sql: `
CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  phone TEXT NOT NULL DEFAULT '',
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','banned')),
  created_at TEXT NOT NULL DEFAULT (${TS}),
  last_login_at TEXT
);

CREATE TABLE sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (${TS}),
  ip TEXT NOT NULL DEFAULT '',
  user_agent TEXT NOT NULL DEFAULT ''
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

CREATE TABLE password_resets (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL,
  used_at TEXT
);

CREATE TABLE games (
  id INTEGER PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  image_url TEXT NOT NULL DEFAULT '',
  banner_url TEXT NOT NULL DEFAULT '',
  currency_label TEXT NOT NULL DEFAULT 'Credits',
  requires_server_id INTEGER NOT NULL DEFAULT 0,
  player_id_label TEXT NOT NULL DEFAULT 'Player ID',
  server_id_label TEXT NOT NULL DEFAULT 'Server ID',
  player_id_pattern TEXT NOT NULL DEFAULT '',
  server_id_pattern TEXT NOT NULL DEFAULT '',
  featured INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (${TS})
);

CREATE TABLE categories (
  id INTEGER PRIMARY KEY,
  game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_categories_game ON categories(game_id);

CREATE TABLE products (
  id INTEGER PRIMARY KEY,
  game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  quantity_label TEXT NOT NULL DEFAULT '',
  image_url TEXT NOT NULL DEFAULT '',
  price_bdt INTEGER NOT NULL CHECK (price_bdt > 0),
  old_price_bdt INTEGER,
  available INTEGER NOT NULL DEFAULT 1,
  popular INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (${TS}),
  updated_at TEXT NOT NULL DEFAULT (${TS})
);
CREATE INDEX idx_products_game ON products(game_id);

CREATE TABLE payment_methods (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'manual' CHECK (type IN ('manual','gateway')),
  gateway_provider TEXT NOT NULL DEFAULT '',
  account_number TEXT NOT NULL DEFAULT '',
  instructions TEXT NOT NULL DEFAULT '',
  brand_color TEXT NOT NULL DEFAULT '#6366f1',
  enabled INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE orders (
  id INTEGER PRIMARY KEY,
  order_no TEXT NOT NULL UNIQUE,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  game_id INTEGER REFERENCES games(id) ON DELETE SET NULL,
  product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
  game_name TEXT NOT NULL,
  product_name TEXT NOT NULL,
  quantity_label TEXT NOT NULL DEFAULT '',
  price_bdt INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  server_id TEXT NOT NULL DEFAULT '',
  payment_method_id INTEGER REFERENCES payment_methods(id) ON DELETE SET NULL,
  payment_method_name TEXT NOT NULL,
  payment_method_type TEXT NOT NULL,
  gateway_provider TEXT NOT NULL DEFAULT '',
  payment_status TEXT NOT NULL DEFAULT 'unpaid' CHECK (payment_status IN ('unpaid','submitted','paid','rejected','refunded')),
  status TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending','Payment Submitted','Processing','Completed','Cancelled','Refunded')),
  payment_trx_id TEXT,
  payment_sender TEXT NOT NULL DEFAULT '',
  gateway_payment_id TEXT,
  paid_at TEXT,
  verified_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  admin_note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (${TS}),
  updated_at TEXT NOT NULL DEFAULT (${TS})
);
CREATE INDEX idx_orders_user ON orders(user_id, created_at);
CREATE INDEX idx_orders_status ON orders(status, created_at);
CREATE INDEX idx_orders_gateway ON orders(gateway_payment_id);
-- one TrxID can back only one live payment per payment method (stops re-use of a single payment)
CREATE UNIQUE INDEX idx_orders_trx_unique ON orders(payment_method_name, payment_trx_id)
  WHERE payment_trx_id IS NOT NULL AND payment_status IN ('submitted','paid','refunded');

CREATE TABLE order_events (
  id INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  payment_status TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  actor TEXT NOT NULL DEFAULT 'system',
  created_at TEXT NOT NULL DEFAULT (${TS})
);
CREATE INDEX idx_events_order ON order_events(order_id);

CREATE TABLE banners (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  subtitle TEXT NOT NULL DEFAULT '',
  image_url TEXT NOT NULL DEFAULT '',
  link_url TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE promotions (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  badge TEXT NOT NULL DEFAULT '',
  link_url TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE reviews (
  id INTEGER PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT NOT NULL,
  approved INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (${TS})
);

CREATE TABLE faqs (
  id INTEGER PRIMARY KEY,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT ''
);
`,
  },
];

function migrate() {
  db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (id TEXT PRIMARY KEY, applied_at TEXT NOT NULL)`);
  const done = new Set(all('SELECT id FROM schema_migrations').map((r) => r.id));
  const applied = [];
  for (const m of MIGRATIONS) {
    if (done.has(m.id)) continue;
    tx(() => {
      db.exec(m.sql);
      run('INSERT INTO schema_migrations (id, applied_at) VALUES (?, ?)', m.id, now());
    });
    applied.push(m.id);
  }
  return applied;
}

module.exports = { db, all, get, run, tx, now, migrate };
