'use strict';
const http = require('node:http');
const { config } = require('./lib/env');
const { migrate } = require('./db');
const { handle, setUserResolver } = require('./lib/http');
const auth = require('./services/auth');

require('./routes/auth');
require('./routes/public');
require('./routes/orders');
require('./routes/admin');

function createServer() {
  migrate();
  setUserResolver(auth.resolveUser);
  auth.cleanupExpired();
  const timer = setInterval(auth.cleanupExpired, 3600_000);
  timer.unref();
  const server = http.createServer((req, res) => { handle(req, res); });
  server.requestTimeout = 30_000;
  server.headersTimeout = 15_000;
  return server;
}

if (require.main === module) {
  if (config.isProd && !config.appUrl.startsWith('https://')) {
    console.warn('[warn] NODE_ENV=production but APP_URL is not https:// – payment callbacks and cookies need HTTPS.');
  }
  createServer().listen(config.port, () => {
    console.log(`GAMEZONE BD running at ${config.appUrl}  (admin: ${config.appUrl}/admin)`);
  });
}

module.exports = { createServer };
