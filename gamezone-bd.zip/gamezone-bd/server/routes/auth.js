'use strict';
const { get, run, now } = require('../db');
const { route, rateLimit, clearRate, HttpError } = require('../lib/http');
const { validate, normalizeBdMobile, EMAIL_RE, passwordRule } = require('../lib/validate');
const A = require('../services/auth');
const { sendMail } = require('../services/mailer');
const { config } = require('../lib/env');

const publicUser = (u) => u && ({ id: u.id, name: u.name, email: u.email, phone: u.phone, role: u.role, created_at: u.created_at });

function phoneOrEmpty(v) {
  if (!v) return '';
  const n = normalizeBdMobile(v);
  if (!n) throw new HttpError(400, 'Enter a valid Bangladeshi mobile number (01XXXXXXXXX)', { phone: 'invalid' });
  return n;
}

route('POST', '/api/auth/register', async (ctx) => {
  rateLimit(`register:${ctx.ip}`, 10, 3600_000);
  const d = validate(ctx.body, {
    name: { type: 'string', required: true, min: 2, max: 60, label: 'Name' },
    email: { type: 'string', required: true, lower: true, max: 254, pattern: EMAIL_RE, patternMsg: 'Enter a valid email address', label: 'Email' },
    phone: { type: 'string', max: 20, label: 'Phone' },
    password: passwordRule,
  });
  const phone = phoneOrEmpty(d.phone);
  if (get('SELECT 1 FROM users WHERE email = ?', d.email)) throw new HttpError(409, 'An account with this email already exists', { email: 'taken' });
  const hash = await A.hashPassword(d.password);
  const r = run('INSERT INTO users (name, email, phone, password_hash, last_login_at) VALUES (?, ?, ?, ?, ?)', d.name, d.email, phone, hash, now());
  const user = get('SELECT * FROM users WHERE id = ?', Number(r.lastInsertRowid));
  A.createSession(ctx, user.id);
  ctx.status = 201;
  return { user: publicUser(user) };
});

route('POST', '/api/auth/login', async (ctx) => {
  const email = String(ctx.body.email || '').trim().toLowerCase().slice(0, 254);
  const password = String(ctx.body.password || '').slice(0, 128);
  if (!email || !password) throw new HttpError(400, 'Enter your email and password');
  const key = `login:${ctx.ip}:${email}`;
  rateLimit(key, 8, 15 * 60_000);
  rateLimit(`login-ip:${ctx.ip}`, 40, 15 * 60_000);

  const user = get('SELECT * FROM users WHERE email = ?', email);
  const ok = user ? await A.verifyPassword(password, user.password_hash) : (await A.burnPasswordCheck(password), false);
  if (!ok) throw new HttpError(401, 'Incorrect email or password');
  if (user.status !== 'active') throw new HttpError(403, 'This account has been suspended. Please contact support.');
  clearRate(key);
  run('UPDATE users SET last_login_at = ? WHERE id = ?', now(), user.id);
  A.createSession(ctx, user.id);
  return { user: publicUser(user) };
});

route('POST', '/api/auth/logout', (ctx) => { A.destroySession(ctx); return { ok: true }; });

route('GET', '/api/auth/me', (ctx) => ({ user: publicUser(ctx.user) }));

route('PATCH', '/api/auth/profile', (ctx) => {
  const d = validate(ctx.body, {
    name: { type: 'string', required: true, min: 2, max: 60, label: 'Name' },
    phone: { type: 'string', max: 20, label: 'Phone' },
  });
  run('UPDATE users SET name = ?, phone = ? WHERE id = ?', d.name, phoneOrEmpty(d.phone), ctx.user.id);
  return { user: publicUser(get('SELECT * FROM users WHERE id = ?', ctx.user.id)) };
}, { auth: 'user' });

route('POST', '/api/auth/change-password', async (ctx) => {
  rateLimit(`chpw:${ctx.user.id}`, 8, 15 * 60_000);
  const d = validate(ctx.body, {
    current_password: { type: 'string', required: true, max: 128, label: 'Current password' },
    new_password: { ...passwordRule, label: 'New password' },
  });
  const u = get('SELECT * FROM users WHERE id = ?', ctx.user.id);
  if (!(await A.verifyPassword(d.current_password, u.password_hash))) throw new HttpError(400, 'Your current password is incorrect', { current_password: 'wrong' });
  run('UPDATE users SET password_hash = ? WHERE id = ?', await A.hashPassword(d.new_password), u.id);
  A.destroyUserSessions(u.id, ctx.cookies[A.COOKIE]); // sign out every other device
  return { ok: true };
}, { auth: 'user' });

// Always answers the same way so the form can't be used to discover which emails have accounts.
route('POST', '/api/auth/forgot-password', async (ctx) => {
  rateLimit(`forgot:${ctx.ip}`, 5, 3600_000);
  const email = String(ctx.body.email || '').trim().toLowerCase().slice(0, 254);
  const generic = { ok: true, message: 'If an account exists for that email, a reset link has been sent.' };
  if (!EMAIL_RE.test(email)) return generic;
  const user = get(`SELECT * FROM users WHERE email = ? AND status = 'active'`, email);
  if (!user) return generic;
  const token = A.createResetToken(user.id);
  const link = `${config.appUrl}/#/reset?token=${token}`;
  await sendMail({
    to: user.email,
    subject: 'Reset your GAMEZONE BD password',
    text: `Hi ${user.name},\n\nWe received a request to reset your password. Open this link within 1 hour:\n\n${link}\n\nIf you didn't ask for this, you can ignore this email.\n\n— GAMEZONE BD`,
  });
  return generic;
});

route('POST', '/api/auth/reset-password', async (ctx) => {
  rateLimit(`reset:${ctx.ip}`, 10, 3600_000);
  const d = validate(ctx.body, {
    token: { type: 'string', required: true, max: 100, label: 'Reset token' },
    password: passwordRule,
  });
  const rec = A.findResetToken(d.token);
  if (!rec) throw new HttpError(400, 'This reset link is invalid or has expired. Please request a new one.');
  run('UPDATE users SET password_hash = ? WHERE id = ?', await A.hashPassword(d.password), rec.user_id);
  run('UPDATE password_resets SET used_at = ? WHERE token_hash = ?', now(), rec.token_hash);
  A.destroyUserSessions(rec.user_id);
  return { ok: true };
});
