'use strict';
const { all, get, run } = require('../db');
const { route, rateLimit, HttpError } = require('../lib/http');
const { validate } = require('../lib/validate');
const { getSettings, PUBLIC_KEYS } = require('../services/settings');
const { listPaymentMethods, publicMethod } = require('../services/orders');

const gameCols = `id, slug, name, description, image_url, banner_url, currency_label, requires_server_id,
                  player_id_label, server_id_label, player_id_pattern, server_id_pattern, featured, sort_order`;
const productSelect = `SELECT p.id, p.game_id, p.category_id, p.name, p.quantity_label, p.image_url, p.price_bdt, p.old_price_bdt,
                              p.available, p.popular, g.slug AS game_slug, g.name AS game_name
                         FROM products p JOIN games g ON g.id = p.game_id`;

const maskName = (n) => (n ? `${[...n.trim()][0]}${'•'.repeat(3)}` : 'Gamer');
const like = (q) => `%${q.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;

route('GET', '/api/site', () => {
  const s = getSettings();
  const settings = Object.fromEntries(PUBLIC_KEYS.map((k) => [k, s[k]]));
  return {
    settings,
    games: all(`SELECT ${gameCols} FROM games WHERE active = 1 ORDER BY sort_order, id`),
    banners: all('SELECT id, title, subtitle, image_url, link_url FROM banners WHERE active = 1 ORDER BY sort_order, id'),
    promotions: all('SELECT id, title, description, badge, link_url FROM promotions WHERE active = 1 ORDER BY sort_order, id'),
    faqs: all('SELECT id, question, answer FROM faqs WHERE active = 1 ORDER BY sort_order, id'),
    popular: all(`${productSelect} WHERE p.popular = 1 AND p.available = 1 AND g.active = 1 ORDER BY g.sort_order, p.sort_order, p.id LIMIT 8`),
    offers: all(`${productSelect} WHERE p.old_price_bdt > p.price_bdt AND p.available = 1 AND g.active = 1
                  ORDER BY (p.old_price_bdt - p.price_bdt) * 1.0 / p.old_price_bdt DESC LIMIT 4`),
    reviews: all(`SELECT name, rating, comment, created_at FROM reviews WHERE approved = 1 ORDER BY created_at DESC LIMIT 9`),
    recent_orders: all(
      `SELECT o.game_name, o.quantity_label, o.product_name, o.updated_at, u.name AS user_name
         FROM orders o LEFT JOIN users u ON u.id = o.user_id WHERE o.status = 'Completed' ORDER BY o.updated_at DESC LIMIT 6`
    ).map((r) => ({ game_name: r.game_name, item: r.quantity_label || r.product_name, who: maskName(r.user_name), at: r.updated_at })),
    payment_methods: listPaymentMethods().map(publicMethod),
  };
});

route('GET', '/api/games/:slug', (ctx) => {
  const game = get(`SELECT ${gameCols} FROM games WHERE slug = ? AND active = 1`, ctx.params.slug);
  if (!game) throw new HttpError(404, 'Game not found');
  return {
    game,
    categories: all('SELECT id, name FROM categories WHERE game_id = ? ORDER BY sort_order, id', game.id),
    products: all(`${productSelect} WHERE p.game_id = ? ORDER BY p.sort_order, p.id`, game.id),
    payment_methods: listPaymentMethods().map(publicMethod),
  };
});

route('GET', '/api/search', (ctx) => {
  const q = String(ctx.query.q || '').trim().slice(0, 60);
  if (q.length < 2) return { games: [], products: [] };
  return {
    games: all(`SELECT slug, name, image_url FROM games WHERE active = 1 AND name LIKE ? ESCAPE '\\' ORDER BY sort_order LIMIT 6`, like(q)),
    products: all(
      `${productSelect} WHERE g.active = 1 AND p.available = 1 AND (p.name LIKE ? ESCAPE '\\' OR p.quantity_label LIKE ? ESCAPE '\\' OR g.name LIKE ? ESCAPE '\\')
        ORDER BY p.popular DESC, p.price_bdt LIMIT 8`, like(q), like(q), like(q)),
  };
});

// Customers who have a completed order may leave a review (held for admin approval).
route('POST', '/api/reviews', (ctx) => {
  rateLimit(`review:${ctx.user.id}`, 3, 3600_000);
  const d = validate(ctx.body, {
    rating: { type: 'int', required: true, min: 1, max: 5, label: 'Rating' },
    comment: { type: 'string', required: true, min: 5, max: 400, label: 'Review' },
  });
  if (!get(`SELECT 1 FROM orders WHERE user_id = ? AND status = 'Completed' LIMIT 1`, ctx.user.id)) {
    throw new HttpError(403, 'Reviews can be left after your first completed order');
  }
  if (get('SELECT 1 FROM reviews WHERE user_id = ?', ctx.user.id)) throw new HttpError(409, 'You have already submitted a review');
  run('INSERT INTO reviews (user_id, name, rating, comment, approved) VALUES (?, ?, ?, ?, 0)', ctx.user.id, ctx.user.name.slice(0, 40), d.rating, d.comment);
  ctx.status = 201;
  return { ok: true, message: 'Thanks! Your review will appear once it has been approved.' };
}, { auth: 'user' });
