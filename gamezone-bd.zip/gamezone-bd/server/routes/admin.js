'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { all, get, run, tx, now } = require('../db');
const { route, HttpError } = require('../lib/http');
const { validate, EMAIL_RE } = require('../lib/validate');
const { config } = require('../lib/env');
const { getSettings, setSettings, DEFAULTS } = require('../services/settings');
const { destroyUserSessions } = require('../services/auth');
const { isConfigured: smtpConfigured } = require('../services/mailer');
const O = require('../services/orders');
const { settleGateway } = require('./orders');

const A = { auth: 'admin' };
const slugify = (s) => String(s).toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40);

// ───────────── generic CRUD resources ─────────────
const sort = { type: 'int', min: -9999, max: 9999, default: 0, label: 'Sort order' };
const RESOURCES = {
  games: {
    table: 'games', order: 'sort_order, id',
    schema: {
      name: { type: 'string', required: true, min: 2, max: 60, label: 'Name' },
      slug: { type: 'string', max: 40, lower: true, pattern: /^[a-z0-9]+(-[a-z0-9]+)*$/, patternMsg: 'Slug may only contain lowercase letters, numbers and dashes', label: 'Slug' },
      description: { type: 'string', max: 300 },
      image_url: { type: 'string', max: 300, url: 'media', label: 'Image' },
      banner_url: { type: 'string', max: 300, url: 'media', label: 'Banner image' },
      currency_label: { type: 'string', max: 20, default: 'Credits', label: 'Currency label' },
      requires_server_id: { type: 'bool', label: 'Requires Server ID' },
      player_id_label: { type: 'string', max: 30, default: 'Player ID', label: 'Player ID label' },
      server_id_label: { type: 'string', max: 30, default: 'Server ID', label: 'Server ID label' },
      player_id_pattern: { type: 'string', max: 120, label: 'Player ID pattern' },
      server_id_pattern: { type: 'string', max: 120, label: 'Server ID pattern' },
      featured: { type: 'bool' }, active: { type: 'bool', default: 1 }, sort_order: sort,
    },
    prepare(d) {
      if (!d.slug && d.name) d.slug = slugify(d.name);
      if (d.slug !== undefined && !/^[a-z0-9]+(-[a-z0-9]+)*$/.test(d.slug)) throw new HttpError(400, 'Could not build a slug from that name – enter one manually');
      for (const k of ['player_id_pattern', 'server_id_pattern']) {
        if (d[k]) { try { new RegExp(d[k]); } catch { throw new HttpError(400, `${k.replace(/_/g, ' ')} is not a valid regular expression`); } }
      }
    },
  },
  categories: {
    table: 'categories', order: 'game_id, sort_order, id',
    list: () => all(`SELECT c.*, g.name AS game_name FROM categories c JOIN games g ON g.id = c.game_id ORDER BY g.sort_order, c.sort_order, c.id`),
    schema: {
      game_id: { type: 'int', required: true, min: 1, label: 'Game' },
      name: { type: 'string', required: true, min: 2, max: 60, label: 'Name' },
      sort_order: sort,
    },
    prepare(d) { if (d.game_id && !get('SELECT 1 FROM games WHERE id = ?', d.game_id)) throw new HttpError(400, 'Choose a valid game'); },
  },
  products: {
    table: 'products', order: 'game_id, sort_order, id',
    list: () => all(`SELECT p.*, g.name AS game_name, c.name AS category_name FROM products p
                       JOIN games g ON g.id = p.game_id LEFT JOIN categories c ON c.id = p.category_id
                      ORDER BY g.sort_order, p.sort_order, p.id`),
    schema: {
      game_id: { type: 'int', required: true, min: 1, label: 'Game' },
      category_id: { type: 'int', nullable: true, min: 1, label: 'Category' },
      name: { type: 'string', required: true, min: 2, max: 80, label: 'Product name' },
      quantity_label: { type: 'string', max: 40, label: 'Quantity label' },
      image_url: { type: 'string', max: 300, url: 'media', label: 'Image' },
      price_bdt: { type: 'int', required: true, min: 1, max: 1_000_000, label: 'Price (৳)' },
      old_price_bdt: { type: 'int', nullable: true, min: 1, max: 1_000_000, label: 'Old price (৳)' },
      available: { type: 'bool', default: 1 }, popular: { type: 'bool' }, sort_order: sort,
    },
    prepare(d, current) {
      const gameId = d.game_id ?? current?.game_id;
      if (d.game_id !== undefined && !get('SELECT 1 FROM games WHERE id = ?', d.game_id)) throw new HttpError(400, 'Choose a valid game');
      if (d.category_id && !get('SELECT 1 FROM categories WHERE id = ? AND game_id = ?', d.category_id, gameId)) throw new HttpError(400, 'That category belongs to a different game');
      const price = d.price_bdt ?? current?.price_bdt;
      if (d.old_price_bdt && price && d.old_price_bdt <= price) throw new HttpError(400, 'Old price must be higher than the current price (or leave it empty)');
      d.updated_at = now();
    },
  },
  payment_methods: {
    table: 'payment_methods', order: 'sort_order, id',
    list: () => O.listPaymentMethods({ onlyAvailable: false }).map((m) => ({ ...m, gateway_ready: m.type === 'gateway' ? !!O.providers[m.gateway_provider]?.isConfigured() : null })),
    schema: {
      code: { type: 'string', required: true, lower: true, max: 20, pattern: /^[a-z0-9_-]{2,20}$/, patternMsg: 'Code: 2–20 lowercase letters, numbers, - or _', label: 'Code' },
      name: { type: 'string', required: true, min: 2, max: 40, label: 'Name' },
      type: { type: 'string', required: true, enum: ['manual', 'gateway'], label: 'Type' },
      gateway_provider: { type: 'string', enum: ['', 'bkash', 'nagad'], label: 'Gateway provider' },
      account_number: { type: 'string', max: 40, label: 'Receiving number' },
      instructions: { type: 'string', max: 600, label: 'Instructions' },
      brand_color: { type: 'string', max: 7, pattern: /^#[0-9a-fA-F]{6}$/, default: '#6366f1', patternMsg: 'Colour must look like #e2136e', label: 'Brand colour' },
      enabled: { type: 'bool' }, sort_order: sort,
    },
    prepare(d, current) {
      const type = d.type ?? current?.type;
      const provider = d.gateway_provider ?? current?.gateway_provider;
      if (type === 'gateway' && !provider) throw new HttpError(400, 'Choose a gateway provider for gateway payment methods');
      if (type === 'manual') d.gateway_provider = '';
    },
  },
  banners: {
    table: 'banners', order: 'sort_order, id',
    schema: {
      title: { type: 'string', required: true, max: 80, label: 'Title' },
      subtitle: { type: 'string', max: 160 },
      image_url: { type: 'string', max: 300, url: 'media', label: 'Image' },
      link_url: { type: 'string', max: 300, url: 'link', label: 'Link' },
      active: { type: 'bool', default: 1 }, sort_order: sort,
    },
  },
  promotions: {
    table: 'promotions', order: 'sort_order, id',
    schema: {
      title: { type: 'string', required: true, max: 80, label: 'Title' },
      description: { type: 'string', max: 240 },
      badge: { type: 'string', max: 20, label: 'Badge text' },
      link_url: { type: 'string', max: 300, url: 'link', label: 'Link' },
      active: { type: 'bool', default: 1 }, sort_order: sort,
    },
  },
  reviews: {
    table: 'reviews', order: 'created_at DESC',
    schema: {
      name: { type: 'string', required: true, max: 40, label: 'Name' },
      rating: { type: 'int', required: true, min: 1, max: 5, label: 'Rating' },
      comment: { type: 'string', required: true, min: 5, max: 400, label: 'Review' },
      approved: { type: 'bool' },
    },
  },
  faqs: {
    table: 'faqs', order: 'sort_order, id',
    schema: {
      question: { type: 'string', required: true, max: 160, label: 'Question' },
      answer: { type: 'string', required: true, max: 800, label: 'Answer' },
      active: { type: 'bool', default: 1 }, sort_order: sort,
    },
  },
};

function resource(name) {
  const r = RESOURCES[name];
  if (!r) throw new HttpError(404, 'Unknown resource');
  return r;
}

function friendlyDbError(err) {
  if (err instanceof HttpError) return err;
  const msg = String(err.message || '');
  if (msg.includes('UNIQUE constraint failed')) return new HttpError(409, 'That value is already in use – choose a different one');
  if (msg.includes('FOREIGN KEY constraint failed')) return new HttpError(409, 'This item is still linked to other records');
  return err;
}

route('GET', '/api/admin/r/:name', (ctx) => {
  const r = resource(ctx.params.name);
  return { items: r.list ? r.list() : all(`SELECT * FROM ${r.table} ORDER BY ${r.order}`) };
}, A);

route('POST', '/api/admin/r/:name', (ctx) => {
  const r = resource(ctx.params.name);
  const d = validate(ctx.body, r.schema);
  try {
    r.prepare?.(d, null);
    const keys = Object.keys(d);
    const res = run(`INSERT INTO ${r.table} (${keys.join(', ')}) VALUES (${keys.map(() => '?').join(', ')})`, ...keys.map((k) => d[k]));
    ctx.status = 201;
    return { item: get(`SELECT * FROM ${r.table} WHERE id = ?`, Number(res.lastInsertRowid)) };
  } catch (e) { throw friendlyDbError(e); }
}, A);

route('PUT', '/api/admin/r/:name/:id', (ctx) => {
  const r = resource(ctx.params.name);
  const id = Number(ctx.params.id);
  const current = get(`SELECT * FROM ${r.table} WHERE id = ?`, id);
  if (!current) throw new HttpError(404, 'Not found');
  const d = validate(ctx.body, r.schema, { partial: true });
  try {
    r.prepare?.(d, current);
    const keys = Object.keys(d);
    if (keys.length) run(`UPDATE ${r.table} SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ?`, ...keys.map((k) => d[k]), id);
    return { item: get(`SELECT * FROM ${r.table} WHERE id = ?`, id) };
  } catch (e) { throw friendlyDbError(e); }
}, A);

route('DELETE', '/api/admin/r/:name/:id', (ctx) => {
  const r = resource(ctx.params.name);
  const res = run(`DELETE FROM ${r.table} WHERE id = ?`, Number(ctx.params.id));
  if (!res.changes) throw new HttpError(404, 'Not found');
  return { ok: true };
}, A);

// ───────────── dashboard ─────────────
route('GET', '/api/admin/stats', () => {
  const one = (sql, ...p) => get(sql, ...p).n;
  const since = new Date(Date.now() - 6 * 86400_000).toISOString().slice(0, 10);
  const byDay = new Map(all(
    `SELECT substr(created_at, 1, 10) AS day, COUNT(*) AS orders,
            COALESCE(SUM(CASE WHEN status = 'Completed' THEN price_bdt END), 0) AS revenue
       FROM orders WHERE created_at >= ? GROUP BY day`, since).map((r) => [r.day, r]));
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const day = new Date(Date.now() - i * 86400_000).toISOString().slice(0, 10);
    days.push({ day, orders: byDay.get(day)?.orders ?? 0, revenue: byDay.get(day)?.revenue ?? 0 });
  }
  return {
    total_users: one('SELECT COUNT(*) AS n FROM users'),
    total_orders: one('SELECT COUNT(*) AS n FROM orders'),
    pending_orders: one(`SELECT COUNT(*) AS n FROM orders WHERE status IN ('Pending','Payment Submitted')`),
    awaiting_verification: one(`SELECT COUNT(*) AS n FROM orders WHERE payment_status = 'submitted'`),
    processing_orders: one(`SELECT COUNT(*) AS n FROM orders WHERE status = 'Processing'`),
    completed_orders: one(`SELECT COUNT(*) AS n FROM orders WHERE status = 'Completed'`),
    total_revenue: one(`SELECT COALESCE(SUM(price_bdt), 0) AS n FROM orders WHERE status = 'Completed'`),
    total_products: one('SELECT COUNT(*) AS n FROM products'),
    last_7_days: days,
    recent: all(`SELECT o.id, o.order_no, o.game_name, o.product_name, o.quantity_label, o.price_bdt, o.status, o.payment_status, o.created_at FROM orders o ORDER BY o.id DESC LIMIT 8`),
  };
}, A);

route('GET', '/api/admin/system', () => ({
  app_url: config.appUrl, production: config.isProd, cookie_secure: config.cookieSecure,
  smtp_configured: smtpConfigured(),
  gateways: Object.entries(O.providers).map(([key, p]) => ({ key, name: p.name, configured: p.isConfigured() })),
}), A);

// ───────────── orders ─────────────
const adminOrderCols = `o.*, u.name AS user_name, u.email AS user_email, u.phone AS user_phone`;

route('GET', '/api/admin/orders', (ctx) => {
  const where = [];
  const p = [];
  const { status, payment_status: ps, q } = ctx.query;
  if (status && O.ORDER_STATUSES.includes(status)) { where.push('o.status = ?'); p.push(status); }
  if (ps && Object.keys(O.PAYMENT_LABELS).includes(ps)) { where.push('o.payment_status = ?'); p.push(ps); }
  if (q) {
    const l = `%${String(q).trim().slice(0, 60).replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
    where.push(`(o.order_no LIKE ? ESCAPE '\\' OR o.player_id LIKE ? ESCAPE '\\' OR o.payment_trx_id LIKE ? ESCAPE '\\' OR u.email LIKE ? ESCAPE '\\' OR o.payment_sender LIKE ? ESCAPE '\\')`);
    p.push(l, l, l, l, l);
  }
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const perPage = 20;
  const page = Math.max(1, parseInt(ctx.query.page, 10) || 1);
  const total = get(`SELECT COUNT(*) AS n FROM orders o LEFT JOIN users u ON u.id = o.user_id ${w}`, ...p).n;
  const items = all(`SELECT ${adminOrderCols} FROM orders o LEFT JOIN users u ON u.id = o.user_id ${w} ORDER BY o.id DESC LIMIT ? OFFSET ?`, ...p, perPage, (page - 1) * perPage);
  return { items, total, page, per_page: perPage };
}, A);

const orderDetail = (id) => {
  const order = get(`SELECT ${adminOrderCols} FROM orders o LEFT JOIN users u ON u.id = o.user_id WHERE o.id = ?`, id);
  if (!order) throw new HttpError(404, 'Order not found');
  return { order, events: all('SELECT * FROM order_events WHERE order_id = ? ORDER BY id', id) };
};

route('GET', '/api/admin/orders/:id', (ctx) => orderDetail(Number(ctx.params.id)), A);
route('POST', '/api/admin/orders/:id/verify-payment', (ctx) => { O.verifyManualPayment(Number(ctx.params.id), ctx.user.id); return orderDetail(Number(ctx.params.id)); }, A);
route('POST', '/api/admin/orders/:id/reject-payment', (ctx) => {
  const { note } = validate(ctx.body, { note: { type: 'string', max: 200 } });
  O.rejectManualPayment(Number(ctx.params.id), ctx.user.id, note);
  return orderDetail(Number(ctx.params.id));
}, A);
route('POST', '/api/admin/orders/:id/status', (ctx) => {
  const d = validate(ctx.body, { status: { type: 'string', required: true, enum: O.ORDER_STATUSES }, note: { type: 'string', max: 200 } });
  O.setOrderStatus(Number(ctx.params.id), d.status, ctx.user.id, d.note);
  return orderDetail(Number(ctx.params.id));
}, A);
route('POST', '/api/admin/orders/:id/gateway-recheck', async (ctx) => {
  const o = get('SELECT * FROM orders WHERE id = ?', Number(ctx.params.id));
  if (!o) throw new HttpError(404, 'Order not found');
  if (o.payment_method_type !== 'gateway' || !o.gateway_payment_id) throw new HttpError(409, 'This order has no online payment to re-check');
  const outcome = await settleGateway(o, { executeFirst: false });
  return { outcome, ...orderDetail(o.id) };
}, A);

// ───────────── users ─────────────
route('GET', '/api/admin/users', (ctx) => {
  const q = String(ctx.query.q || '').trim().slice(0, 60);
  const l = `%${q.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
  const items = all(
    `SELECT u.id, u.name, u.email, u.phone, u.role, u.status, u.created_at, u.last_login_at,
            (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id) AS orders
       FROM users u WHERE (? = '' OR u.name LIKE ? ESCAPE '\\' OR u.email LIKE ? ESCAPE '\\') ORDER BY u.id DESC LIMIT 200`, q, l, l);
  return { items };
}, A);

route('PATCH', '/api/admin/users/:id', (ctx) => {
  const id = Number(ctx.params.id);
  const d = validate(ctx.body, {
    role: { type: 'string', enum: ['user', 'admin'] },
    status: { type: 'string', enum: ['active', 'banned'] },
  }, { partial: true });
  const u = get('SELECT * FROM users WHERE id = ?', id);
  if (!u) throw new HttpError(404, 'User not found');
  if (id === ctx.user.id && (d.role && d.role !== 'admin' || d.status === 'banned')) throw new HttpError(409, 'You cannot demote or suspend your own account');
  if (d.role === 'user' && u.role === 'admin' && get(`SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND status = 'active'`).n <= 1) throw new HttpError(409, 'At least one active administrator is required');
  tx(() => {
    for (const [k, v] of Object.entries(d)) run(`UPDATE users SET ${k} = ? WHERE id = ?`, v, id);
    if (d.status === 'banned' || d.role) destroyUserSessions(id);
  });
  return { user: get('SELECT id, name, email, phone, role, status FROM users WHERE id = ?', id) };
}, A);

// ───────────── website settings ─────────────
const settingsSchema = {
  site_name: { type: 'string', required: true, min: 2, max: 40, label: 'Site name' },
  tagline: { type: 'string', max: 80 },
  hero_title: { type: 'string', max: 100, label: 'Hero title' },
  hero_subtitle: { type: 'string', max: 240, label: 'Hero subtitle' },
  announcement: { type: 'string', max: 200 },
  support_whatsapp: { type: 'string', max: 20, pattern: /^\+?[0-9]{8,15}$/, patternMsg: 'WhatsApp number: digits only, e.g. 8801XXXXXXXXX', label: 'WhatsApp number' },
  support_telegram: { type: 'string', max: 200, url: 'http', label: 'Telegram link' },
  support_facebook: { type: 'string', max: 200, url: 'http', label: 'Facebook link' },
  support_instagram: { type: 'string', max: 200, url: 'http', label: 'Instagram link' },
  support_youtube: { type: 'string', max: 200, url: 'http', label: 'YouTube link' },
  support_email: { type: 'string', max: 120, pattern: EMAIL_RE, patternMsg: 'Enter a valid support email', label: 'Support email' },
  support_phone: { type: 'string', max: 20, label: 'Support phone' },
  footer_text: { type: 'string', max: 400 },
  maintenance_mode: { type: 'bool', label: 'Maintenance mode' },
};

route('GET', '/api/admin/settings', () => ({ settings: getSettings(), keys: Object.keys(DEFAULTS) }), A);
route('PUT', '/api/admin/settings', (ctx) => {
  const d = validate(ctx.body, settingsSchema, { partial: true });
  if ('maintenance_mode' in d) d.maintenance_mode = String(d.maintenance_mode);
  setSettings(d);
  return { settings: getSettings() };
}, A);

// ───────────── image upload ─────────────
function sniffImage(b) {
  if (b.length > 12 && b[0] === 0x89 && b.toString('latin1', 1, 4) === 'PNG') return 'png';
  if (b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpg';
  if (b.length > 12 && b.toString('latin1', 0, 4) === 'RIFF' && b.toString('latin1', 8, 12) === 'WEBP') return 'webp';
  if (b.length > 6 && b.toString('latin1', 0, 4) === 'GIF8') return 'gif';
  return null;
}

route('POST', '/api/admin/upload', (ctx) => {
  const ext = sniffImage(ctx.raw);
  if (!ext) throw new HttpError(400, 'Only PNG, JPG, WEBP or GIF images are allowed');
  fs.mkdirSync(config.uploadDir, { recursive: true });
  const name = `${crypto.randomBytes(12).toString('hex')}.${ext}`;
  fs.writeFileSync(path.join(config.uploadDir, name), ctx.raw);
  ctx.status = 201;
  return { url: `/uploads/${name}` };
}, { auth: 'admin', raw: 3_000_000 });

module.exports = { RESOURCES };
