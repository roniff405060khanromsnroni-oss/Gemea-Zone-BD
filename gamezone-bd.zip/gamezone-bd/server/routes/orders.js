'use strict';
const { all, get, run, now } = require('../db');
const { route, rateLimit, HttpError } = require('../lib/http');
const { config } = require('../lib/env');
const O = require('../services/orders');

// ───────────── customer orders ─────────────
route('POST', '/api/orders', (ctx) => {
  rateLimit(`order:${ctx.user.id}`, 20, 3600_000);
  const order = O.createOrder(ctx.user, ctx.body);
  ctx.status = 201;
  return { order: O.ownerView(order) };
}, { auth: 'user' });

route('GET', '/api/orders', (ctx) =>
  ({ orders: all('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 200', ctx.user.id).map(O.ownerView) }), { auth: 'user' });

route('GET', '/api/orders/:orderNo', (ctx) => {
  const o = O.getOwnedOrder(ctx.user, ctx.params.orderNo);
  const m = o.payment_method_id ? get('SELECT * FROM payment_methods WHERE id = ?', o.payment_method_id) : null;
  return {
    order: O.ownerView(o),
    payment_method: m ? O.publicMethod(m) : null,
    events: all('SELECT status, payment_status, note, created_at FROM order_events WHERE order_id = ? ORDER BY id', o.id)
      .map((e) => ({ status: e.status, payment_status: e.payment_status, created_at: e.created_at, note: e.note })),
  };
}, { auth: 'user' });

route('POST', '/api/orders/:orderNo/payment/manual', (ctx) => {
  rateLimit(`pay-manual:${ctx.user.id}`, 20, 3600_000);
  return { order: O.ownerView(O.submitManualPayment(ctx.user, ctx.params.orderNo, ctx.body)) };
}, { auth: 'user' });

route('POST', '/api/orders/:orderNo/cancel', (ctx) => ({ order: O.ownerView(O.cancelOwnOrder(ctx.user, ctx.params.orderNo)) }), { auth: 'user' });

// ───────────── public tracking ─────────────
route('GET', '/api/track/:orderNo', (ctx) => {
  rateLimit(`track:${ctx.ip}`, 40, 60_000);
  const no = String(ctx.params.orderNo).trim().toUpperCase().slice(0, 20);
  const o = get('SELECT * FROM orders WHERE order_no = ?', no);
  if (!o) throw new HttpError(404, 'No order found with that Order ID. Please check it and try again.');
  return { order: O.trackingView(o) };
});

// ───────────── online gateway payments ─────────────
function gatewayFor(order) {
  const provider = O.providers[order.gateway_provider];
  if (order.payment_method_type !== 'gateway' || !provider || !provider.isConfigured()) {
    throw new HttpError(503, 'Online payment is not available for this order right now. Please contact support.');
  }
  return provider;
}

route('POST', '/api/orders/:orderNo/payment/gateway', async (ctx) => {
  rateLimit(`pay-gw:${ctx.user.id}`, 15, 3600_000);
  const o = O.getOwnedOrder(ctx.user, ctx.params.orderNo);
  const provider = gatewayFor(o);
  if (o.status !== 'Pending' || !['unpaid', 'rejected'].includes(o.payment_status)) throw new HttpError(409, 'This order cannot be paid right now');
  let created;
  try {
    created = await provider.createPayment({
      amount: o.price_bdt, invoice: o.order_no, payerReference: o.player_id.slice(0, 30),
      callbackURL: `${config.appUrl}/api/payments/${o.gateway_provider}/callback`,
    });
  } catch (err) {
    console.error('[payment] create failed:', err.message);
    throw new HttpError(502, 'The payment provider could not start the payment. Please try again or use another method.');
  }
  run('UPDATE orders SET gateway_payment_id = ?, updated_at = ? WHERE id = ?', created.paymentId, now(), o.id);
  O.addEvent(o.id, { status: o.status, payment_status: o.payment_status, note: `${provider.name} payment started`, actor: `user:${ctx.user.id}` });
  return { redirect_url: created.redirectUrl };
}, { auth: 'user' });

/**
 * Ask the provider whether the order's payment completed and, if (and only if) the provider confirms
 * it with matching amount + invoice, mark the order paid. Returns 'paid' | 'failed' | 'pending'.
 */
async function settleGateway(order, { executeFirst }) {
  if (['paid', 'refunded'].includes(order.payment_status)) return 'paid';
  if (!order.gateway_payment_id) return 'pending';
  const provider = gatewayFor(order);
  let result;
  try {
    result = await provider.verifyPayment(order.gateway_payment_id, { amount: order.price_bdt, invoice: order.order_no }, { executeFirst });
  } catch (err) {
    console.error('[payment] verify failed:', err.message);
    return 'pending';
  }
  if (!result.ok) {
    O.addEvent(order.id, { status: order.status, payment_status: order.payment_status, note: `${provider.name} did not confirm payment (${result.reason})` });
    return 'failed';
  }
  try {
    O.markPaid(order.id, { trxId: result.trxId, actor: 'gateway', note: `Payment confirmed by ${provider.name} (TrxID ${result.trxId})` });
  } catch (err) {
    // e.g. unique TrxID collision → leave for manual review rather than guessing
    console.error('[payment] could not record payment:', err.message);
    return 'pending';
  }
  return 'paid';
}

// Browser is redirected here by the provider. We never trust the query string: we ask the provider directly.
route('GET', '/api/payments/:provider/callback', async (ctx) => {
  rateLimit(`pay-cb:${ctx.ip}`, 60, 60_000);
  const paymentId = String(ctx.query.paymentID || '').slice(0, 80);
  const o = paymentId && ctx.params.provider === 'bkash' ? get('SELECT * FROM orders WHERE gateway_payment_id = ? AND gateway_provider = ?', paymentId, 'bkash') : null;
  if (!o) return ctx.redirect(`${config.appUrl}/#/orders`);

  let outcome;
  if (ctx.query.status === 'success') outcome = await settleGateway(o, { executeFirst: true });
  else {
    outcome = ctx.query.status === 'cancel' ? 'cancelled' : 'failed';
    O.addEvent(o.id, { status: o.status, payment_status: o.payment_status, note: `Customer returned from payment page: ${ctx.query.status || 'unknown'}` });
  }
  ctx.redirect(`${config.appUrl}/#/order/${o.order_no}?pay=${outcome}`);
}, { csrf: false });

// "I paid but the page didn't update" – safe re-check with the provider (owner only).
route('POST', '/api/orders/:orderNo/payment/gateway/recheck', async (ctx) => {
  rateLimit(`pay-recheck:${ctx.user.id}`, 20, 3600_000);
  const o = O.getOwnedOrder(ctx.user, ctx.params.orderNo);
  const outcome = await settleGateway(o, { executeFirst: false });
  return { outcome, order: O.ownerView(get('SELECT * FROM orders WHERE id = ?', o.id)) };
}, { auth: 'user' });

module.exports = { settleGateway };
