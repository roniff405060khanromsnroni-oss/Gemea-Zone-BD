'use strict';
// End-to-end API tests: auth, authorization, purchase flow, manual payment verification,
// bKash gateway verification (against a LOCAL MOCK of bKash – no real money, no real credentials), admin CRUD.
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

// ── environment must be set before the app is loaded ──
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'gz-test-'));
process.env.DB_PATH = path.join(tmp, 'test.db');
process.env.UPLOAD_DIR = path.join(tmp, 'uploads');
process.env.APP_URL = 'http://localhost:0';
process.env.BKASH_APP_KEY = 'test-key';
process.env.BKASH_APP_SECRET = 'test-secret';
process.env.BKASH_USERNAME = 'test-user';
process.env.BKASH_PASSWORD = 'test-pass';

// ── local mock of bKash tokenized checkout ──
const mock = { payments: new Map(), seq: 0, tamperAmount: false };
const mockServer = http.createServer((req, res) => {
  let body = '';
  req.on('data', (c) => (body += c));
  req.on('end', () => {
    const j = body ? JSON.parse(body) : {};
    const reply = (o) => { res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(o)); };
    const url = req.url;
    if (url.endsWith('/token/grant')) {
      if (req.headers.username !== 'test-user' || j.app_secret !== 'test-secret') return reply({ statusCode: '2001', statusMessage: 'Invalid credentials' });
      return reply({ statusCode: '0000', id_token: 'tok123', expires_in: 3600 });
    }
    if (req.headers.authorization !== 'tok123') return reply({ statusCode: '2001', statusMessage: 'Unauthorized' });
    if (url.endsWith('/checkout/create')) {
      const id = `PAY${++mock.seq}`;
      mock.payments.set(id, { amount: j.amount, invoice: j.merchantInvoiceNumber, approved: false, trxID: `TRX${1000 + mock.seq}ABC` });
      mock.last = id;
      return reply({ statusCode: '0000', paymentID: id, bkashURL: `https://bkash.example/pay/${id}` });
    }
    const p = mock.payments.get(j.paymentID);
    if (!p) return reply({ statusCode: '2062', statusMessage: 'Payment not found' });
    const done = {
      statusCode: '0000', paymentID: j.paymentID, trxID: p.trxID, transactionStatus: 'Completed', currency: 'BDT',
      amount: mock.tamperAmount ? '1.00' : p.amount, merchantInvoiceNumber: p.invoice,
    };
    if (url.endsWith('/checkout/execute')) return reply(p.approved ? done : { statusCode: '2023', statusMessage: 'Not approved by customer' });
    if (url.endsWith('/payment/status')) return reply(p.approved ? done : { statusCode: '0000', paymentID: j.paymentID, transactionStatus: 'Initiated' });
    reply({ statusCode: '9999' });
  });
});

let server, base, hashPassword, dbm;

function client() {
  let cookie = '';
  const call = async (method, p, body, extra = {}) => {
    const res = await fetch(base + p, {
      method, redirect: 'manual',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest', ...(cookie ? { cookie } : {}), ...extra },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    for (const c of res.headers.getSetCookie()) cookie = /Max-Age=0/.test(c) ? '' : c.split(';')[0];
    let data = null;
    try { data = await res.json(); } catch { /* not json */ }
    return { status: res.status, data, res };
  };
  call.raw = async (p, buf, extra = {}) => {
    const res = await fetch(base + p, { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest', cookie, 'Content-Type': 'application/octet-stream', ...extra }, body: buf });
    return { status: res.status, data: await res.json().catch(() => null) };
  };
  return call;
}

let admin, alice, bob, ids = {};

before(async () => {
  await new Promise((r) => mockServer.listen(0, r));
  process.env.BKASH_BASE_URL = `http://localhost:${mockServer.address().port}/v1`;
  const { createServer } = require('../server');
  dbm = require('../server/db');
  ({ hashPassword } = require('../server/services/auth'));
  server = createServer();
  await new Promise((r) => server.listen(0, r));
  base = `http://localhost:${server.address().port}`;
  require('../server/lib/env').config.appUrl = base;

  // seed sample content + an admin account (created directly – there is no default admin)
  process.argv = [process.argv[0], 'seed'];
  require('../scripts/seed.js');
  dbm.run(`INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?, 'admin')`, 'Root Admin', 'admin@example.com', await hashPassword('correct-horse-battery'));

  admin = client();
  const r = await admin('POST', '/api/auth/login', { email: 'admin@example.com', password: 'correct-horse-battery' });
  assert.equal(r.status, 200);
});

after(() => { server.close(); mockServer.close(); fs.rmSync(tmp, { recursive: true, force: true }); });

// ───────────── public & security basics ─────────────
test('public site data loads and nothing is faked', async () => {
  const c = client();
  const r = await c('GET', '/api/site');
  assert.equal(r.status, 200);
  assert.equal(r.data.games.length, 3);
  assert.deepEqual(r.data.reviews, [], 'no invented reviews');
  assert.deepEqual(r.data.recent_orders, [], 'no invented orders');
  assert.deepEqual(r.data.payment_methods, [], 'payment methods are disabled until the admin configures them');
  const s = await c('GET', '/api/search?q=free');
  assert.ok(s.data.games.some((g) => g.slug === 'free-fire'));
  const game = await c('GET', '/api/games/free-fire');
  assert.deepEqual(game.data.categories.map((x) => x.name), ['Diamond Top-Up', 'Weekly Membership', 'Monthly Membership', 'Special Bundles', 'Other Packages']);
  ids.ffProducts = game.data.products;
});

test('state-changing requests without the CSRF header are rejected', async () => {
  const res = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(res.status, 403);
});

test('security headers are present', async () => {
  const res = await fetch(base + '/api/site');
  assert.match(res.headers.get('content-security-policy'), /default-src 'self'/);
  assert.equal(res.headers.get('x-frame-options'), 'DENY');
});

// ───────────── auth ─────────────
test('registration validates input, hashes passwords, and prevents duplicates', async () => {
  alice = client();
  assert.equal((await alice('POST', '/api/auth/register', { name: 'A', email: 'bad', password: 'x' })).status, 400);
  assert.equal((await alice('POST', '/api/auth/register', { name: 'Alice', email: 'alice@example.com', password: 'short' })).status, 400);
  const ok = await alice('POST', '/api/auth/register', { name: 'Alice', email: 'Alice@Example.com', phone: '+8801712345678', password: 'alice-password-1' });
  assert.equal(ok.status, 201);
  assert.equal(ok.data.user.email, 'alice@example.com');
  assert.equal(ok.data.user.phone, '01712345678');
  assert.equal(ok.data.user.role, 'user');
  assert.equal(ok.data.user.password_hash, undefined);
  const row = dbm.get('SELECT password_hash FROM users WHERE email = ?', 'alice@example.com');
  assert.match(row.password_hash, /^scrypt\$/);
  assert.equal((await client()('POST', '/api/auth/register', { name: 'Alice2', email: 'alice@example.com', password: 'another-password' })).status, 409);
  assert.equal((await alice('GET', '/api/auth/me')).data.user.email, 'alice@example.com');
});

test('login fails safely, locks out brute force, and logout ends the session', async () => {
  const c = client();
  const bad = await c('POST', '/api/auth/login', { email: 'alice@example.com', password: 'wrong-wrong' });
  assert.equal(bad.status, 401);
  assert.equal(bad.data.error, (await c('POST', '/api/auth/login', { email: 'nobody@example.com', password: 'wrong-wrong' })).data.error, 'same error for unknown email');
  const good = await c('POST', '/api/auth/login', { email: 'alice@example.com', password: 'alice-password-1' });
  assert.equal(good.status, 200);
  assert.match(good.res.headers.getSetCookie()[0], /HttpOnly/);
  assert.match(good.res.headers.getSetCookie()[0], /SameSite=Lax/);
  await c('POST', '/api/auth/logout');
  assert.equal((await c('GET', '/api/auth/me')).data.user, null);

  const victim = client();
  let last;
  for (let i = 0; i < 10; i++) last = await victim('POST', '/api/auth/login', { email: 'bruteforce@example.com', password: `guess-${i}-guess` });
  assert.equal(last.status, 429);
});

test('password reset: tokens are single-use, generic responses, old sessions revoked', async () => {
  const logs = [];
  const orig = console.log;
  console.log = (...a) => logs.push(a.join(' '));
  const c = client();
  try {
    const known = await c('POST', '/api/auth/forgot-password', { email: 'alice@example.com' });
    const unknown = await c('POST', '/api/auth/forgot-password', { email: 'ghost@example.com' });
    assert.deepEqual(known.data, unknown.data, 'no account enumeration');
  } finally { console.log = orig; }
  const token = logs.join('\n').match(/#\/reset\?token=([\w-]+)/)[1];
  assert.equal((await c('POST', '/api/auth/reset-password', { token: 'nope', password: 'brand-new-password' })).status, 400);
  assert.equal((await c('POST', '/api/auth/reset-password', { token, password: 'brand-new-password' })).status, 200);
  assert.equal((await c('POST', '/api/auth/reset-password', { token, password: 'another-new-password' })).status, 400, 'single use');
  assert.equal((await alice('GET', '/api/auth/me')).data.user, null, 'existing sessions revoked');
  assert.equal((await alice('POST', '/api/auth/login', { email: 'alice@example.com', password: 'brand-new-password' })).status, 200);
});

// ───────────── authorization ─────────────
test('admin API requires an administrator', async () => {
  assert.equal((await client()('GET', '/api/admin/stats')).status, 401);
  assert.equal((await alice('GET', '/api/admin/stats')).status, 403);
  assert.equal((await alice('POST', '/api/admin/r/games', { name: 'Hack' })).status, 403);
  assert.equal((await alice('PATCH', '/api/admin/users/1', { role: 'admin' })).status, 403);
  assert.equal((await admin('GET', '/api/admin/stats')).status, 200);
});

// ───────────── admin management ─────────────
test('admin can manage games, categories and products with validation', async () => {
  const g = await admin('POST', '/api/admin/r/games', { name: 'Call of Duty Mobile', currency_label: 'CP', requires_server_id: false, featured: true });
  assert.equal(g.status, 201);
  assert.equal(g.data.item.slug, 'call-of-duty-mobile');
  assert.equal((await admin('POST', '/api/admin/r/games', { name: 'Call of Duty Mobile' })).status, 409, 'duplicate slug');
  assert.equal((await admin('POST', '/api/admin/r/games', { name: 'X', slug: 'x' })).status, 400, 'name too short');
  assert.equal((await admin('POST', '/api/admin/r/games', { name: 'Bad Regex', player_id_pattern: '([' })).status, 400);

  const cat = await admin('POST', '/api/admin/r/categories', { game_id: g.data.item.id, name: 'CP Top-Up' });
  assert.equal(cat.status, 201);
  const bad = await admin('POST', '/api/admin/r/products', { game_id: g.data.item.id, name: 'Bad', price_bdt: -5 });
  assert.equal(bad.status, 400);
  const p = await admin('POST', '/api/admin/r/products', { game_id: g.data.item.id, category_id: cat.data.item.id, name: '80 CP', quantity_label: '80 CP', price_bdt: 100 });
  assert.equal(p.status, 201);
  const upd = await admin('PUT', `/api/admin/r/products/${p.data.item.id}`, { price_bdt: 120, available: false });
  assert.equal(upd.data.item.price_bdt, 120);
  assert.equal(upd.data.item.available, 0);
  assert.equal((await admin('PUT', `/api/admin/r/products/${p.data.item.id}`, { old_price_bdt: 50 })).status, 400, 'old price must exceed price');

  assert.equal((await admin('DELETE', `/api/admin/r/games/${g.data.item.id}`)).status, 200);
  assert.equal(dbm.get('SELECT COUNT(*) AS n FROM products WHERE game_id = ?', g.data.item.id).n, 0, 'products cascade');
  assert.equal((await admin('GET', '/api/admin/r/nonsense')).status, 404);
});

test('payment methods: stay hidden until configured; gateway methods need real credentials', async () => {
  const list = (await admin('GET', '/api/admin/r/payment_methods')).data.items;
  const bkash = list.find((m) => m.code === 'bkash');
  const nagad = list.find((m) => m.code === 'nagad');
  const gw = list.find((m) => m.code === 'bkash-gateway');
  // enabling without a receiving number must not expose the method
  await admin('PUT', `/api/admin/r/payment_methods/${bkash.id}`, { enabled: true });
  assert.equal((await client()('GET', '/api/site')).data.payment_methods.length, 0);
  await admin('PUT', `/api/admin/r/payment_methods/${bkash.id}`, { account_number: '01700000000', enabled: true });
  await admin('PUT', `/api/admin/r/payment_methods/${nagad.id}`, { account_number: '01800000000', enabled: true });
  await admin('PUT', `/api/admin/r/payment_methods/${gw.id}`, { enabled: true });
  const pub = (await client()('GET', '/api/site')).data.payment_methods;
  assert.deepEqual(pub.map((m) => m.code).sort(), ['bkash', 'bkash-gateway', 'nagad'], 'gateway visible only because test credentials exist');
  ids.bkash = bkash.id; ids.nagad = nagad.id; ids.gw = gw.id;
  const sys = (await admin('GET', '/api/admin/system')).data;
  assert.equal(sys.gateways.find((g) => g.key === 'nagad').configured, false, 'Nagad gateway is honestly reported as not implemented');
});

// ───────────── purchase flow (manual payment) ─────────────
const order = async (c, body) => c('POST', '/api/orders', body);

test('ordering requires login and validates every field server-side', async () => {
  const p = ids.ffProducts.find((x) => x.quantity_label === '240 Diamonds');
  ids.p240 = p;
  assert.equal((await order(client(), { product_id: p.id, payment_method_id: ids.bkash, player_id: '123456789' })).status, 401);
  assert.equal((await order(alice, { product_id: p.id, payment_method_id: ids.bkash, player_id: 'abc' })).status, 400, 'Free Fire UID must be numeric');
  assert.equal((await order(alice, { product_id: 99999, payment_method_id: ids.bkash, player_id: '123456789' })).status, 404);
  assert.equal((await order(alice, { product_id: p.id, payment_method_id: 99999, player_id: '123456789' })).status, 400);

  const ml = (await alice('GET', '/api/games/mobile-legends')).data;
  assert.equal((await order(alice, { product_id: ml.products[0].id, payment_method_id: ids.bkash, player_id: '123456789' })).status, 400, 'Zone ID required');
  assert.equal((await order(alice, { product_id: ml.products[0].id, payment_method_id: ids.bkash, player_id: '123456789', server_id: '2001' })).status, 201);

  // price always comes from the database, never from the client
  const r = await order(alice, { product_id: p.id, payment_method_id: ids.bkash, player_id: '123456789', price_bdt: 1 });
  assert.equal(r.status, 201);
  assert.equal(r.data.order.price_bdt, 160);
  assert.match(r.data.order.order_no, /^GZ-[A-Z2-9]{10}$/);
  assert.equal(r.data.order.status, 'Pending');
  assert.equal(r.data.order.payment_status, 'unpaid');
  ids.order1 = r.data.order.order_no;

  // unavailable products can't be bought
  await admin('PUT', `/api/admin/r/products/${p.id}`, { available: false });
  assert.equal((await order(alice, { product_id: p.id, payment_method_id: ids.bkash, player_id: '123456789' })).status, 409);
  await admin('PUT', `/api/admin/r/products/${p.id}`, { available: true });
});

test('manual payment: submitting a TrxID never marks the order paid; only admin verification does', async () => {
  const no = ids.order1;
  assert.equal((await alice('POST', `/api/orders/${no}/payment/manual`, { trx_id: '12', sender_number: '01711111111' })).status, 400);
  assert.equal((await alice('POST', `/api/orders/${no}/payment/manual`, { trx_id: 'ABC123XYZ9', sender_number: '12345' })).status, 400);
  const sub = await alice('POST', `/api/orders/${no}/payment/manual`, { trx_id: 'abc123xyz9', sender_number: '01711111111' });
  assert.equal(sub.status, 200);
  assert.equal(sub.data.order.status, 'Payment Submitted');
  assert.equal(sub.data.order.payment_status, 'submitted');
  assert.equal(sub.data.order.payment_trx_id, 'ABC123XYZ9');

  const row = dbm.get('SELECT id FROM orders WHERE order_no = ?', no);
  ids.order1Id = row.id;
  // the status can't be forced to Processing/Completed while unverified
  for (const status of ['Processing', 'Completed']) {
    const r = await admin('POST', `/api/admin/orders/${row.id}/status`, { status });
    assert.equal(r.status, 409, `${status} must be blocked before verification`);
  }
  // customers cannot verify their own payment or reach admin routes
  assert.equal((await alice('POST', `/api/admin/orders/${row.id}/verify-payment`)).status, 403);
  assert.equal((await alice('POST', `/api/orders/${no}/payment/manual`, { trx_id: 'NEWTRX0001', sender_number: '01711111111' })).status, 409, 'cannot resubmit while under review');

  // tracking shows only the safe fields
  const t = await client()('GET', `/api/track/${no.toLowerCase()}`);
  assert.equal(t.status, 200);
  assert.equal(t.data.order.status, 'Payment Submitted');
  assert.equal(t.data.order.player_id_masked.endsWith('789'), true);
  assert.equal(t.data.order.player_id, undefined);
  assert.equal(t.data.order.payment_trx_id, undefined);
  assert.equal((await client()('GET', '/api/track/GZ-NOSUCHORDER')).status, 404);

  const v = await admin('POST', `/api/admin/orders/${row.id}/verify-payment`);
  assert.equal(v.status, 200);
  assert.equal(v.data.order.payment_status, 'paid');
  assert.equal(v.data.order.status, 'Processing');
  assert.equal((await admin('POST', `/api/admin/orders/${row.id}/verify-payment`)).status, 409, 'not verifiable twice');

  assert.equal((await admin('POST', `/api/admin/orders/${row.id}/status`, { status: 'Cancelled' })).status, 409, 'paid orders must be refunded, not cancelled');
  const done = await admin('POST', `/api/admin/orders/${row.id}/status`, { status: 'Completed', note: 'Delivered' });
  assert.equal(done.data.order.status, 'Completed');
  assert.deepEqual(done.data.events.map((e) => e.status), ['Pending', 'Payment Submitted', 'Processing', 'Completed']);
  assert.equal((await client()('GET', `/api/track/${no}`)).data.order.status, 'Completed');
});

test('a TrxID cannot be reused on another order; rejected payments can be resubmitted', async () => {
  const mk = async () => (await order(alice, { product_id: ids.p240.id, payment_method_id: ids.bkash, player_id: '123456789' })).data.order.order_no;
  const no2 = await mk();
  const dup = await alice('POST', `/api/orders/${no2}/payment/manual`, { trx_id: 'ABC123XYZ9', sender_number: '01711111111' });
  assert.equal(dup.status, 409);

  const sub = await alice('POST', `/api/orders/${no2}/payment/manual`, { trx_id: 'FAKE000001', sender_number: '01711111111' });
  assert.equal(sub.status, 200);
  const id2 = dbm.get('SELECT id FROM orders WHERE order_no = ?', no2).id;
  const rej = await admin('POST', `/api/admin/orders/${id2}/reject-payment`, { note: 'TrxID not found in our account' });
  assert.equal(rej.data.order.payment_status, 'rejected');
  assert.equal(rej.data.order.status, 'Pending');
  const re = await alice('POST', `/api/orders/${no2}/payment/manual`, { trx_id: 'REAL000002', sender_number: '01711111111' });
  assert.equal(re.status, 200);
  assert.equal((await admin('POST', `/api/admin/orders/${id2}/status`, { status: 'Cancelled' })).data.order.payment_status, 'rejected');
});

test('refunds require a paid order; customers can only see their own orders', async () => {
  const id = ids.order1Id;
  const ref = await admin('POST', `/api/admin/orders/${id}/status`, { status: 'Refunded' });
  assert.equal(ref.data.order.status, 'Refunded');
  assert.equal(ref.data.order.payment_status, 'refunded');
  assert.equal((await admin('POST', `/api/admin/orders/${id}/status`, { status: 'Processing' })).status, 409, 'refunded orders stay closed');

  bob = client();
  await bob('POST', '/api/auth/register', { name: 'Bob', email: 'bob@example.com', password: 'bob-password-12' });
  assert.equal((await bob('GET', `/api/orders/${ids.order1}`)).status, 404);
  assert.equal((await bob('GET', '/api/orders')).data.orders.length, 0);
  assert.ok((await alice('GET', '/api/orders')).data.orders.length >= 3);
  assert.equal((await bob('POST', `/api/orders/${ids.order1}/cancel`)).status, 404);
});

test('customers can cancel their own unpaid orders only', async () => {
  const no = (await order(alice, { product_id: ids.p240.id, payment_method_id: ids.nagad, player_id: '555555555' })).data.order.order_no;
  assert.equal((await alice('POST', `/api/orders/${no}/cancel`)).data.order.status, 'Cancelled');
  assert.equal((await alice('POST', `/api/orders/${ids.order1}/cancel`)).status, 409);
});

test('maintenance mode blocks new orders', async () => {
  await admin('PUT', '/api/admin/settings', { site_name: 'GAMEZONE BD', maintenance_mode: true });
  assert.equal((await order(alice, { product_id: ids.p240.id, payment_method_id: ids.bkash, player_id: '123456789' })).status, 503);
  await admin('PUT', '/api/admin/settings', { maintenance_mode: false });
  assert.equal((await order(alice, { product_id: ids.p240.id, payment_method_id: ids.bkash, player_id: '123456789' })).status, 201);
});

// ───────────── bKash gateway (against the local mock) ─────────────
test('gateway payment is only accepted after the provider confirms it server-to-server', async () => {
  const mkGw = async () => (await order(alice, { product_id: ids.p240.id, payment_method_id: ids.gw, player_id: '123456789' })).data.order.order_no;
  const no = await mkGw();
  const start = await alice('POST', `/api/orders/${no}/payment/gateway`);
  assert.equal(start.status, 200);
  assert.match(start.data.redirect_url, /bkash\.example\/pay\/PAY\d+/);
  const pid = mock.last;
  assert.equal(mock.payments.get(pid).amount, '160.00');
  assert.equal(mock.payments.get(pid).invoice, no);

  const cb = (q) => fetch(`${base}/api/payments/bkash/callback?${q}`, { redirect: 'manual' });
  const status = () => dbm.get('SELECT status, payment_status FROM orders WHERE order_no = ?', no);

  // 1) provider says "success" in the URL but the customer never approved → we do NOT trust the URL
  let r = await cb(`paymentID=${pid}&status=success`);
  assert.equal(r.status, 302);
  assert.match(r.headers.get('location'), new RegExp(`#/order/${no}\\?pay=failed`));
  assert.deepEqual({ ...status() }, { status: 'Pending', payment_status: 'unpaid' });

  // 2) cancelled / failed callbacks never mark paid
  await cb(`paymentID=${pid}&status=cancel`);
  await cb(`paymentID=${pid}&status=failure`);
  assert.equal(status().payment_status, 'unpaid');

  // 3) approved but the amount differs → rejected
  mock.payments.get(pid).approved = true;
  mock.tamperAmount = true;
  r = await cb(`paymentID=${pid}&status=success`);
  assert.match(r.headers.get('location'), /pay=failed/);
  assert.equal(status().payment_status, 'unpaid');
  mock.tamperAmount = false;

  // 4) genuinely completed → paid
  r = await cb(`paymentID=${pid}&status=success`);
  assert.match(r.headers.get('location'), /pay=paid/);
  assert.deepEqual({ ...status() }, { status: 'Processing', payment_status: 'paid' });
  const row = dbm.get('SELECT payment_trx_id FROM orders WHERE order_no = ?', no);
  assert.equal(row.payment_trx_id, mock.payments.get(pid).trxID);

  // 5) replay is harmless
  await cb(`paymentID=${pid}&status=success`);
  assert.equal(dbm.get('SELECT COUNT(*) AS n FROM order_events WHERE order_id = (SELECT id FROM orders WHERE order_no = ?) AND payment_status = \'paid\' AND actor = \'gateway\'', no).n, 1);

  // unknown payment ids go nowhere
  const unk = await cb('paymentID=PAYNOPE&status=success');
  assert.match(unk.headers.get('location'), /#\/orders$/);
});

test('gateway re-check (customer + admin) settles a payment that completed while the browser was away', async () => {
  const no = (await order(alice, { product_id: ids.p240.id, payment_method_id: ids.gw, player_id: '123456789' })).data.order.order_no;
  await alice('POST', `/api/orders/${no}/payment/gateway`);
  const pid = mock.last;
  assert.equal((await alice('POST', `/api/orders/${no}/payment/gateway/recheck`)).data.outcome, 'failed');
  mock.payments.get(pid).approved = true;
  const re = await alice('POST', `/api/orders/${no}/payment/gateway/recheck`);
  assert.equal(re.data.outcome, 'paid');
  assert.equal(re.data.order.status, 'Processing');
  assert.equal((await alice('POST', `/api/orders/${no}/payment/manual`, { trx_id: 'SOMETHING1', sender_number: '01711111111' })).status, 400, 'gateway orders have no manual path');

  // admin re-check
  const no2 = (await order(alice, { product_id: ids.p240.id, payment_method_id: ids.gw, player_id: '123456789' })).data.order.order_no;
  await alice('POST', `/api/orders/${no2}/payment/gateway`);
  const id2 = dbm.get('SELECT id FROM orders WHERE order_no = ?', no2).id;
  assert.equal((await admin('POST', `/api/admin/orders/${id2}/gateway-recheck`)).data.outcome, 'failed');
  mock.payments.get(mock.last).approved = true;
  const ar = await admin('POST', `/api/admin/orders/${id2}/gateway-recheck`);
  assert.equal(ar.data.outcome, 'paid');
  assert.equal(ar.data.order.status, 'Processing');
  // admins cannot "recheck" a manual order
  const manualId = dbm.get(`SELECT id FROM orders WHERE payment_method_type = 'manual' LIMIT 1`).id;
  assert.equal((await admin('POST', `/api/admin/orders/${manualId}/gateway-recheck`)).status, 409);
});

test('deliberate errors keep their real message (not masked as a server fault)', async () => {
  await admin('PUT', '/api/admin/settings', { site_name: 'GAMEZONE BD', maintenance_mode: true });
  const r = await order(alice, { product_id: ids.p240.id, payment_method_id: ids.bkash, player_id: '123456789' });
  assert.equal(r.status, 503);
  assert.match(r.data.error, /maintenance/i);
  await admin('PUT', '/api/admin/settings', { maintenance_mode: false });
});

// ───────────── users, settings, uploads ─────────────
test('admin user management protects the last admin and own account', async () => {
  const users = (await admin('GET', '/api/admin/users')).data.items;
  const adminId = users.find((u) => u.email === 'admin@example.com').id;
  const bobId = users.find((u) => u.email === 'bob@example.com').id;
  assert.equal((await admin('PATCH', `/api/admin/users/${adminId}`, { role: 'user' })).status, 409);
  assert.equal((await admin('PATCH', `/api/admin/users/${adminId}`, { status: 'banned' })).status, 409);
  assert.equal((await admin('PATCH', `/api/admin/users/${bobId}`, { status: 'banned' })).data.user.status, 'banned');
  assert.equal((await bob('GET', '/api/auth/me')).data.user, null, 'banned users are signed out');
  assert.equal((await client()('POST', '/api/auth/login', { email: 'bob@example.com', password: 'bob-password-12' })).status, 403);
});

test('dashboard statistics reflect real orders', async () => {
  const s = (await admin('GET', '/api/admin/stats')).data;
  assert.equal(s.total_users, 3);
  assert.ok(s.total_orders >= 6);
  assert.equal(s.completed_orders, 0, 'the one completed order was refunded');
  assert.equal(s.total_revenue, 0, 'refunded orders do not count as revenue');
  assert.equal(s.total_products, 13 + 5 + 5);
  assert.equal(s.last_7_days.length, 7);
});

test('uploads accept only real images', async () => {
  const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(40, 1)]);
  const up = await admin.raw('/api/admin/upload', png);
  assert.equal(up.status, 201);
  const res = await fetch(base + up.data.url);
  assert.equal(res.status, 200);
  assert.equal(res.headers.get('content-type'), 'image/png');
  assert.equal((await admin.raw('/api/admin/upload', Buffer.from('<script>alert(1)</script>'))).status, 400);
  assert.equal((await alice.raw('/api/admin/upload', png)).status, 403);
});

test('static file serving blocks path traversal', async () => {
  const res = await fetch(base + '/..%2f..%2fpackage.json');
  assert.ok([403, 404].includes(res.status));
  const res2 = await fetch(base + '/uploads/..%2f..%2ftest.db');
  assert.ok([403, 404].includes(res2.status));
});
